package com.altayaytin.altay_paranormal_app

import android.app.Activity
import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "altay_paranormal/docx_picker"
    private val requestCodeDocx = 43210
    private var pendingResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            if (call.method == "pickDocx") {
                if (pendingResult != null) {
                    result.error("busy", "Dosya seçimi zaten açık.", null)
                    return@setMethodCallHandler
                }

                pendingResult = result
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/octet-stream",
                        "application/zip"
                    ))
                }

                try {
                    startActivityForResult(Intent.createChooser(intent, "Word dosyası seç"), requestCodeDocx)
                } catch (e: Exception) {
                    pendingResult = null
                    result.error("open_failed", e.message, null)
                }
            } else {
                result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == requestCodeDocx) {
            val result = pendingResult
            pendingResult = null
            if (result == null) return

            if (resultCode != Activity.RESULT_OK) {
                result.success(null)
                return
            }

            val uri = data?.data
            if (uri == null) {
                result.success(null)
                return
            }

            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    result.error("read_failed", "Word dosyası okunamadı.", null)
                } else {
                    result.success(bytes)
                }
            } catch (e: Exception) {
                result.error("read_error", e.message, null)
            }
        }
    }
}
