package com.altayaytin.altay_paranormal_app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "altay_paranormal/docx_picker"
    private val requestCodeDocx = 43210
    private val requestCodeBackup = 43211
    private var pendingResult: MethodChannel.Result? = null
    private val pendingSharedFiles = mutableListOf<ByteArray>()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        readSharedFilesFromIntent(intent)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDocx" -> openDocxPicker(result)
                "pickBackup" -> openBackupPicker(result)
                "getSharedDocxFiles" -> {
                    val files = pendingSharedFiles.toList()
                    pendingSharedFiles.clear()
                    result.success(files)
                }
                // Eski Flutter koduyla uyumluluk için ilk dosyayı döndürür.
                "getSharedDocx" -> {
                    val bytes = pendingSharedFiles.firstOrNull()
                    pendingSharedFiles.clear()
                    result.success(bytes)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedFilesFromIntent(intent)
    }

    private fun readSharedFilesFromIntent(incoming: Intent?) {
        if (incoming == null) return

        val uris = linkedSetOf<Uri>()
        when (incoming.action) {
            Intent.ACTION_SEND -> getSingleStreamUri(incoming)?.let(uris::add)
            Intent.ACTION_SEND_MULTIPLE -> uris.addAll(getMultipleStreamUris(incoming))
            Intent.ACTION_VIEW -> incoming.data?.let(uris::add)
        }

        val clipData = incoming.clipData
        if (clipData != null) {
            for (index in 0 until clipData.itemCount) {
                clipData.getItemAt(index).uri?.let(uris::add)
            }
        }

        if (uris.isEmpty()) return

        val loaded = mutableListOf<ByteArray>()
        for (uri in uris) {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes != null && bytes.isNotEmpty()) loaded.add(bytes)
            } catch (_: Exception) {
                // Okunamayan tek dosya diğer dosyaların alınmasını engellemez.
            }
        }

        if (loaded.isNotEmpty()) {
            pendingSharedFiles.clear()
            pendingSharedFiles.addAll(loaded)
            // Aynı paylaşım intent'i uygulama normal açıldığında tekrar işlenmesin.
            setIntent(Intent(this, MainActivity::class.java))
        }
    }

    @Suppress("DEPRECATION")
    private fun getSingleStreamUri(intent: Intent): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
    }

    @Suppress("DEPRECATION")
    private fun getMultipleStreamUris(intent: Intent): List<Uri> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
        } else {
            intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
        }
    }

    private fun openDocxPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }

        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/msword",
                "application/octet-stream",
                "application/zip"
            ))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        try {
            startActivityForResult(Intent.createChooser(intent, "Word dosyası seç"), requestCodeDocx)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    private fun openBackupPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }

        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/json",
                "text/plain",
                "application/octet-stream"
            ))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        try {
            startActivityForResult(Intent.createChooser(intent, "Yedek dosyası seç"), requestCodeBackup)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != requestCodeDocx && requestCode != requestCodeBackup) return

        val result = pendingResult
        pendingResult = null
        if (result == null) return

        if (resultCode != Activity.RESULT_OK) {
            result.success(null)
            return
        }

        val uri = data?.data
        if (uri == null) {
            result.success(null)
            return
        }

        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) {
                result.error("read_failed", "Dosya okunamadı.", null)
            } else {
                result.success(bytes)
            }
        } catch (e: Exception) {
            result.error("read_error", e.message, null)
        }
    }
}
