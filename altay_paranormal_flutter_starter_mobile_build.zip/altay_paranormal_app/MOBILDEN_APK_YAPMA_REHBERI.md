# Mobilden APK Yapma Rehberi

Bu proje bilgisayar olmadan APK üretmek için GitHub Actions ayarıyla hazırlandı.

## Gerekli olanlar

- Android telefonda tarayıcı
- GitHub hesabı
- Bu zip dosyası

## Adımlar

1. Telefonda GitHub hesabına giriş yap.
2. github.com/new adresinden yeni bir repository oluştur.
   - Repository adı: altay-paranormal-app
   - Public veya Private seçebilirsin.
3. Repository açılınca “uploading an existing file” bağlantısına dokun.
4. Zip içindeki `altay_paranormal_app` klasörünün içindeki dosyaları yükle.
   - Özellikle `.github/workflows/build-apk.yml` dosyasının yüklendiğinden emin ol.
5. Yükleme bitince Commit changes de.
6. Repository içinde Actions sekmesine gir.
7. “Android APK Oluştur” iş akışını aç.
8. Run workflow düğmesine bas.
9. İşlem bitince aynı sayfada Artifacts bölümünden `altay-paranormal-apk` dosyasını indir.
10. Zip içinden `app-release.apk` dosyasını çıkarıp telefona kur.

## Notlar

- İlk APK deneme içindir. Google Play’e yüklemek için imzalı sürüm ayarı gerekir.
- Telefon APK kurulumunda “bilinmeyen kaynaklara izin ver” isteyebilir.
- Google Play için daha sonra uygulama adı, ikon, paket adı ve imzalama ayarları düzenlenmelidir.
