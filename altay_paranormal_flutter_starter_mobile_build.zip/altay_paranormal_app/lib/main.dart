import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as im;
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive_io.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';

const appVersionLabel = 'SÜRÜM 84 • GÖRSELLERİ GÖMÜLÜ WORD';
const MethodChannel docxPickerChannel = MethodChannel('altay_paranormal/docx_picker');

class IncomingDocument {
  final String path;
  final String name;
  final String mimeType;
  final Uint8List? bytes;

  const IncomingDocument({
    this.path = '',
    this.name = '',
    this.mimeType = '',
    this.bytes,
  });

  factory IncomingDocument.fromNative(dynamic value) {
    if (value is Map) {
      return IncomingDocument(
        path: value['path']?.toString() ?? '',
        name: value['name']?.toString() ?? '',
        mimeType: value['mimeType']?.toString() ?? '',
      );
    }
    if (value is Uint8List) return IncomingDocument(bytes: value, name: 'paylasilan_belge.docx');
    throw const FormatException('Paylaşılan dosya bilgisi okunamadı.');
  }

  String get displayName {
    if (name.trim().isNotEmpty) return name.trim();
    if (path.trim().isNotEmpty) return path.replaceAll('\\', '/').split('/').last;
    return 'Belge';
  }
}

class DocumentImportBatch {
  final List<AppContent> chapters;
  final int receivedFileCount;
  final int unreadableFileCount;
  final int wordFileCount;
  final int pdfFileCount;
  final int textFileCount;
  final List<String> failedFiles;

  const DocumentImportBatch({
    required this.chapters,
    required this.receivedFileCount,
    required this.unreadableFileCount,
    required this.wordFileCount,
    required this.pdfFileCount,
    required this.textFileCount,
    required this.failedFiles,
  });
}

class WriterEditResult {
  final String editedBody;
  final String aiReport;

  const WriterEditResult({
    required this.editedBody,
    required this.aiReport,
  });
}

class ExternalDocumentImporter {
  static Future<List<IncomingDocument>> takeSharedFiles() async {
    try {
      final rawFiles = await docxPickerChannel.invokeMethod<List<dynamic>>('getSharedFiles');
      if (rawFiles != null) {
        final files = <IncomingDocument>[];
        for (final raw in rawFiles) {
          try {
            final file = IncomingDocument.fromNative(raw);
            if (file.path.trim().isNotEmpty || (file.bytes?.isNotEmpty ?? false)) files.add(file);
          } catch (_) {}
        }
        if (files.isNotEmpty) return files;
      }
    } on MissingPluginException {
      // Eski yerel katmanla uyumluluk aşağıda sürdürülür.
    }

    try {
      final rawFiles = await docxPickerChannel.invokeMethod<List<dynamic>>('getSharedDocxFiles');
      if (rawFiles != null) {
        final files = rawFiles.whereType<Uint8List>().where((bytes) => bytes.isNotEmpty).map((bytes) {
          return IncomingDocument(bytes: bytes, name: 'paylasilan_belge.docx');
        }).toList();
        if (files.isNotEmpty) return files;
      }
    } on MissingPluginException {}

    final bytes = await docxPickerChannel.invokeMethod<Uint8List>('getSharedDocx');
    if (bytes == null || bytes.isEmpty) return const <IncomingDocument>[];
    return <IncomingDocument>[IncomingDocument(bytes: bytes, name: 'paylasilan_belge.docx')];
  }

  static Future<List<IncomingDocument>> pickDocuments() async {
    final rawFiles = await docxPickerChannel.invokeMethod<List<dynamic>>('pickDocuments');
    if (rawFiles == null) return const <IncomingDocument>[];
    final files = <IncomingDocument>[];
    for (final raw in rawFiles) {
      try {
        final file = IncomingDocument.fromNative(raw);
        if (file.path.trim().isNotEmpty || (file.bytes?.isNotEmpty ?? false)) files.add(file);
      } catch (_) {}
    }
    return files;
  }

  static Future<DocumentImportBatch> importFiles(List<IncomingDocument> files) async {
    final chapters = <AppContent>[];
    final failedFiles = <String>[];
    var wordCount = 0;
    var pdfCount = 0;
    var textCount = 0;

    for (final file in files) {
      try {
        final kind = await _detectKind(file);
        if (kind == 'docx') {
          final imported = await BookImporter.fromDocx(
            path: file.path.trim().isEmpty ? null : file.path,
            bytes: file.bytes,
          );
          if (imported.isEmpty) throw Exception('Word dosyasında bölüm bulunamadı.');
          chapters.addAll(_applyFileChapterNumber(imported, file));
          wordCount++;
          continue;
        }
        if (kind == 'pdf') {
          chapters.add(await _importPdf(file));
          pdfCount++;
          continue;
        }
        if (kind == 'txt') {
          final raw = await _readText(file);
          final imported = BookImporter.fromPlainText(raw);
          if (imported.isEmpty) throw Exception('Metin dosyasında bölüm bulunamadı.');
          chapters.addAll(_applyFileChapterNumber(imported, file));
          textCount++;
          continue;
        }
        throw Exception('Desteklenmeyen dosya türü. Eski .doc yerine DOCX kullanın.');
      } catch (_) {
        failedFiles.add(file.displayName);
      }
    }

    final orderedChapters = sortImportedChaptersByNumber(chapters);

    return DocumentImportBatch(
      chapters: orderedChapters,
      receivedFileCount: files.length,
      unreadableFileCount: failedFiles.length,
      wordFileCount: wordCount,
      pdfFileCount: pdfCount,
      textFileCount: textCount,
      failedFiles: failedFiles,
    );
  }

  static List<AppContent> _applyFileChapterNumber(List<AppContent> imported, IncomingDocument file) {
    if (imported.length != 1) return imported;
    final item = imported.first;
    if (explicitBookChapterNumber(item) != null) return imported;
    final fileNumber = explicitBookChapterNumberFromText(file.displayName);
    if (fileNumber == null) return imported;
    return [item.copyWith(category: '$fileNumber. Bölüm')];
  }

  static Future<String> _detectKind(IncomingDocument file) async {
    final lowerName = file.displayName.toLowerCase();
    final lowerMime = file.mimeType.toLowerCase();
    if (lowerName.endsWith('.pdf') || lowerMime.contains('pdf')) return 'pdf';
    if (lowerName.endsWith('.docx') || lowerMime.contains('openxmlformats-officedocument.wordprocessingml')) return 'docx';
    if (lowerName.endsWith('.txt') || lowerMime.startsWith('text/')) return 'txt';
    if (lowerName.endsWith('.doc') || lowerMime == 'application/msword') return 'doc';

    final signature = await _readSignature(file, 8);
    if (signature.length >= 4 && String.fromCharCodes(signature.take(4)) == '%PDF') return 'pdf';
    if (signature.length >= 2 && signature[0] == 0x50 && signature[1] == 0x4B) return 'docx';
    return 'unknown';
  }

  static Future<List<int>> _readSignature(IncomingDocument file, int count) async {
    if (file.bytes != null) return file.bytes!.take(count).toList();
    if (file.path.trim().isEmpty) return const [];
    final handle = await File(file.path).open();
    try {
      return await handle.read(count);
    } finally {
      await handle.close();
    }
  }

  static Future<String> _readText(IncomingDocument file) async {
    final data = file.bytes ?? await File(file.path).readAsBytes();
    return utf8.decode(data, allowMalformed: true);
  }

  static String _titleFromFileName(String value) {
    var name = value.replaceAll('\\', '/').split('/').last;
    name = name.replaceFirst(RegExp(r'\.(pdf|docx|doc|txt)$', caseSensitive: false), '');
    name = name.replaceAll(RegExp(r'[_-]+'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    return name.isEmpty ? 'İçe Aktarılan PDF Bölümü' : name;
  }

  static Future<AppContent> _importPdf(IncomingDocument file) async {
    var path = file.path;
    if (path.trim().isEmpty) {
      final dir = await getApplicationDocumentsDirectory();
      final incomingDir = Directory('${dir.path}/incoming_documents');
      if (!await incomingDir.exists()) await incomingDir.create(recursive: true);
      final target = File('${incomingDir.path}/pdf_${DateTime.now().microsecondsSinceEpoch}.pdf');
      await target.writeAsBytes(file.bytes ?? Uint8List(0), flush: true);
      path = target.path;
    }

    final rawPaths = await docxPickerChannel.invokeMethod<List<dynamic>>('renderPdfPages', {'path': path});
    final imagePaths = (rawPaths ?? const <dynamic>[]).map((value) => value.toString()).where((value) => value.trim().isNotEmpty).toList();
    if (imagePaths.isEmpty) throw Exception('PDF sayfaları görüntüye dönüştürülemedi.');

    final importedTitle = _titleFromFileName(file.displayName);
    final importedNumber = explicitBookChapterNumberFromText(importedTitle);

    return AppContent(
      id: 'pdf_import_${DateTime.now().microsecondsSinceEpoch}',
      type: ContentTypes.book,
      title: importedTitle,
      category: importedNumber == null ? 'Bölüm' : '$importedNumber. Bölüm',
      summary: '',
      body: List<String>.filled(imagePaths.length, 'görsel').join('\n\n'),
      source: 'PDF sayfaları düzeni bozulmadan görsel olarak içe aktarıldı: ${file.displayName}',
      inlineImagePaths: imagePaths,
    );
  }
}

void main() {
  runApp(const AltayParanormalApp());
}


String cleanBookChapterTitle(String value) {
  final clean = value.trim().replaceAll(RegExp(r'\s+'), ' ');
  if (clean.length <= 80) return clean;

  final markers = <String>[
    ' Modern dünyada',
    ' Modern bilim',
    ' David Icke',
    ' Icke’nin',
    " Icke'nin",
    ' Icke’ye',
    " Icke'ye",
    ' Ona göre',
    ' Bu görüş',
    ' Bu düşünce',
    ' Bu yaklaşım',
    ' Gerçeklik',
    ' İnsanlar',
    ' Antik mitolojiler',
  ];

  var splitIndex = -1;
  for (final marker in markers) {
    final index = clean.indexOf(marker);
    if (index > 25 && (splitIndex == -1 || index < splitIndex)) {
      splitIndex = index;
    }
  }

  if (splitIndex > 0) {
    return clean.substring(0, splitIndex).trim();
  }

  final letters = clean.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
  final upperLetters = letters.replaceAll(RegExp(r'[^A-ZÇĞİÖŞÜ]'), '');
  final mostlyUpper = letters.isNotEmpty && upperLetters.length / letters.length > 0.72;

  // Tamamen/çoğunlukla büyük harfli bölüm başlıklarını kesme.
  // Örn: DAVID ICKE VE REPTİLYAN TEORİSİ: HOLOGRAFİK EVREN...
  if (mostlyUpper) return clean;

  final words = clean.split(' ');
  if (words.length > 9) {
    for (var i = 5; i < words.length; i++) {
      final word = words[i];
      final hasLowercase = RegExp(r'[a-zçğıöşü]').hasMatch(word);
      if (hasLowercase) {
        return words.take(i).join(' ').trim();
      }
    }
    return words.take(9).join(' ').trim();
  }

  return clean;
}

String bookChapterTitleOverflow(String value) {
  final clean = value.trim().replaceAll(RegExp(r'\s+'), ' ');
  final title = cleanBookChapterTitle(value);
  if (title.isEmpty || title == clean || clean.length <= title.length) return '';
  return clean.substring(title.length).trim();
}


String _normalizeBookLabelText(String value) {
  return value
      .toLowerCase()
      .replaceAll('ı', 'i')
      .replaceAll('İ', 'i')
      .replaceAll('ö', 'o')
      .replaceAll('ü', 'u')
      .replaceAll('ş', 's')
      .replaceAll('ğ', 'g')
      .replaceAll('ç', 'c')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

bool isBookFrontMatter(String title, String category) {
  final value = _normalizeBookLabelText('$title $category');
  return value.contains('onsoz') ||
      value.contains('giris') ||
      value.contains('sunus') ||
      value.contains('baslarken') ||
      value.contains('okura not');
}

String bookChapterLabel(String title, String category, int index) {
  if (isBookFrontMatter(title, category)) {
    final clean = cleanBookChapterTitle(title).trim();
    final normalized = _normalizeBookLabelText(clean);
    if (normalized.contains('onsoz')) return 'Önsöz';
    if (normalized.contains('sunus')) return 'Sunuş';
    if (normalized.contains('giris')) return 'Giriş';
    if (normalized.contains('okura not')) return 'Okura Not';
    if (clean.isNotEmpty && clean.length <= 24) return clean;
    return 'Önsöz';
  }
  return '${index + 1}. Bölüm';
}

String bookExportChapterHeader(String title, String category, int index) {
  final label = bookChapterLabel(title, category, index);
  if (isBookFrontMatter(title, category)) return label.toUpperCase();
  return '${index + 1}. BÖLÜM';
}

int bookChapterNumberInList(List<AppContent> items, int index) {
  var number = 0;
  final safeIndex = index < items.length ? index : items.length - 1;
  for (var i = 0; i <= safeIndex; i++) {
    final item = items[i];
    if (!isBookFrontMatter(item.title, item.category)) {
      number++;
    }
  }
  return number < 1 ? 1 : number;
}

String bookChapterLabelFromList(List<AppContent> items, int index) {
  if (items.isEmpty || index < 0 || index >= items.length) return '';
  final item = items[index];
  if (isBookFrontMatter(item.title, item.category)) {
    return bookChapterLabel(item.title, item.category, index);
  }
  return '${bookChapterNumberInList(items, index)}. Bölüm';
}

String bookExportChapterHeaderFromList(List<AppContent> items, int index) {
  if (items.isEmpty || index < 0 || index >= items.length) return '';
  final item = items[index];
  if (isBookFrontMatter(item.title, item.category)) {
    return bookChapterLabel(item.title, item.category, index).toUpperCase();
  }
  return '${bookChapterNumberInList(items, index)}. BÖLÜM';
}

bool _sameBookHeading(String a, String b) {
  return _normalizeBookLabelText(a) == _normalizeBookLabelText(b);
}

int? explicitBookChapterNumberFromText(String value) {
  final clean = value.replaceAll('\r', ' ').replaceAll('\n', ' ').trim();
  if (clean.isEmpty) return null;

  final patterns = <RegExp>[
    RegExp(r'(?:^|[\s_\-–—])([0-9]{1,4})\s*[\.\-–—:)]?\s*(?:Bölüm|Bolum)\b', caseSensitive: false),
    RegExp(r'(?:Bölüm|Bolum)\s*[:#\.\-–—]?\s*([0-9]{1,4})\b', caseSensitive: false),
    RegExp(r'^\s*([0-9]{1,4})\s*[\.\-_)]+\s*'),
  ];

  for (final pattern in patterns) {
    final match = pattern.firstMatch(clean);
    if (match == null) continue;
    final parsed = int.tryParse(match.group(1) ?? '');
    if (parsed != null && parsed > 0) return parsed;
  }
  return null;
}

int? explicitBookChapterNumber(AppContent item) {
  return explicitBookChapterNumberFromText('${item.category} ${item.title} ${item.source}');
}

List<AppContent> sortImportedChaptersByNumber(List<AppContent> chapters) {
  final indexed = chapters.asMap().entries.toList();
  indexed.sort((a, b) {
    int group(AppContent item) {
      if (isBookFrontMatter(item.title, item.category)) return 0;
      if (explicitBookChapterNumber(item) != null) return 1;
      if (isBookBackMatter(item.title, item.category)) return 3;
      return 2;
    }

    final groupCompare = group(a.value).compareTo(group(b.value));
    if (groupCompare != 0) return groupCompare;

    final aNumber = explicitBookChapterNumber(a.value);
    final bNumber = explicitBookChapterNumber(b.value);
    if (aNumber != null && bNumber != null) {
      final numberCompare = aNumber.compareTo(bNumber);
      if (numberCompare != 0) return numberCompare;
    }
    return a.key.compareTo(b.key);
  });

  return indexed.map((entry) {
    final number = explicitBookChapterNumber(entry.value);
    if (number == null || isBookFrontMatter(entry.value.title, entry.value.category) || isBookBackMatter(entry.value.title, entry.value.category)) {
      return entry.value;
    }
    return entry.value.copyWith(category: '$number. Bölüm');
  }).toList();
}


enum BookFlowSortMode { balanced, topic, geography }

extension BookFlowSortModeLabel on BookFlowSortMode {
  String get label {
    switch (this) {
      case BookFlowSortMode.balanced:
        return 'Dengeli akış';
      case BookFlowSortMode.topic:
        return 'Konu öncelikli';
      case BookFlowSortMode.geography:
        return 'Coğrafya öncelikli';
    }
  }

  String get description {
    switch (this) {
      case BookFlowSortMode.balanced:
        return 'Kuramsal başlangıç, köken anlatıları ve coğrafi geçişleri birlikte değerlendirir.';
      case BookFlowSortMode.topic:
        return 'Benzer konuları art arda getirir; coğrafyayı ikinci ölçüt olarak kullanır.';
      case BookFlowSortMode.geography:
        return 'Başlangıç bölümlerinden sonra yakın coğrafyaları bir araya getirir.';
    }
  }
}

bool isBookBackMatter(String title, String category) {
  final value = _normalizeBookLabelText('$title $category');
  return value.contains('son soz') ||
      value.contains('sonuc') ||
      value.contains('kaynakca') ||
      value.contains('gorsel kaynak') ||
      value.contains('yazar hakkinda') ||
      value.contains('ekler') ||
      value.contains('dizin');
}

class _BookFlowTag {
  final int rank;
  final String label;

  const _BookFlowTag(this.rank, this.label);
}

class BookFlowDescriptor {
  final AppContent item;
  final int originalIndex;
  final int proposedIndex;
  final int structureRank;
  final int themeRank;
  final int geographyRank;
  final String reason;

  const BookFlowDescriptor({
    required this.item,
    required this.originalIndex,
    required this.proposedIndex,
    required this.structureRank,
    required this.themeRank,
    required this.geographyRank,
    required this.reason,
  });

  BookFlowDescriptor copyWith({int? proposedIndex}) {
    return BookFlowDescriptor(
      item: item,
      originalIndex: originalIndex,
      proposedIndex: proposedIndex ?? this.proposedIndex,
      structureRank: structureRank,
      themeRank: themeRank,
      geographyRank: geographyRank,
      reason: reason,
    );
  }
}

class BookFlowPlan {
  final List<AppContent> ordered;
  final List<BookFlowDescriptor> descriptors;
  final BookFlowSortMode mode;
  final bool keptLockedPositions;

  const BookFlowPlan({
    required this.ordered,
    required this.descriptors,
    required this.mode,
    required this.keptLockedPositions,
  });

  BookFlowDescriptor descriptorFor(AppContent item) {
    return descriptors.firstWhere((descriptor) => descriptor.item.id == item.id);
  }
}

class BookFlowAnalyzer {
  static BookFlowPlan buildPlan(
    List<AppContent> items,
    BookFlowSortMode mode, {
    bool keepLockedPositions = true,
  }) {
    final raw = <BookFlowDescriptor>[];
    for (var index = 0; index < items.length; index++) {
      final item = items[index];
      final searchable = _searchableText(item);
      final structure = isBookFrontMatter(item.title, item.category)
          ? 0
          : isBookBackMatter(item.title, item.category)
              ? 2
              : 1;
      final theme = _themeTag(searchable);
      final geography = _geographyTag(searchable);
      raw.add(
        BookFlowDescriptor(
          item: item,
          originalIndex: index,
          proposedIndex: index,
          structureRank: structure,
          themeRank: theme.rank,
          geographyRank: geography.rank,
          reason: _reasonFor(item, searchable, structure, theme, geography),
        ),
      );
    }

    final sorted = [...raw]..sort((a, b) => _compare(a, b, mode));
    late final List<AppContent> ordered;

    if (keepLockedPositions && items.any((item) => item.locked)) {
      final slots = List<AppContent?>.filled(items.length, null);
      for (final descriptor in raw.where((entry) => entry.item.locked)) {
        slots[descriptor.originalIndex] = descriptor.item;
      }
      final movable = sorted.where((entry) => !entry.item.locked).map((entry) => entry.item).toList();
      var movableIndex = 0;
      for (var index = 0; index < slots.length; index++) {
        if (slots[index] == null) {
          slots[index] = movable[movableIndex];
          movableIndex++;
        }
      }
      ordered = slots.cast<AppContent>();
    } else {
      ordered = sorted.map((entry) => entry.item).toList();
    }

    final proposedById = <String, int>{};
    for (var index = 0; index < ordered.length; index++) {
      proposedById[ordered[index].id] = index;
    }

    return BookFlowPlan(
      ordered: ordered,
      descriptors: raw
          .map((descriptor) => descriptor.copyWith(proposedIndex: proposedById[descriptor.item.id] ?? descriptor.originalIndex))
          .toList(),
      mode: mode,
      keptLockedPositions: keepLockedPositions,
    );
  }

  static String _searchableText(AppContent item) {
    final body = item.body.length > 2400 ? item.body.substring(0, 2400) : item.body;
    return _normalizeBookLabelText('${item.title} ${item.category} ${item.summary} $body');
  }

  static bool _containsAny(String value, List<String> words) {
    for (final word in words) {
      if (value.contains(_normalizeBookLabelText(word))) return true;
    }
    return false;
  }

  static _BookFlowTag _themeTag(String text) {
    if (_containsAny(text, ['david icke', 'icke'])) {
      return const _BookFlowTag(100, 'Modern kuramsal başlangıç: David Icke');
    }
    if (_containsAny(text, ['reptilyan teorisi', 'reptilyanlar kimdir', 'modern reptilyan', 'komplo teorilerinde reptilyan'])) {
      return const _BookFlowTag(90, 'Kavram ve modern teori çerçevesi');
    }
    if (_containsAny(text, ['ubaid', 'ubeyd', 'el ubaid', 'al ubaid', 'oueili'])) {
      return const _BookFlowTag(210, 'Arkeolojik devam: Ubeyd figürleri');
    }
    if (_containsAny(text, ['anunnaki', 'anunakiler', 'nibiru', 'anu enlil enki'])) {
      return const _BookFlowTag(200, 'Köken anlatısı: Anunnakiler');
    }
    if (_containsAny(text, ['sumer', 'sümer', 'akad', 'akkad', 'babil', 'asir', 'asur', 'uruk', 'mezopotamya'])) {
      return const _BookFlowTag(230, 'Mezopotamya kaynakları ve arkeoloji');
    }
    if (_containsAny(text, ['yilan soyu', 'yılan soyu', 'ejderha', 'tuyli yilan', 'tüylü yılan', 'naga', 'medusa', 'sahmeran', 'şahmeran'])) {
      return const _BookFlowTag(320, 'Yılan ve sürüngen sembolizmi');
    }
    if (_containsAny(text, ['tapinagi', 'tapınağı', 'antik kent', 'kaya kilise', 'yer alti sehri', 'yeraltı şehri', 'arkeoloji', 'figür', 'kabartma'])) {
      return const _BookFlowTag(400, 'Yer ve arkeolojik bulgu odaklı bölüm');
    }
    if (_containsAny(text, ['ölüdeniz', 'olu deniz', 'leviathan', 'tevrat', 'incil', 'kur an', 'kuran', 'ayet', 'parşömen'])) {
      return const _BookFlowTag(500, 'Metinler ve dinî anlatılar');
    }
    if (_containsAny(text, ['ufo', 'paranormal', 'karsilasma', 'karşılaşma', 'fotografa yansiyan', 'fotoğrafa yansıyan', 'taniklik', 'tanıklık'])) {
      return const _BookFlowTag(650, 'Modern olaylar ve tanıklıklar');
    }
    if (_containsAny(text, ['enerjiden beslenme', 'dusuk enerji', 'düşük enerji', 'kan cizgisi', 'kan çizgisi', 'yonetici sinif', 'yönetici sınıf'])) {
      return const _BookFlowTag(720, 'Modern iddialar ve etkiler');
    }
    return const _BookFlowTag(450, 'Genel araştırma akışı');
  }

  static _BookFlowTag _geographyTag(String text) {
    if (_containsAny(text, ['david icke', 'modern reptilyan', 'komplo teorisi'])) {
      return const _BookFlowTag(10, 'Küresel / modern çerçeve');
    }
    if (_containsAny(text, ['anunnaki', 'ubaid', 'ubeyd', 'sumer', 'sümer', 'akad', 'babil', 'asur', 'uruk', 'mezopotamya', 'irak'])) {
      return const _BookFlowTag(100, 'Mezopotamya');
    }
    if (_containsAny(text, ['ölüdeniz', 'olu deniz', 'ugarit', 'kenan', 'leviathan', 'israil', 'filistin', 'levant'])) {
      return const _BookFlowTag(200, 'Levant ve Doğu Akdeniz');
    }
    if (_containsAny(text, ['misir', 'mısır', 'egypt', 'dendera', 'sobek', 'seth', 'giza'])) {
      return const _BookFlowTag(300, 'Mısır ve Kuzey Afrika');
    }
    if (_containsAny(text, ['hattusa', 'hattuşa', 'yazilikaya', 'yazılıkaya', 'hitit', 'kapadokya', 'derinkuyu', 'ihlara', 'goreme', 'göreme', 'corum', 'çorum'])) {
      return const _BookFlowTag(400, 'Orta Anadolu');
    }
    if (_containsAny(text, ['assos', 'parion', 'parium', 'troas', 'efes', 'ephesus', 'didim', 'milet', 'bergama', 'pergamon', 'myra', 'likya', 'iznik', 'anadolu'])) {
      return const _BookFlowTag(430, 'Batı ve Güney Anadolu');
    }
    if (_containsAny(text, ['atina', 'athena', 'yunan', 'greece', 'roma', 'roman', 'kilpeck', 'cocullo', 'avrupa'])) {
      return const _BookFlowTag(500, 'Yunan-Roma ve Avrupa');
    }
    if (_containsAny(text, ['hindistan', 'india', 'naga', 'hindu', 'cin', 'çin', 'japonya', 'asya'])) {
      return const _BookFlowTag(600, 'Güney ve Doğu Asya');
    }
    if (_containsAny(text, ['maya', 'aztek', 'chichen itza', 'quetzalcoatl', 'inca', 'peru', 'amerika'])) {
      return const _BookFlowTag(700, 'Amerika uygarlıkları');
    }
    if (_containsAny(text, ['ufo', 'paranormal', 'modern', 'guncel', 'güncel'])) {
      return const _BookFlowTag(800, 'Modern / küresel olaylar');
    }
    return const _BookFlowTag(450, 'Coğrafya belirsiz veya karma');
  }

  static String _reasonFor(
    AppContent item,
    String text,
    int structure,
    _BookFlowTag theme,
    _BookFlowTag geography,
  ) {
    if (structure == 0) return 'Ön bölüm olduğu için kitabın başında tutulur.';
    if (structure == 2) return 'Son söz, kaynakça veya ek olduğu için kitabın sonunda tutulur.';
    if (item.locked) return '${theme.label} • ${geography.label} • Kilitli bölüm';
    if (_containsAny(text, ['ubaid', 'ubeyd', 'el ubaid', 'al ubaid'])) {
      return 'Anunnaki/Sümer anlatısından sonra arkeolojik karşılık olarak önerildi.';
    }
    return '${theme.label} • ${geography.label}';
  }

  static int _compare(BookFlowDescriptor a, BookFlowDescriptor b, BookFlowSortMode mode) {
    final structure = a.structureRank.compareTo(b.structureRank);
    if (structure != 0) return structure;

    if (a.structureRank != 1) {
      return a.originalIndex.compareTo(b.originalIndex);
    }

    if (mode == BookFlowSortMode.geography) {
      final aFoundation = a.themeRank <= 230 ? 0 : 1;
      final bFoundation = b.themeRank <= 230 ? 0 : 1;
      final foundation = aFoundation.compareTo(bFoundation);
      if (foundation != 0) return foundation;
      if (aFoundation == 0) {
        final theme = a.themeRank.compareTo(b.themeRank);
        if (theme != 0) return theme;
      } else {
        final geography = a.geographyRank.compareTo(b.geographyRank);
        if (geography != 0) return geography;
        final theme = a.themeRank.compareTo(b.themeRank);
        if (theme != 0) return theme;
      }
    } else {
      final theme = a.themeRank.compareTo(b.themeRank);
      if (theme != 0) return theme;
      final geography = a.geographyRank.compareTo(b.geographyRank);
      if (geography != 0) return geography;
    }

    return a.originalIndex.compareTo(b.originalIndex);
  }
}

class AltayParanormalApp extends StatelessWidget {
  const AltayParanormalApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8A5A22);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gizem ve Paranormal Arşivim',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F1E6),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int selectedIndex = 0;
  bool loading = true;
  bool checkingSharedWord = false;
  List<AppContent> articles = [];
  List<AppContent> fieldNotes = [];
  List<AppContent> galleryItems = [];
  List<AppContent> bookChapters = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadData();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !loading) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _checkSharedWordFile();
      });
    }
  }

  Future<void> _loadData() async {
    final loadedArticles = await LocalStore.loadList(LocalStore.articlesKey, defaultArticles);
    final loadedFieldNotes = await LocalStore.loadList(LocalStore.fieldNotesKey, defaultFieldNotes);
    final loadedGallery = await LocalStore.loadList(LocalStore.galleryKey, defaultGalleryItems);
    final loadedBookRaw = await LocalStore.loadList(LocalStore.bookKey, defaultBookChapters);
    final loadedBook = loadedBookRaw.where((item) => !isBundledSampleBookChapter(item)).toList();
    if (loadedBook.length != loadedBookRaw.length) {
      await LocalStore.saveList(LocalStore.bookKey, loadedBook);
    }
    if (!mounted) return;
    setState(() {
      articles = loadedArticles;
      fieldNotes = loadedFieldNotes;
      galleryItems = loadedGallery;
      bookChapters = loadedBook;
      loading = false;
    });

    // Uygulama normal açılırsa sessiz kalır; yalnızca Word/PDF/TXT paylaşılmışsa ekleme penceresi açılır.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _checkSharedWordFile();
    });
  }

  Future<void> _checkSharedWordFile() async {
    if (checkingSharedWord) return;
    checkingSharedWord = true;

    try {
      final sharedFiles = await ExternalDocumentImporter.takeSharedFiles();
      if (sharedFiles.isEmpty) return;

      if (!mounted) return;
      setState(() => selectedIndex = 3);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            sharedFiles.length == 1
                ? 'Dosya alındı. Word/PDF/TXT içeriği okunuyor...'
                : '${sharedFiles.length} dosya alındı. Word/PDF/TXT içerikleri okunuyor...',
          ),
        ),
      );

      final batch = await ExternalDocumentImporter.importFiles(sharedFiles);
      if (!mounted) return;

      if (batch.chapters.isEmpty) {
        final failed = batch.failedFiles.isEmpty ? '' : '\nOkunamayan: ${batch.failedFiles.join(', ')}';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Paylaşılan dosyalarda eklenebilir bölüm bulunamadı.$failed')),
        );
        return;
      }

      final typeSummary = <String>[
        if (batch.wordFileCount > 0) '${batch.wordFileCount} Word',
        if (batch.pdfFileCount > 0) '${batch.pdfFileCount} PDF',
        if (batch.textFileCount > 0) '${batch.textFileCount} TXT',
      ].join(' • ');

      final numberedCount = batch.chapters.where((item) => explicitBookChapterNumber(item) != null).length;
      final add = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('${batch.receivedFileCount} dosyada ${batch.chapters.length} bölüm bulundu'),
          content: Text(
            '${typeSummary.isEmpty ? 'Belgeler' : typeSummary} içe aktarılacak. '
            'Bölümler mevcut listenin sonuna ayrı ayrı eklenecek; mevcut bölümler silinmez.'
            '${numberedCount > 0 ? '\n\n$numberedCount bölüm, üzerindeki bölüm numarasına göre otomatik sıralandı.' : ''}'
            '${batch.unreadableFileCount > 0 ? '\n\n${batch.unreadableFileCount} dosya okunamadı: ${batch.failedFiles.join(', ')}' : ''}'
            '${batch.pdfFileCount > 0 ? '\n\nPDF sayfaları yerleşimi ve görselleri korunması için tam sayfa görsel olarak alınır.' : ''}',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Bölümleri ekle')),
          ],
        ),
      );

      if (add != true) return;
      if (bookChapters.isEmpty) {
        await _replaceBookChapters(batch.chapters);
      } else {
        await _appendBookChapters(batch.chapters);
      }

      if (!mounted) return;
      setState(() => selectedIndex = 3);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${batch.chapters.length} bölüm eklendi.${numberedCount > 0 ? ' Bölüm numaralarına göre sıralandı.' : ''} Mevcut bölümler silinmedi.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Paylaşılan dosyalar alınamadı: $e')),
      );
    } finally {
      checkingSharedWord = false;
    }
  }

  Future<void> _saveAll() async {
    await LocalStore.saveList(LocalStore.articlesKey, articles);
    await LocalStore.saveList(LocalStore.fieldNotesKey, fieldNotes);
    await LocalStore.saveList(LocalStore.galleryKey, galleryItems);
    await LocalStore.saveList(LocalStore.bookKey, bookChapters);
  }

  List<AppContent> _listForType(String type) {
    switch (type) {
      case ContentTypes.article:
        return articles;
      case ContentTypes.field:
        return fieldNotes;
      case ContentTypes.gallery:
        return galleryItems;
      case ContentTypes.book:
        return bookChapters;
      default:
        return articles;
    }
  }

  Future<void> _replaceList(String type, List<AppContent> list) async {
    setState(() {
      if (type == ContentTypes.article) articles = list;
      if (type == ContentTypes.field) fieldNotes = list;
      if (type == ContentTypes.gallery) galleryItems = list;
      if (type == ContentTypes.book) bookChapters = list;
    });
    await _saveAll();
  }

  Future<void> _addItem(AppContent item) async {
    final list = [..._listForType(item.type), item];
    await _replaceList(item.type, list);
  }

  Future<void> _updateItem(AppContent item) async {
    final list = _listForType(item.type)
        .map((existing) => existing.id == item.id ? item : existing)
        .toList();
    await _replaceList(item.type, list);
  }


  Future<void> _replaceBookChapters(List<AppContent> chapters) async {
    await _replaceList(ContentTypes.book, chapters);
  }

  Future<void> _appendBookChapters(List<AppContent> chapters) async {
    await _replaceList(ContentTypes.book, [...bookChapters, ...chapters]);
  }

  Future<void> _deleteItem(AppContent item) async {
    final list = _listForType(item.type).where((existing) => existing.id != item.id).toList();
    await _replaceList(item.type, list);
  }

  Future<void> _resetData() async {
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
      bookChapters = [...defaultBookChapters];
    });
    await _saveAll();
  }

  String _exportData() {
    return const JsonEncoder.withIndent('  ').convert({
      'articles': articles.map((item) => item.toJson()).toList(),
      'fieldNotes': fieldNotes.map((item) => item.toJson()).toList(),
      'gallery': galleryItems.map((item) => item.toJson()).toList(),
      'book': bookChapters.map((item) => item.toJson()).toList(),
    });
  }

  Future<void> _importData(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Yedek metni geçerli değil.');
    }
    final newArticles = LocalStore.decodeList(decoded['articles'], ContentTypes.article);
    final newFieldNotes = LocalStore.decodeList(decoded['fieldNotes'], ContentTypes.field);
    final newGallery = LocalStore.decodeList(decoded['gallery'], ContentTypes.gallery);
    final newBook = LocalStore.decodeList(decoded['book'], ContentTypes.book);
    setState(() {
      articles = newArticles.isEmpty ? articles : newArticles;
      fieldNotes = newFieldNotes.isEmpty ? fieldNotes : newFieldNotes;
      galleryItems = newGallery.isEmpty ? galleryItems : newGallery;
      bookChapters = newBook.isEmpty ? bookChapters : newBook;
    });
    await _saveAll();
  }

  void _openAdmin({int initialTabIndex = 0}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AdminPage(
          initialTabIndex: initialTabIndex,
          articles: articles,
          fieldNotes: fieldNotes,
          galleryItems: galleryItems,
          bookChapters: bookChapters,
          onAdd: _addItem,
          onUpdate: _updateItem,
          onDelete: _deleteItem,
          onReset: _resetData,
          exportData: _exportData,
          importData: _importData,
        ),
      ),
    );
  }


  Future<void> _openQuickEditor(AppContent item) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: item.type, item: item),
    );
    if (result == null) return;
    await _updateItem(result);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Değişiklik kaydedildi.')));
  }

  void _openAbout() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutPage()));
  }

  void _openContact() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ContactPage()));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final pages = [
      HomePage(
        articlesCount: articles.length,
        fieldCount: fieldNotes.length,
        galleryCount: galleryItems.length,
        onOpenAdmin: () => _openAdmin(),
      ),
      ArticlesPage(items: articles, onEdit: _openQuickEditor, onDelete: _deleteItem),
      FieldNotesPage(
        fieldItems: fieldNotes,
        galleryItems: galleryItems,
        onOpenFieldAdmin: () => _openAdmin(initialTabIndex: 1),
        onOpenGalleryAdmin: () => _openAdmin(initialTabIndex: 2),
        onEdit: _openQuickEditor,
        onDelete: _deleteItem,
      ),
      BookPage(items: bookChapters, onOpenBookAdmin: () => _openAdmin(initialTabIndex: 3), onEdit: _openQuickEditor, onDelete: _deleteItem, onReplaceBookChapters: _replaceBookChapters, onAppendBookChapters: _appendBookChapters),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gizem ve Paranormal Arşivim'),
        actions: [
          IconButton(
            tooltip: 'Yönetim',
            onPressed: () => _openAdmin(),
            icon: const Icon(Icons.admin_panel_settings_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'about') _openAbout();
              if (value == 'contact') _openContact();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'about', child: Text('Hakkımda')),
              PopupMenuItem(value: 'contact', child: Text('İletişim')),
            ],
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: pages[selectedIndex],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana'),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Yazılar'),
          NavigationDestination(icon: Icon(Icons.travel_explore_outlined), selectedIcon: Icon(Icons.travel_explore), label: 'Saha'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Kitap'),
        ],
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int articlesCount;
  final int fieldCount;
  final int galleryCount;
  final VoidCallback onOpenAdmin;

  const HomePage({
    super.key,
    required this.articlesCount,
    required this.fieldCount,
    required this.galleryCount,
    required this.onOpenAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const HeroHeader(),
        const SizedBox(height: 12),
        const VersionBanner(),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: onOpenAdmin,
          icon: const Icon(Icons.edit_note),
          label: const Text('Yönetim paneli: yazı, saha notu ve galeri ekle'),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: CounterCard(title: 'Yazı', value: articlesCount.toString(), icon: Icons.article_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Saha', value: fieldCount.toString(), icon: Icons.travel_explore_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Galeri', value: galleryCount.toString(), icon: Icons.photo_library_outlined)),
          ],
        ),
        const SizedBox(height: 18),
        Text('Öne Çıkan Dosyalar', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: const [
            FeatureCard(icon: Icons.public, title: 'UFO Dosyaları', subtitle: 'Gözlem, rapor ve olay notları'),
            FeatureCard(icon: Icons.account_balance, title: 'Antik Medeniyetler', subtitle: 'Tapınaklar, semboller, mitler'),
            FeatureCard(icon: Icons.terrain, title: 'Saha Geçmişi', subtitle: 'Hattuşa, Yazılıkaya, Efes, Myra'),
            FeatureCard(icon: Icons.auto_stories, title: 'Kitap Projesi', subtitle: 'Antik Medeniyetlerde Reptilyanların İzinde'),
          ],
        ),
        const SizedBox(height: 18),
        const InfoPanel(
          title: 'Bu sürümde ne var?',
          text:
              'Bu 5. sürümde yazı ve galeri detayları artık yarım açılan pencere yerine tam sayfa açılır. Makale, saha notu ve galeri görseli ekleyebilir, düzenleyebilir ve silebilirsin. Kayıtlar telefonda saklanır. Yedek almayı unutma.',
        ),
      ],
    );
  }
}


class VersionBanner extends StatelessWidget {
  const VersionBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: scheme.tertiaryContainer,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        children: [
          Icon(Icons.verified_outlined, color: scheme.onTertiaryContainer),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '$appVersionLabel aktif. Yazılar artık tam sayfa açılır; galeri ekleme butonu görünür.',
              style: TextStyle(
                color: scheme.onTertiaryContainer,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CounterCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const CounterCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C))),
          ],
        ),
      ),
    );
  }
}

class HeroHeader extends StatelessWidget {
  const HeroHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [scheme.primaryContainer, scheme.secondaryContainer],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.explore, size: 44, color: scheme.onPrimaryContainer),
          const SizedBox(height: 18),
          Text(
            'Gizem, UFO ve Paranormal Araştırman\nAltay Aytın',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            'Anadolu sahalarından antik sembollere, mitolojik anlatılardan modern gizem dosyalarına uzanan bağımsız araştırma arşivi.',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const FeatureCard({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width > 700 ? 260 : double.infinity,
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(child: Icon(icon)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(subtitle),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ArticlesPage extends StatefulWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const ArticlesPage({super.key, required this.items, required this.onEdit, this.onDelete});

  @override
  State<ArticlesPage> createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  final controller = TextEditingController();
  String query = '';

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.items.where((item) {
      final q = query.toLowerCase().trim();
      if (q.isEmpty) return true;
      return item.title.toLowerCase().contains(q) ||
          item.summary.toLowerCase().contains(q) ||
          item.category.toLowerCase().contains(q) ||
          item.body.toLowerCase().contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 120),
      children: [
        Text('Yazılar', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(
          controller: controller,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            labelText: 'Yazılarda ara',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) => setState(() => query = value),
        ),
        const SizedBox(height: 12),
        for (final article in filtered) ContentTile(item: article, onEdit: widget.onEdit, onDelete: widget.onDelete),
        if (filtered.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('Bu aramada sonuç bulunamadı.')),
          ),
      ],
    );
  }
}

class ContentTile extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const ContentTile({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kayıt silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    final subtitle = [
      if (item.category.trim().isNotEmpty) item.category.trim(),
      if (item.summary.trim().isNotEmpty) item.summary.trim(),
    ].join(' • ');

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ContentDetailPage(item: item, onEdit: onEdit, onDelete: onDelete)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(child: Icon(item.icon)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, height: 1.25),
                        ),
                        if (subtitle.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            subtitle,
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.35),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.chevron_right),
                ],
              ),
              if (onEdit != null || onDelete != null) ...[
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (onEdit != null)
                      TextButton.icon(
                        onPressed: () => onEdit!(item),
                        icon: const Icon(Icons.edit_outlined),
                        label: const Text('Düzenle'),
                      ),
                    if (onDelete != null) ...[
                      const SizedBox(width: 8),
                      TextButton.icon(
                        onPressed: () => _confirmDelete(context),
                        icon: const Icon(Icons.delete_outline),
                        label: const Text('Sil'),
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class ContentDetailPage extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const ContentDetailPage({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kayıt silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_shortTitle(item.title)),
        actions: [
          if (onEdit != null)
            IconButton(
              tooltip: 'Bu kaydı düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => onEdit!(item),
            ),
          if (onDelete != null)
            IconButton(
              tooltip: 'Bu kaydı sil',
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _confirmDelete(context),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            item.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (item.category.trim().isNotEmpty) Chip(label: Text(item.category)),
              if (item.summary.trim().isNotEmpty) Chip(label: Text(item.summary)),
            ],
          ),
          const SizedBox(height: 18),
          SelectableText(
            item.body.trim().isEmpty ? 'Bu kayıt için henüz uzun metin eklenmemiş.' : item.body,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.55),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  static String _shortTitle(String value) {
    final clean = value.trim();
    if (clean.length <= 24) return clean;
    return '${clean.substring(0, 24)}...';
  }
}

class FieldNotesPage extends StatelessWidget {
  final List<AppContent> fieldItems;
  final List<AppContent> galleryItems;
  final VoidCallback onOpenFieldAdmin;
  final VoidCallback onOpenGalleryAdmin;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const FieldNotesPage({
    super.key,
    required this.fieldItems,
    required this.galleryItems,
    required this.onOpenFieldAdmin,
    required this.onOpenGalleryAdmin,
    required this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      children: [
        Text(
          'Saha ve Galeri',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text('Saha notlarını ve gerçek/telifsiz görsellerini aynı bölümden yönet.'),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            FilledButton.icon(
              onPressed: onOpenFieldAdmin,
              icon: const Icon(Icons.edit_note_outlined),
              label: const Text('Saha notu ekle'),
            ),
            FilledButton.tonalIcon(
              onPressed: onOpenGalleryAdmin,
              icon: const Icon(Icons.add_photo_alternate_outlined),
              label: const Text('Görsel yükle'),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            const Icon(Icons.travel_explore_outlined),
            const SizedBox(width: 8),
            Text('Saha Notlarım', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 10),
        if (fieldItems.isEmpty)
          const EmptyPanel(text: 'Henüz saha notu yok. “Saha notu ekle” butonuyla ekleyebilirsin.')
        else
          for (final note in fieldItems) ContentTile(item: note, onEdit: onEdit, onDelete: onDelete),
        const SizedBox(height: 20),
        Row(
          children: [
            const Icon(Icons.photo_library_outlined),
            const SizedBox(width: 8),
            Text('Saha Görsellerim', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 8),
        const Text('Gerçek fotoğraf, açık lisanslı veya izinli görselleri burada tut.'),
        const SizedBox(height: 12),
        if (galleryItems.isEmpty)
          const EmptyPanel(text: 'Henüz görsel yok. “Görsel yükle” butonuyla ekleyebilirsin.')
        else
          GridView.builder(
            itemCount: galleryItems.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.74,
            ),
            itemBuilder: (context, index) => GalleryCard(item: galleryItems[index], onEdit: onEdit, onDelete: onDelete),
          ),
      ],
    );
  }
}

class GalleryPage extends StatelessWidget {
  final List<AppContent> items;
  final VoidCallback onOpenGalleryAdmin;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const GalleryPage({
    super.key,
    required this.items,
    required this.onOpenGalleryAdmin,
    required this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      children: [
        Text('Galeri', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Gerçek, telifsiz, kamu malı veya izinli görseller için ayrıldı. Görsel eklemek için aşağıdaki butona bas.'),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: onOpenGalleryAdmin,
          icon: const Icon(Icons.add_photo_alternate_outlined),
          label: const Text('Galeriye görsel ekle / düzenle'),
        ),
        const SizedBox(height: 14),
        GridView.builder(
          itemCount: items.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.74,
          ),
          itemBuilder: (context, index) => GalleryCard(item: items[index], onEdit: onEdit, onDelete: onDelete),
        ),
        if (items.isEmpty) const EmptyPanel(text: 'Henüz galeri kaydı yok. Yönetim panelinden ekleyebilirsin.'),
      ],
    );
  }
}

class GalleryCard extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const GalleryCard({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Galeri kaydı silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _openDetails(context),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: scheme.outlineVariant),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: GalleryImage(item: item, fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, height: 1.15),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    item.summary,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C), height: 1.2),
                  ),
                  const SizedBox(height: 1),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (onEdit != null)
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'Düzenle',
                          onPressed: () => onEdit!(item),
                          icon: const Icon(Icons.edit_outlined, size: 18),
                        ),
                      if (onDelete != null)
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'Sil',
                          onPressed: () => _confirmDelete(context),
                          icon: const Icon(Icons.delete_outline, size: 18),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openDetails(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GalleryDetailPage(item: item, onEdit: onEdit, onDelete: onDelete)),
    );
  }
}

class GalleryDetailPage extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const GalleryDetailPage({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Galeri kaydı silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_shortTitle(item.title)),
        actions: [
          if (onEdit != null)
            IconButton(
              tooltip: 'Galeri kaydını düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => onEdit!(item),
            ),
          if (onDelete != null)
            IconButton(
              tooltip: 'Galeri kaydını sil',
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _confirmDelete(context),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (item.hasImage)
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                constraints: const BoxConstraints(minHeight: 260),
                child: GalleryImage(item: item, fit: BoxFit.contain),
              ),
            )
          else
            const EmptyPanel(text: 'Bu galeri kaydında henüz fotoğraf yok.'),
          const SizedBox(height: 18),
          Text(
            item.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          if (item.summary.trim().isNotEmpty)
            Text(item.summary, style: Theme.of(context).textTheme.bodyLarge),
          if (item.source.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            SelectableText('Kaynak: ${item.source}', style: Theme.of(context).textTheme.bodyMedium),
          ],
          if (item.body.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            SelectableText(item.body, style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.5)),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  static String _shortTitle(String value) {
    final clean = value.trim();
    if (clean.length <= 24) return clean;
    return '${clean.substring(0, 24)}...';
  }
}

class GalleryImage extends StatelessWidget {
  final AppContent item;
  final BoxFit fit;

  const GalleryImage({super.key, required this.item, required this.fit});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final localPath = item.imagePath.trim();
    if (localPath.isNotEmpty && !kIsWeb) {
      final file = File(localPath);
      if (file.existsSync()) {
        return Image.file(
          file,
          width: double.infinity,
          fit: fit,
          errorBuilder: (context, error, stackTrace) => Center(
            child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
          ),
        );
      }
    }

    final url = item.imageUrl.trim();
    if (url.isNotEmpty) {
      return Image.network(
        url,
        width: double.infinity,
        fit: fit,
        errorBuilder: (context, error, stackTrace) => Center(
          child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
        ),
      );
    }

    return Center(child: Icon(Icons.image_outlined, size: 46, color: scheme.primary));
  }
}


class BookPage extends StatefulWidget {
  final List<AppContent> items;
  final VoidCallback onOpenBookAdmin;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item) onDelete;
  final Future<void> Function(List<AppContent> chapters) onReplaceBookChapters;
  final Future<void> Function(List<AppContent> chapters) onAppendBookChapters;

  const BookPage({
    super.key,
    required this.items,
    required this.onOpenBookAdmin,
    required this.onEdit,
    required this.onDelete,
    required this.onReplaceBookChapters,
    required this.onAppendBookChapters,
  });

  @override
  State<BookPage> createState() => _BookPageState();
}

class _BookPageState extends State<BookPage> {
  static const _reorderSpeedPreferenceKey = 'book_reorder_speed_v1';

  String activeBookTab = 'bolumler';
  String operationStatus = 'Hazır. Word dosyasını paylaşınca veya Word yükleye basınca bölümler eklenir.';
  double _reorderSpeed = 4.0;
  bool _chapterSelectionMode = false;
  final Set<String> _selectedChapterIds = <String>{};
  bool _publisherPackageBusy = false;
  final ValueNotifier<String> _publisherPackageProgress = ValueNotifier<String>('Hazırlanıyor...');

  BookStats get stats => BookStats.from(widget.items);

  @override
  void initState() {
    super.initState();
    _loadReorderSpeed();
  }

  @override
  void dispose() {
    _publisherPackageProgress.dispose();
    super.dispose();
  }

  Future<void> _loadReorderSpeed() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getDouble(_reorderSpeedPreferenceKey) ?? 4.0;
    if (!mounted) return;
    setState(() => _reorderSpeed = saved);
  }

  String get _reorderSpeedLabel {
    if (_reorderSpeed <= 2.5) return 'Yavaş';
    if (_reorderSpeed <= 5.0) return 'Normal';
    if (_reorderSpeed <= 9.0) return 'Hızlı';
    return 'Çok hızlı';
  }

  bool _hasSourceOrLicense(AppContent item) {
    final value = '${item.source}\n${item.body}\n${item.summary}'.toLowerCase();
    return item.source.trim().isNotEmpty ||
        value.contains('kaynak:') ||
        value.contains('lisans:') ||
        value.contains('wikimedia commons') ||
        value.contains('public domain') ||
        value.contains('creative commons') ||
        value.contains('cc by') ||
        value.contains('cc-by') ||
        value.contains('museum') ||
        value.contains('müze') ||
        value.contains('library') ||
        value.contains('kütüphane');
  }


  List<AppContent>? _undoBookSnapshot;
  String _undoReason = '';

  bool get _canUndoBookChange => _undoBookSnapshot != null && _undoBookSnapshot!.isNotEmpty;

  Future<void> _applyBookReplacement(List<AppContent> newItems, String status, {bool rememberUndo = true}) async {
    if (rememberUndo) {
      _undoBookSnapshot = [...widget.items];
      _undoReason = status;
    }
    await widget.onReplaceBookChapters(newItems);
    if (!mounted) return;
    final validIds = newItems.map((item) => item.id).toSet();
    setState(() {
      _selectedChapterIds.removeWhere((id) => !validIds.contains(id));
      if (_selectedChapterIds.isEmpty) _chapterSelectionMode = false;
      activeBookTab = 'bolumler';
      operationStatus = status;
    });
  }

  Future<void> _applyBookAppend(List<AppContent> chapters, String status) async {
    await _applyBookReplacement([...widget.items, ...chapters], status);
  }

  Future<void> _undoLastBookChange() async {
    final snapshot = _undoBookSnapshot;
    if (snapshot == null || snapshot.isEmpty) return;

    _undoBookSnapshot = null;
    await widget.onReplaceBookChapters(snapshot);
    if (!mounted) return;
    setState(() {
      activeBookTab = 'bolumler';
      operationStatus = 'Son işlem geri alındı. $_undoReason';
      _undoReason = '';
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Son bölüm işlemi geri alındı.')));
  }

  Future<void> _exportPublisherPackage(BuildContext context) async {
    if (widget.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce bölüm ekle.')));
      return;
    }
    if (_publisherPackageBusy) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yayınevi paketi zaten hazırlanıyor. İşlem tamamlanana kadar bekleyin.')),
      );
      return;
    }

    setState(() {
      _publisherPackageBusy = true;
      operationStatus = 'Yayınevi paketi başlatılıyor...';
    });
    _publisherPackageProgress.value = 'Düzenlenebilir Word ve baskıya hazır PDF hazırlanıyor...';

    var progressDialogOpen = true;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: const Text('Yayınevi paketi hazırlanıyor'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 18),
              ValueListenableBuilder<String>(
                valueListenable: _publisherPackageProgress,
                builder: (context, value, _) => Text(value, textAlign: TextAlign.center),
              ),
              const SizedBox(height: 10),
              const Text(
                'Paket yalnızca iki dosya içerir: görselleri içine gömülü düzenlenebilir Word ve baskıya hazır PDF.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        ),
      ),
    );
    await Future<void>.delayed(const Duration(milliseconds: 120));

    void closeProgressDialog() {
      if (!progressDialogOpen || !context.mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      progressDialogOpen = false;
    }

    try {
      try {
        await docxPickerChannel.invokeMethod<void>('setExportActive', <String, Object>{'active': true});
      } catch (_) {}

      _publisherPackageProgress.value = 'Dosyalar ve görseller kontrol ediliyor...';
      final issues = await BookExporter.validatePublisherPackage(
        widget.items,
        onProgress: (message, current, total) {
          final rawPercent = total <= 0 ? 0.0 : ((current / total) * 100).clamp(0, 100).toDouble();
          final percent = current >= total ? 100 : rawPercent.floor().clamp(0, 99);
          _publisherPackageProgress.value = '$message\n%$percent tamamlandı';
        },
      );
      if (issues.isNotEmpty) {
        closeProgressDialog();
        if (!context.mounted) return;
        setState(() => operationStatus = 'Yayınevi paketi başlamadı: ${issues.length} sorun bulundu.');
        await showDialog<void>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Önce düzeltilmesi gerekenler'),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: issues.length,
                separatorBuilder: (_, __) => const Divider(height: 16),
                itemBuilder: (_, index) => Text('• ${issues[index]}'),
              ),
            ),
            actions: [FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Tamam'))],
          ),
        );
        return;
      }

      final file = await BookExporter.createPublisherPackage(
        widget.items,
        fileName: 'Altay_Aytin_Yayinevi_Paketi',
        onProgress: (message, current, total) {
          final rawPercent = total <= 0 ? 0.0 : ((current / total) * 100).clamp(0, 100).toDouble();
          final percent = current >= total ? 100 : rawPercent.floor().clamp(0, 99);
          _publisherPackageProgress.value = '$message\n%$percent tamamlandı';
        },
      );

      final sizeMb = (await file.length()) / (1024 * 1024);
      _publisherPackageProgress.value = 'Yayınevi paketi Download/AltayParanormal klasörüne kaydediliyor...\n%100 tamamlandı';
      final savedResult = await _saveCreatedFileToDownloads(file, showError: false);
      if (savedResult == null) throw Exception('Paket hazırlandı ancak Download klasörüne kaydedilemedi.');
      closeProgressDialog();
      if (!context.mounted) return;
      final location = savedResult['location']?.toString().trim();
      setState(() {
        operationStatus = location == null || location.isEmpty
            ? 'Yayınevi paketi hazır ve Download klasörüne kaydedildi.'
            : 'Yayınevi paketi hazır: $location';
      });
      await _showSavedFileDialog(
        context,
        file,
        savedResult,
        'Görselleri içine gömülü düzenlenebilir tam Word + baskıya hazır tam PDF',
        sizeMb: sizeMb,
      );
    } catch (e) {
      closeProgressDialog();
      if (!context.mounted) return;
      setState(() => operationStatus = 'Yayınevi paketi oluşturulamadı. Hata: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Yayınevi paketi oluşturulamadı: $e'), duration: const Duration(seconds: 10)),
      );
    } finally {
      try { await docxPickerChannel.invokeMethod<void>('setExportActive', <String, Object>{'active': false}); } catch (_) {}
      if (mounted) setState(() => _publisherPackageBusy = false);
    }
  }


  String _exportMimeType(File file) {
    final lowerPath = file.path.toLowerCase();
    if (lowerPath.endsWith('.zip')) return 'application/zip';
    if (lowerPath.endsWith('.docx')) {
      return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    }
    if (lowerPath.endsWith('.pdf')) return 'application/pdf';
    return 'application/octet-stream';
  }

  Future<Map<String, dynamic>?> _saveCreatedFileToDownloads(
    File file, {
    bool showError = true,
  }) async {
    try {
      final result = await docxPickerChannel.invokeMapMethod<String, dynamic>(
        'saveExportToDownloads',
        <String, Object>{
          'path': file.path,
          'mimeType': _exportMimeType(file),
          'suggestedName': file.uri.pathSegments.isEmpty
              ? 'Altay_Paranormal_Dosya'
              : file.uri.pathSegments.last,
        },
      );
      if (result == null) return null;
      return Map<String, dynamic>.from(result);
    } on MissingPluginException {
      if (showError) {
        // Eski APK kullanılıyorsa kullanıcı dosyayı yine kaybedemez.
        return null;
      }
      return null;
    } catch (error) {
      if (showError && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Download klasörüne kaydedilemedi: $error')),
        );
      }
      return null;
    }
  }

  Future<bool> _saveCreatedFileToChosenLocation(
    BuildContext context,
    File file,
  ) async {
    try {
      final result = await docxPickerChannel.invokeMapMethod<String, dynamic>(
        'saveExportFile',
        <String, Object>{
          'path': file.path,
          'mimeType': _exportMimeType(file),
          'suggestedName': file.uri.pathSegments.isEmpty
              ? 'Altay_Paranormal_Dosya'
              : file.uri.pathSegments.last,
        },
      );
      if (result == null) return false;
      if (!context.mounted) return true;
      final savedName = result['name']?.toString().trim();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            savedName == null || savedName.isEmpty
                ? 'Dosya seçtiğiniz konuma kaydedildi.'
                : '$savedName seçtiğiniz konuma kaydedildi.',
          ),
          duration: const Duration(seconds: 5),
        ),
      );
      return true;
    } on MissingPluginException {
      return false;
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Kaydetme penceresi açılamadı: $error')),
        );
      }
      return false;
    }
  }

  Future<void> _shareFileDirectly(
    BuildContext context,
    File file,
    String label,
  ) async {
    try {
      await Share.shareXFiles(
        <XFile>[XFile(file.path, mimeType: _exportMimeType(file))],
        text: label,
      );
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: file.path));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Paylaşım ekranı açılamadı. Geçici dosya yolu panoya kopyalandı.'),
        ),
      );
    }
  }

  Future<void> _showSavedFileDialog(
    BuildContext context,
    File file,
    Map<String, dynamic> savedResult,
    String label, {
    double? sizeMb,
  }) async {
    if (!context.mounted) return;
    final name = savedResult['name']?.toString().trim();
    final location = savedResult['location']?.toString().trim();
    final displayName = name == null || name.isEmpty ? file.uri.pathSegments.last : name;
    final displayLocation = location == null || location.isEmpty
        ? 'Download/AltayParanormal/$displayName'
        : location;
    final shareToo = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Dosya kaydedildi'),
        content: SelectableText(
          sizeMb == null
              ? '$displayName hazır.\n\nKonum:\n$displayLocation'
              : '$displayName hazır (${sizeMb.toStringAsFixed(1)} MB).\n\nKonum:\n$displayLocation',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Tamam'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            icon: const Icon(Icons.share_outlined),
            label: const Text('Paylaş'),
          ),
        ],
      ),
    );
    if (shareToo == true && context.mounted) {
      await _shareFileDirectly(context, file, label);
    }
  }

  Future<void> _shareCreatedFile(BuildContext context, File file, String label) async {
    if (!await file.exists() || await file.length() == 0) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Oluşturulan dosya bulunamadı veya boş.')),
      );
      return;
    }

    final savedResult = await _saveCreatedFileToDownloads(file);
    if (!context.mounted) return;
    if (savedResult != null) {
      await _showSavedFileDialog(context, file, savedResult, label);
      return;
    }

    // Çok eski Android bileşenlerinde son çare olarak klasik konum seçici açılır.
    final saved = await _saveCreatedFileToChosenLocation(context, file);
    if (!context.mounted) return;
    if (saved) return;

    final action = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Dosya hazır'),
        content: Text(
          '${file.uri.pathSegments.last} oluşturuldu ancak otomatik kayıt açılamadı.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop('close'),
            child: const Text('Kapat'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.of(dialogContext).pop('share'),
            icon: const Icon(Icons.share_outlined),
            label: const Text('Paylaş'),
          ),
        ],
      ),
    );
    if (action == 'share' && context.mounted) {
      await _shareFileDirectly(context, file, label);
    }
  }

  Future<void> _exportWord(BuildContext context) async {
    if (widget.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce kitap bölümü ekle.')));
      return;
    }
    try {
      final file = await BookExporter.createDocx(widget.items);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'Tam Word dosyası hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Word dosyası oluşturulamadı: $e')));
    }
  }

  Future<void> _exportPdf(BuildContext context) async {
    if (widget.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce kitap bölümü ekle.')));
      return;
    }
    try {
      final file = await BookExporter.createPdf(widget.items);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'Tam PDF dosyası hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF dosyası oluşturulamadı: $e')));
    }
  }

  final RegExp _writerVisualMarker = RegExp(
    r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*\d*\s*(?::\s*.*)?\]?)\s*$',
    caseSensitive: false,
  );

  String _visualLockToken(int number) => '[[GÖRSEL_KİLİT_$number]]';

  String _writerBodyOf(AppContent item) => item.body.trim().isEmpty ? item.summary.trim() : item.body.trim();

  List<String> _extractVisualLocks(String body) {
    final locks = <String>[];
    for (final line in body.split('\n')) {
      final clean = line.trim();
      if (_writerVisualMarker.hasMatch(clean)) {
        // Eski sürümden kayıtlı token varsa gerçek görsel işaretine çevir.
        locks.add('görsel');
      }
    }
    return locks;
  }

  List<String> _visualLocksForItem(AppContent item) {
    final bodyLocks = _extractVisualLocks(_writerBodyOf(item));
    if (bodyLocks.isNotEmpty) return bodyLocks;

    // Bazı kayıtlarda görsel dosyası vardır ama metinde "görsel" satırı kalmamıştır.
    // Bu durumda görseller kaybolmasın diye mevcut metin içi görsel sayısı kadar kilit oluştur.
    return List<String>.generate(item.cleanInlineImagePaths.length, (_) => 'görsel');
  }

  String _protectBodyVisualLocks(String body) {
    var number = 1;
    final lines = <String>[];
    for (final line in body.split('\n')) {
      final clean = line.trim();
      if (_writerVisualMarker.hasMatch(clean)) {
        lines.add(_visualLockToken(number));
        number++;
      } else {
        lines.add(line);
      }
    }
    return lines.join('\n').trim();
  }

  String _protectedBodyForWriter(AppContent item) {
    final body = _writerBodyOf(item);
    final bodyLocks = _extractVisualLocks(body);
    if (bodyLocks.isNotEmpty) return _protectBodyVisualLocks(body);

    final locks = _visualLocksForItem(item);
    if (locks.isEmpty) return body;

    final buffer = StringBuffer(body.trim());
    for (var i = 0; i < locks.length; i++) {
      buffer.writeln();
      buffer.writeln();
      buffer.writeln(_visualLockToken(i + 1));
    }
    return buffer.toString().trim();
  }

  int _visualMarkerCount(String body) {
    return body.split('\n').where((line) => _writerVisualMarker.hasMatch(line.trim())).length;
  }

  bool _generatedKeepsVisualLocks(String generated, int lockCount) {
    // Bu sürümde ChatGPT kilitleri unutsa bile uygulama eksik görsel satırlarını geri ekler.
    return true;
  }

  String _restoreVisualLocks(String generated, List<String> locks) {
    final lines = <String>[];
    var normalMarkerIndex = 0;

    for (final rawLine in generated.trim().split('\n')) {
      var line = rawLine;
      for (var i = 0; i < locks.length; i++) {
        line = line.replaceAll(_visualLockToken(i + 1), locks[i]);
      }

      final clean = line.trim();
      if (_writerVisualMarker.hasMatch(clean)) {
        if (normalMarkerIndex < locks.length) {
          lines.add(locks[normalMarkerIndex]);
          normalMarkerIndex++;
        } else {
          lines.add('görsel');
        }
      } else {
        lines.add(line);
      }
    }

    var result = lines.join('\n').trim();

    // Kalan kilit token'ları asla okuyucuda yazı olarak kalmasın.
    result = result.replaceAll(RegExp(r'\[\[GÖRSEL_KİLİT_\d+\]\]'), 'görsel');

    return result.trim();
  }

  String _normalizeVisualResult(String generated, List<String> locks) {
    var result = _restoreVisualLocks(generated, locks);
    final currentCount = _visualMarkerCount(result);

    if (currentCount < locks.length) {
      final buffer = StringBuffer(result.trim());
      for (var i = currentCount; i < locks.length; i++) {
        buffer.writeln();
        buffer.writeln();
        buffer.writeln(locks[i]);
      }
      result = buffer.toString().trim();
    }

    return result.trim();
  }

  String _cleanWriterGeneratedText(String value) {
    String reduceConnectorChains(String line) {
      var fixed = line
          .replaceAll(RegExp(r'\bhemde\b', caseSensitive: false), 'hem de')
          .replaceAll(RegExp(r'\bve\s+ve\b', caseSensitive: false), 've')
          .replaceAll(RegExp(r'\bde\s+de\b', caseSensitive: false), 'de');

      final hemMatches = RegExp(r'\bhem(?:\s+de)?\b', caseSensitive: false).allMatches(fixed).length;
      if (hemMatches > 2) {
        // Uzun "hem... hem... hem..." zincirlerini kes. Bu yapı yazar modunda istenmiyor.
        fixed = fixed.replaceAll(RegExp(r'\bhem\s+de\b\s*', caseSensitive: false), '');
        fixed = fixed.replaceAll(RegExp(r'\bhem\b\s*', caseSensitive: false), '');
        fixed = fixed.replaceAll(RegExp(r'\s*,\s*,+'), ', ');
        fixed = fixed.replaceAll(RegExp(r'\s{2,}'), ' ');
      }

      return fixed.trimRight();
    }

    final lines = <String>[];
    final seenParagraphStarts = <String, int>{};

    for (final line in value.split('\n')) {
      var workingLine = reduceConnectorChains(line);

      final tokens = workingLine.split(RegExp(r'(\s+)'));
      final cleaned = <String>[];
      var previousWord = '';

      for (final token in tokens) {
        final normalized = token
            .toLowerCase()
            .replaceAll(RegExp(r'[^a-z0-9çğıöşüÇĞİÖŞÜ]'), '');

        if (normalized.isNotEmpty && normalized == previousWord) {
          continue;
        }

        cleaned.add(token);
        if (normalized.isNotEmpty) previousWord = normalized;
      }

      workingLine = cleaned.join();

      // Paragrafların hep aynı kelimeyle başlamasını azalt.
      final startMatch = RegExp(r'^\s*([A-Za-zÇĞİÖŞÜçğıöşü]{4,})').firstMatch(workingLine);
      if (startMatch != null && workingLine.trim().length > 60) {
        final key = startMatch.group(1)!.toLowerCase();
        final count = seenParagraphStarts[key] ?? 0;
        seenParagraphStarts[key] = count + 1;
        if (count >= 2) {
          workingLine = workingLine.replaceFirst(RegExp(r'^\s*' + RegExp.escape(startMatch.group(1)!) + r'\s*,?\s*', caseSensitive: false), '');
        }
      }

      lines.add(workingLine);
    }

    return lines
        .join('\n')
        .replaceAll(RegExp(r'Seçilmemiş görsel alanı\\.?', caseSensitive: false), 'Bölüm arası')
        .replaceAll(RegExp(r'\n{4,}'), '\n\n\n')
        .trim();
  }

  String _chapterWriterRequest(AppContent item, int index, {int retry = 0}) {
    final title = cleanBookChapterTitle(item.title);
    final chapterLabel = bookChapterLabelFromList(widget.items, index);
    final protectedBody = _protectedBodyForWriter(item);
    final visualLocks = _visualLocksForItem(item);
    final words = BookStats.countWords('${item.title} ${item.summary} ${item.body}');
    final pages = BookStats.estimatedPagesForItem(item);
    final minimumWords = words <= 0 ? 0 : (words * 0.98).floor();
    final targetUpperPages = pages <= 1 ? 2 : pages + 1;
    final nearbyTitles = widget.items
        .asMap()
        .entries
        .where((entry) => entry.key != index)
        .map((entry) => cleanBookChapterTitle(entry.value.title))
        .where((value) => value.trim().isNotEmpty)
        .take(80)
        .join('\n- ');
    final versionNote = retry == 0
        ? ''
        : '\nÖnceki cevap metni kısalttı veya kurallara uymadı. Bu kez hiçbir özgün bilgiyi silmeden, daha doğal ve kaynak güvenli bir düzenleme yap.';
    final visualRule = visualLocks.isEmpty
        ? '- Bu bölümde görsel kilidi yok. Yeni görsel satırı ekleme.'
        : '''
Görsel kilidi:
- Bu bölümde ${visualLocks.length} görsel alanı var.
- [[GÖRSEL_KİLİT_1]] gibi satırlar görsel yeridir.
- Kilit satırlarını AYNEN koru; silme, taşıma, çoğaltma veya değiştirme.
- Yeni "görsel" satırı ekleme.
- Kilitlerin çevresindeki metni düzenleyebilirsin; görseller uygulamada aynı yerde kalmalı.''';

    return '''
Sen, bağımsız bir araştırmacının hazırladığı araştırma metnini düzenleyen dikkatli bir kitap editörüsün.

Çalışmanın ana amacı:
Antik medeniyetlerde sürüngen soy, yılan/ejderha sembolleri ve modern Reptilyan yorumları arasındaki izleri araştırmak.

Bölüm:
$chapterLabel
Başlık: $title
Mevcut yaklaşık kelime: $words
Mevcut yaklaşık sayfa: $pages
Alt sınır: $minimumWords kelime
Hedef: mevcut uzunluğu koru; gerçek bir eksik varsa en fazla yaklaşık $targetUpperPages sayfaya kadar geliştir.
$versionNote

Diğer bölüm başlıkları:
- $nearbyTitles

GÖREV
Aşağıdaki bölümü baştan sona oku. Yazım, noktalama, anlatım, geçiş, tekrar ve konu bütünlüğü sorunlarını düzelt. Bölümde eksik kalan açıklamaları, yalnızca mevcut metindeki doğrulanabilir bilgilerden ve güvenli bağlamdan hareketle geliştir. Metni, aynı yazarın elinden çıkmış doğal bir araştırma bölümü gibi düzenle.

ZORUNLU İÇERİK KURALLARI
- Bölümü KISALTMA. Yeni metin, mevcut kelime sayısının yüzde 98'inin altına düşmemeli.
- Saf tekrarları temizlediğinde oluşan kaybı, yeni ve anlamlı geçiş/açıklamalarla dengele.
- Altı sayfalık bir bölümü dört sayfaya indirme; özgün bilgileri, örnekleri, yer adlarını ve olayları silme.
- Bölümün sonunda daha önce anlatılanları yeniden özetleyen bir paragraf yazma.
- Aynı bilgiyi farklı cümlelerle tekrar anlatma. Her paragraf yeni bir işlev taşısın.
- "Medeniyet", "antik", "varlık", "Reptilyan" ve benzeri kelimeleri gereksiz sıklıkta tekrarlama.
- Bir medeniyeti, kenti veya tapınağı uzun uzun yeniden tanıtma. Okuyucunun ihtiyaç duyduğu kadar kısa bağlam ver ve doğrudan bölümün özgün konusuna geç.
- Sürüngen soy/Reptilyan bağlantısını bölümün malzemesine göre kur. Yılan, ejderha, soy, doğum, yeraltı, maske, kabartma, ritüel veya insan dışı figür gibi gerçek motiflerden hareket et.
- Reptilyan bağlantısını tarihsel gerçekmiş gibi sunma; "bu motif modern yorumlarda...", "araştırma açısından...", "bu benzerlik..." gibi ölçülü bir araştırmacı dili kullan.
- Mitolojik anlatı, arkeolojik bulgu, tarihsel kaynak ve modern/paranormal yorumu birbirinden açıkça ayır.
- Sahte kişi, tarih, kazı, eser, müze, alıntı, kaynak veya akademik görüş UYDURMA.
- Metinde bulunmayan bir bilgi doğrulama gerektiriyorsa onu bölüme ekleme; değişiklik raporunda "Kaynak gerekli" başlığı altında belirt.
- Kaynağı bilinmeyen kesin cümleleri daha temkinli hâle getir; fakat metni sürekli "kanıt değildir" kalıbıyla boğma.
- Roman, hikâye veya şiir dili kullanma. Bağımsız araştırmacı tonunda; akıcı, ciddi, merak uyandıran ve insan eliyle yazılmış gibi yaz.
- Aynı paragraf başlangıçlarını, kalıp sonuç cümlelerini ve zincirleme "hem... hem..." yapılarını tekrarlama.
- Başlığı tekrar yazma.
$visualRule

ÇIKTI BİÇİMİ — AYNEN UY
[[DUZENLENMIS_METIN]]
Buraya yalnızca düzenlenmiş bölüm metnini yaz.

[[DEGISIKLIK_RAPORU]]
Eklenenler:
- Bölüme eklediğin gerçek açıklama ve bağlantıları açıkça yaz.

Değiştirilenler:
- Düzelttiğin tekrar, geçiş, anlatım ve temkinli ifade değişikliklerini yaz.

Korunanlar:
- Koruduğun ana bilgiler, görseller ve bölümün özgün yönünü kısaca yaz.

Kaynak gerekli:
- Doğrulanmadan eklemediğin bilgi ihtiyaçlarını yaz. Yoksa "Yok" yaz.

Kesinlikle değişiklik raporunu bölüm metninin içine karıştırma.

MEVCUT BÖLÜM METNİ
---
$protectedBody
---
''';
  }

  String _newChapterWriterRequest({int retry = 0}) {
    final titles = widget.items
        .map((item) => cleanBookChapterTitle(item.title))
        .where((title) => title.trim().isNotEmpty)
        .take(60)
        .join('\n- ');
    final versionNote = retry == 0 ? '' : '\nÖnceki öneriden farklı bir bölüm konusu ve farklı akış öner. Aynı uygarlık listesini tekrar etme.';

    return '''
Sen profesyonel bir editör ve araştırma yazarı gibi çalış; ama anlatım akademik makale gibi kuru olmasın.

Çalışmanın konusu:
Antik çağlarda reptilyan izleri, mitolojik semboller, arkeolojik işaretler, gizem ve paranormal araştırma.

Yazar kimliği:
Metin bağımsız bir araştırmacının kaleminden çıkmış gibi olmalı. Okuyucuya dönük, merak uyandıran, ciddi ama anlaşılır bir anlatım kullan. Kozmopolitik ve farklı bilgi seviyelerinden okurların rahat okuyacağı bir dil kur.

Kitaptaki mevcut bölüm başlıkları:
- $titles

Görev:
Bu kitaba uygun yeni bir bölüm öner ve yaz.
$versionNote

Çıktı biçimi:
Başlık: <yeni bölüm başlığı>

<kitap bölümü metni>

Kurallar:
- Bölüm 4-6 standart sayfa hedefinde olsun; aşırı uzatma.
- Toplam hedef yaklaşık 300 sayfa olduğu için yeni bölüm dengeli kalsın.
- "Kitap" kelimesini kullanma; gerekiyorsa "bu çalışma", "bu bölüm", "bu metin" de.
- Aynı fikirleri, aynı cümleleri ve aynı paragraf başlangıçlarını tekrar etme.
- Aynı kelime dağarcığını döndürüp durma; her paragrafta farklı ifade, farklı cümle yapısı ve yeni vurgu kullan.
- "bazen bazen", "kiminde kiminde", "kimi zaman kimi zaman", "hem ... hem ... hem ..." gibi kelime/yapı tekrarları kesinlikle olmasın.
- "hem bilgeliği hem zehri, hem şifayı hem tehdidi, hem yeraltını..." gibi zincirleme kalıp kurma; bu yapıyı tamamen sadeleştir.
- Aynı kavramları art arda sıralama. Bilgelik, zehir, şifa, tehdit, yeraltı gibi kelimeleri gereksiz tekrar etme.
- Yazıyı bitirmeden önce kendi metnini tekrar açısından kontrol et; tekrar gördüğün kelimeyi, cümleyi veya fikri değiştir.
- Gereksiz yere sürekli Mezopotamya, Anadolu, Mısır, Yunan, Hint, Uzak Doğu gibi uygarlık adlarını sıralama.
- Bu uygarlık adları gerekiyorsa kullan; ama liste gibi yığma yapma.
- Reptilyan izlerine kesin vardır ya da kesin yoktur diye yaklaşma; şüpheci, araştırmacı ve dengeli kal.
- "Bilimsel kanıt yoktur" cümlesini sürekli tekrar etme. Gerektiğinde bir kez yumuşak biçimde "bu yorum kesin hüküm değil, araştırma ihtimalidir" de.
- Dünyadaki sürüngen/yılan/ejderha izlerini ve sembolik sürekliliği ciddiye al; ama kesin hüküm kurma.
- Mitoloji, arkeoloji ve modern/paranormal yorum ayrımını net tut.
- Sahte kaynak ve sahte tarihî belge üretme.
- Gerektiğinde ayrı satır olarak "görsel" yaz.
- Bölüm sonunda önceki paragrafları yeniden özetleme; yeni bir fikir taşıyan doğal ve düşündürücü bir kapanış yap.
- Dil: bağımsız araştırmacı sesiyle, okuyucuya dönük, akıcı, ciddi, gizemli ama anlaşılır olsun.
''';
  }

  Future<void> _shareWriterTextAsWord(
    BuildContext context,
    String title,
    String body,
    String fileName, {
    AppContent? sourceItem,
    List<String> visualLocks = const [],
  }) async {
    final cleanBody = sourceItem == null ? body.trim() : _normalizeVisualResult(body, visualLocks);
    if (cleanBody.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Word için metin yok.')));
      return;
    }

    try {
      final file = await BookExporter.createDocx([
        AppContent(
          id: 'writer_${DateTime.now().microsecondsSinceEpoch}',
          type: ContentTypes.book,
          title: title,
          category: 'Yazar Modu',
          summary: '',
          body: cleanBody,
          imageUrl: sourceItem?.imageUrl ?? '',
          imagePath: sourceItem?.imagePath ?? '',
          source: sourceItem?.source ?? '',
          inlineImagePaths: sourceItem?.inlineImagePaths ?? const [],
        ),
      ], fileName: fileName, includeBookTitlePage: false);

      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'Yazar modu Word dosyası hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Word dosyası oluşturulamadı: $e')));
    }
  }

  Future<String?> _openApiFreeWriterSheet(
    BuildContext context, {
    required String title,
    required String requestText,
    required String acceptLabel,
    required String shareLabel,
    required bool visualLocked,
    AppContent? sourceItem,
    List<String> visualLocks = const [],
  }) async {
    final controller = TextEditingController();

    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.92,
          minChildSize: 0.55,
          maxChildSize: 0.97,
          builder: (context, scrollController) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.auto_fix_high_outlined),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  visualLocked
                      ? 'Gönderilecek metin aşağıda görünüyor. Görselleri de göndermek için Görselli Word yap butonunu kullan. Cevabı yapıştırınca uygulama eski görselleri ve yerlerini geri koruyacak.'
                      : 'Gönderilecek metin aşağıda görünüyor. ChatGPT’ye gönder, cevabı yapıştır.',
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: () => Share.share(requestText, subject: title),
                      icon: const Icon(Icons.open_in_new_outlined),
                      label: Text(shareLabel),
                    ),
                    OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: requestText));
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gönderilecek metin kopyalandı.')));
                      },
                      icon: const Icon(Icons.copy_outlined),
                      label: const Text('Metni kopyala'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => _shareWriterTextAsWord(
                        context,
                        'Yazar Modu İsteği',
                        requestText,
                        'Yazar_Modu_Istegi',
                        sourceItem: sourceItem,
                        visualLocks: visualLocks,
                      ),
                      icon: const Icon(Icons.description_outlined),
                      label: Text(visualLocked ? 'Görselli Word yap' : 'İsteği Word yap'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: SingleChildScrollView(
                    controller: scrollController,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Gönderilecek metin', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(minHeight: 160, maxHeight: 260),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                          ),
                          child: SingleChildScrollView(
                            child: SelectableText(requestText),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text('ChatGPT cevabı', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: controller,
                          minLines: 10,
                          maxLines: 16,
                          textAlignVertical: TextAlignVertical.top,
                          decoration: const InputDecoration(
                            labelText: 'ChatGPT cevabını buraya yapıştır',
                            alignLabelWithHint: true,
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            OutlinedButton.icon(
                              onPressed: () async {
                                final value = controller.text.trim();
                                if (value.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce ChatGPT cevabını yapıştır.')));
                                  return;
                                }
                                await Clipboard.setData(ClipboardData(text: value));
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cevap kopyalandı.')));
                              },
                              icon: const Icon(Icons.copy_all_outlined),
                              label: const Text('Cevabı kopyala'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () {
                                final value = controller.text.trim();
                                if (value.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce ChatGPT cevabını yapıştır.')));
                                  return;
                                }
                                _shareWriterTextAsWord(
                                  context,
                                  'Yazar Modu Cevabı',
                                  value,
                                  'Yazar_Modu_Cevabi',
                                  sourceItem: sourceItem,
                                  visualLocks: visualLocks,
                                );
                              },
                              icon: const Icon(Icons.description_outlined),
                              label: const Text('Cevabı Word yap'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Share.share(requestText, subject: title),
                        icon: const Icon(Icons.refresh_outlined),
                        label: const Text('Tekrar gönder'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () {
                          final value = controller.text.trim();
                          if (value.isEmpty) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce ChatGPT cevabını buraya yapıştır.')));
                            return;
                          }
                          Navigator.of(context).pop(value);
                        },
                        icon: const Icon(Icons.check_outlined),
                        label: Text(acceptLabel),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    controller.dispose();
    return result;
  }

  WriterEditResult _parseWriterEditResult(String raw) {
    const textMarker = '[[DUZENLENMIS_METIN]]';
    const reportMarker = '[[DEGISIKLIK_RAPORU]]';
    final normalized = raw.trim();
    final textIndex = normalized.indexOf(textMarker);
    final reportIndex = normalized.indexOf(reportMarker);

    if (textIndex >= 0 && reportIndex > textIndex) {
      final body = normalized.substring(textIndex + textMarker.length, reportIndex).trim();
      final report = normalized.substring(reportIndex + reportMarker.length).trim();
      return WriterEditResult(editedBody: body, aiReport: report);
    }

    if (reportIndex >= 0) {
      return WriterEditResult(
        editedBody: normalized.substring(0, reportIndex).replaceAll(textMarker, '').trim(),
        aiReport: normalized.substring(reportIndex + reportMarker.length).trim(),
      );
    }

    return WriterEditResult(editedBody: normalized.replaceAll(textMarker, '').trim(), aiReport: '');
  }

  String _writerTimestamp() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${two(now.day)}.${two(now.month)}.${now.year} ${two(now.hour)}:${two(now.minute)}';
  }

  String _buildWriterEditReport({
    required String oldBody,
    required String newBody,
    required String aiReport,
  }) {
    final oldWords = BookStats.countWords(oldBody);
    final newWords = BookStats.countWords(newBody);
    final difference = newWords - oldWords;
    final oldParagraphs = oldBody
        .split(RegExp(r'\n\s*\n'))
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toList();
    final newParagraphs = newBody
        .split(RegExp(r'\n\s*\n'))
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toList();
    final commonLength = oldParagraphs.length < newParagraphs.length ? oldParagraphs.length : newParagraphs.length;
    var changedParagraphs = 0;
    for (var i = 0; i < commonLength; i++) {
      final oldNormalized = oldParagraphs[i].replaceAll(RegExp(r'\s+'), ' ').trim();
      final newNormalized = newParagraphs[i].replaceAll(RegExp(r'\s+'), ' ').trim();
      if (oldNormalized != newNormalized) changedParagraphs++;
    }
    final addedParagraphs = newParagraphs.length > oldParagraphs.length ? newParagraphs.length - oldParagraphs.length : 0;
    final removedParagraphs = oldParagraphs.length > newParagraphs.length ? oldParagraphs.length - newParagraphs.length : 0;
    final signedDifference = difference > 0 ? '+$difference' : '$difference';
    final suppliedReport = aiReport.trim().isEmpty
        ? 'Yapay zekâ ayrıntılı rapor vermedi. Uygulama yalnızca ölçülebilen değişiklikleri gösteriyor.'
        : aiReport.trim();

    return '''UYGULAMA KONTROLÜ
- Önceki kelime sayısı: $oldWords
- Yeni kelime sayısı: $newWords
- Kelime farkı: $signedDifference
- Değişen paragraf: $changedParagraphs
- Eklenen paragraf: $addedParagraphs
- Çıkarılan paragraf: $removedParagraphs
- Uzunluk koruması: ${newWords >= (oldWords * 0.98).floor() ? 'Geçti' : 'Başarısız'}

YAPAY ZEKÂ DEĞİŞİKLİK RAPORU
$suppliedReport''';
  }

  Future<bool> _confirmWriterEdit(
    BuildContext context, {
    required AppContent item,
    required String editedBody,
    required String report,
  }) async {
    final oldWords = BookStats.countWords(item.body);
    final newWords = BookStats.countWords(editedBody);
    final difference = newWords - oldWords;
    final signedDifference = difference > 0 ? '+$difference' : '$difference';

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.9,
          minChildSize: 0.55,
          maxChildSize: 0.97,
          builder: (context, scrollController) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.fact_check_outlined),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Değişiklikleri incele',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text('Önce: $oldWords kelime  •  Sonra: $newWords kelime  •  Fark: $signedDifference'),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView(
                    controller: scrollController,
                    children: [
                      Text('Neler eklendi ve değiştirildi?', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      SelectableText(report),
                      const SizedBox(height: 12),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        title: const Text('Eski metni göster'),
                        children: [SelectableText(item.body)],
                      ),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        title: const Text('Düzenlenmiş metni göster'),
                        children: [SelectableText(editedBody)],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: const Text('Vazgeç'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => Navigator.of(context).pop(true),
                        icon: const Icon(Icons.check_outlined),
                        label: const Text('Değişiklikleri uygula'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    return result == true;
  }

  Future<void> _showWriterEditReport(BuildContext context, AppContent item, int index) async {
    if (item.writerEditReport.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bu bölüm için kayıtlı değişiklik raporu yok.')));
      return;
    }

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.9,
          minChildSize: 0.5,
          maxChildSize: 0.97,
          builder: (context, scrollController) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.fact_check_outlined),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Son değişiklik raporu',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                    IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close)),
                  ],
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '${bookChapterLabelFromList(widget.items, index)} • ${item.writerEditedAt.trim().isEmpty ? 'Tarih kaydedilmedi' : item.writerEditedAt}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView(
                    controller: scrollController,
                    children: [
                      SelectableText(item.writerEditReport),
                      if (item.writerPreviousBody.trim().isNotEmpty) ...[
                        const SizedBox(height: 12),
                        ExpansionTile(
                          tilePadding: EdgeInsets.zero,
                          title: const Text('Düzenleme öncesi metin'),
                          children: [SelectableText(item.writerPreviousBody)],
                        ),
                        ExpansionTile(
                          tilePadding: EdgeInsets.zero,
                          title: const Text('Güncel metin'),
                          children: [SelectableText(item.body)],
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _repeatWarningSummary(String body) {
    final lower = body.toLowerCase();
    final warnings = <String>[];
    final hemCount = RegExp(r'\bhem(?:\s+de)?\b', caseSensitive: false).allMatches(lower).length;
    if (hemCount > 2) warnings.add('hem kalıbı fazla');
    for (final word in ['bilgelik', 'zehir', 'şifa', 'tehdit', 'yeraltı', 'korku']) {
      final count = RegExp('\\b$word\\b', caseSensitive: false).allMatches(lower).length;
      if (count > 4) warnings.add('$word tekrarı');
    }
    return warnings.take(3).join(', ');
  }

  Future<void> _openChapterWriterMode(BuildContext context, AppContent item, int index) async {
    if (item.locked) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bu bölüm kilitli. Yazar Modu için önce kilidi aç.')));
      return;
    }
    final visualLocks = _visualLocksForItem(item);
    var retry = 0;

    while (context.mounted) {
      final request = _chapterWriterRequest(item, index, retry: retry);
      final pasted = await _openApiFreeWriterSheet(
        context,
        title: 'Yazar Modu: Analiz ve düzenleme',
        requestText: request,
        acceptLabel: 'Karşılaştır',
        shareLabel: retry == 0 ? 'ChatGPT’ye gönder' : 'Kurallarla yeniden gönder',
        visualLocked: visualLocks.isNotEmpty,
        sourceItem: item,
        visualLocks: visualLocks,
      );

      if (pasted == null || pasted.trim().isEmpty || !context.mounted) return;

      final parsed = _parseWriterEditResult(pasted);
      if (parsed.editedBody.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Düzenlenmiş metin bulunamadı. ChatGPT cevabını yeniden yapıştırın.')));
        return;
      }

      final cleanedPasted = _cleanWriterGeneratedText(parsed.editedBody);
      final safeGenerated = _normalizeVisualResult(cleanedPasted, visualLocks).trim();
      final oldWords = BookStats.countWords(item.body);
      final newWords = BookStats.countWords(safeGenerated);
      final minimumWords = (oldWords * 0.98).floor();

      if (oldWords > 0 && newWords < minimumWords) {
        final retryRequested = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Bölüm fazla kısaldı'),
            content: Text(
              'Eski metin $oldWords kelime, yeni metin $newWords kelime. '
              'Bu sürüm 6 sayfalık bölümü 4 sayfaya indiren cevapları uygulamaz.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
              FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Yeniden gönder')),
            ],
          ),
        );
        if (retryRequested == true) {
          retry++;
          continue;
        }
        return;
      }

      final report = _buildWriterEditReport(
        oldBody: item.body,
        newBody: safeGenerated,
        aiReport: parsed.aiReport,
      );
      final approved = await _confirmWriterEdit(
        context,
        item: item,
        editedBody: safeGenerated,
        report: report,
      );
      if (!approved || !context.mounted) return;

      final updated = item.copyWith(
        body: safeGenerated,
        writerEditReport: report,
        writerPreviousBody: item.body,
        writerEditedAt: _writerTimestamp(),
      );

      final newList = [...widget.items];
      if (index >= 0 && index < newList.length) {
        newList[index] = updated;
        final repeatWarning = _repeatWarningSummary(safeGenerated);
        await _applyBookReplacement(
          newList,
          repeatWarning.isEmpty
              ? 'Yazar modu bölümü kısaltmadan analiz edip güncelledi: ${bookChapterLabelFromList(newList, index)}'
              : 'Yazar modu güncelledi; değişiklik raporu hazır. Tekrar uyarısı: $repeatWarning',
        );
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Bölüm güncellendi. Değişiklikleri rapor düğmesinden görebilirsiniz.')),
        );
      }
      return;
    }
  }

  AppContent _chapterFromGeneratedText(String generated) {
    final cleanedGenerated = _cleanWriterGeneratedText(generated);
    final lines = cleanedGenerated.split('\n');
    var title = 'Yeni Bölüm';
    var startIndex = 0;

    for (var i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final lower = line.toLowerCase();
      if (lower.startsWith('başlık:') || lower.startsWith('baslik:')) {
        title = line.substring(line.indexOf(':') + 1).trim();
        startIndex = i + 1;
      } else if (line.length <= 120 && !line.endsWith('.')) {
        title = line.replaceAll(RegExp(r'^#+\s*'), '').trim();
        startIndex = i + 1;
      }
      break;
    }

    final body = lines.skip(startIndex).join('\n').trim();
    return AppContent(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      type: ContentTypes.book,
      title: title.trim().isEmpty ? 'Yeni Bölüm' : title.trim(),
      category: 'Bölüm',
      summary: '',
      body: body.isEmpty ? cleanedGenerated.trim() : body,
    );
  }

  Future<void> _openNewChapterWriterMode(BuildContext context) async {
    var retry = 0;
    while (context.mounted) {
      final request = _newChapterWriterRequest(retry: retry);
      final pasted = await _openApiFreeWriterSheet(
        context,
        title: 'Yazar Modu: Yeni bölüm',
        requestText: request,
        acceptLabel: 'Bölüm ekle',
        shareLabel: retry == 0 ? 'ChatGPT’ye gönder' : 'Başka bölüm yazdır',
        visualLocked: false,
      );

      if (pasted == null || pasted.trim().isEmpty || !context.mounted) return;

      final chapter = _chapterFromGeneratedText(pasted);
      await _applyBookAppend([chapter], 'Uygulama içi yazar modu yeni bölüm ekledi.');
      if (!mounted) return;
      return;
    }
  }

  Future<void> _exportSingleChapter(BuildContext context, AppContent item, int index) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.description_outlined),
                title: const Text('Bu bölümü Word olarak aktar'),
                subtitle: Text(cleanBookChapterTitle(item.title)),
                onTap: () => Navigator.of(context).pop('word'),
              ),
              ListTile(
                leading: const Icon(Icons.picture_as_pdf_outlined),
                title: const Text('Bu bölümü PDF olarak aktar'),
                subtitle: Text(cleanBookChapterTitle(item.title)),
                onTap: () => Navigator.of(context).pop('pdf'),
              ),
            ],
          ),
        ),
      ),
    );

    if (choice == null) return;

    final label = bookChapterLabelFromList(widget.items, index).replaceAll('.', '').replaceAll(' ', '_');
    final title = cleanBookChapterTitle(item.title);
    final fileName = '${label}_${title.isEmpty ? 'Bolum' : title}';

    try {
      final file = choice == 'word'
          ? await BookExporter.createDocx([item], numberingChapters: widget.items, indexOffset: index, fileName: fileName, includeBookTitlePage: false)
          : await BookExporter.createPdf([item], numberingChapters: widget.items, indexOffset: index, fileName: fileName, includeBookTitlePage: false);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, choice == 'word' ? 'Bölüm Word dosyası hazır' : 'Bölüm PDF dosyası hazır');
      setState(() => operationStatus = 'Tek bölüm dışa aktarıldı: ${bookChapterLabelFromList(widget.items, index)}');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bölüm dışa aktarılamadı: $e')));
    }
  }

  int _visualMarkerLineCount(String body) {
    final marker = RegExp(
      r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*\d*\s*(?::\s*.*)?\]?)\s*$',
      caseSensitive: false,
    );
    return body.split('\n').where((line) => marker.hasMatch(line.trim())).length;
  }

  String _ensureReplacementVisualMarkers(String body, AppContent oldItem, AppContent incoming) {
    final imageCount = incoming.cleanInlineImagePaths.isNotEmpty
        ? incoming.cleanInlineImagePaths.length
        : oldItem.cleanInlineImagePaths.length;

    if (imageCount <= 0) return body.trim();

    final existingMarkers = _visualMarkerLineCount(body);
    if (existingMarkers >= imageCount) return body.trim();

    final buffer = StringBuffer(body.trim());
    for (var i = existingMarkers; i < imageCount; i++) {
      buffer.writeln();
      buffer.writeln();
      buffer.writeln('görsel');
    }
    return buffer.toString().trim();
  }

  String _replacementTitle(AppContent oldItem, AppContent incoming) {
    final incomingTitle = cleanBookChapterTitle(incoming.title).trim();
    final lower = incomingTitle.toLowerCase();
    if (incomingTitle.isEmpty || lower.startsWith('yazar modu')) {
      return oldItem.title;
    }
    return incomingTitle;
  }

  AppContent _mergeImportedChapterIntoExisting(AppContent oldItem, AppContent incoming) {
    final incomingImages = incoming.cleanInlineImagePaths;
    final body = _ensureReplacementVisualMarkers(incoming.body.trim(), oldItem, incoming);

    return AppContent(
      id: oldItem.id,
      type: ContentTypes.book,
      title: _replacementTitle(oldItem, incoming),
      category: oldItem.category,
      summary: incoming.summary,
      body: body,
      imageUrl: incoming.imageUrl.trim().isNotEmpty ? incoming.imageUrl : oldItem.imageUrl,
      imagePath: incoming.imagePath.trim().isNotEmpty ? incoming.imagePath : oldItem.imagePath,
      source: incoming.source.trim().isNotEmpty ? incoming.source : oldItem.source,
      inlineImagePaths: incomingImages.isNotEmpty ? incoming.inlineImagePaths : oldItem.inlineImagePaths,
    );
  }

  Future<int?> _selectChapterIndexToReplace(BuildContext context, AppContent incoming) async {
    return showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.75,
          minChildSize: 0.35,
          maxChildSize: 0.92,
          builder: (context, scrollController) => Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                child: Row(
                  children: [
                    const Icon(Icons.swap_horiz_outlined),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Hangi bölümü değiştireyim?',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Text(
                  'Yüklediğin tek bölüm, sadece seçtiğin bölümün yerine geçer. Diğer bölümler silinmez.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  itemCount: widget.items.length,
                  itemBuilder: (context, index) {
                    final item = widget.items[index];
                    return ListTile(
                      leading: CircleAvatar(child: Text('${index + 1}')),
                      title: Text(
                        cleanBookChapterTitle(item.title),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text('${bookChapterLabelFromList(widget.items, index)} • yaklaşık ${BookStats.estimatedPagesForItem(item)} sayfa'),
                      onTap: () => Navigator.of(context).pop(index),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<int?> _selectChapterIndexToDelete(BuildContext context) async {
    return showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.75,
          minChildSize: 0.35,
          maxChildSize: 0.92,
          builder: (context, scrollController) => Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                child: Row(
                  children: [
                    const Icon(Icons.delete_outline),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Hangi bölümü sileyim?',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Text(
                  'Sadece seçtiğin bölüm silinir. Diğer bölümler korunur.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  itemCount: widget.items.length,
                  itemBuilder: (context, index) {
                    final item = widget.items[index];
                    return ListTile(
                      leading: CircleAvatar(child: Text('${index + 1}')),
                      title: Text(
                        cleanBookChapterTitle(item.title),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text('${bookChapterLabelFromList(widget.items, index)} • yaklaşık ${BookStats.estimatedPagesForItem(item)} sayfa'),
                      trailing: const Icon(Icons.delete_outline),
                      onTap: () => Navigator.of(context).pop(index),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleImportedChapters(BuildContext context, List<AppContent> chapters) async {
    chapters = sortImportedChaptersByNumber(chapters);
    final numberedCount = chapters.where((item) => explicitBookChapterNumber(item) != null).length;
    if (chapters.isEmpty) {
      setState(() => operationStatus = 'Dosya okundu ama bölüm bulunamadı.');
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bölüm bulunamadı.')));
      return;
    }

    if (widget.items.isEmpty) {
      await _applyBookReplacement(chapters, numberedCount > 0 ? '$numberedCount numaralı bölüm bölüm numarasına göre sıralanarak yüklendi.' : 'İlk belge dosyaları yüklendi.');
      if (!mounted || !context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Belge dosyaları yüklendi.')));
      return;
    }

    final action = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${chapters.length} bölüm bulundu'),
        content: Text(numberedCount > 0 ? '$numberedCount bölümde bölüm numarası bulundu ve dosyalar numaraya göre sıralandı. Mevcut listenin sonuna ekleyebilir veya seçtiğiniz bir bölümü değiştirebilirsiniz.' : 'Dosyaları mevcut bölümlerin sonuna ekleyebilir veya seçtiğiniz bir bölümü değiştirebilirsiniz. Toplu silme işlemi Bölümler ekranındaki “Bölüm seç” düğmesinden yapılır.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(null), child: const Text('İptal')),
          TextButton(onPressed: () => Navigator.of(context).pop('append'), child: const Text('Üstüne ekle')),
          FilledButton(onPressed: () => Navigator.of(context).pop('replace_one'), child: const Text('Bölüm seç ve değiştir')),
        ],
      ),
    );

    if (action == null) return;

    if (action == 'append') {
      await _applyBookAppend(chapters, numberedCount > 0 ? '${chapters.length} bölüm kendi bölüm numaralarına göre sıralanıp listenin sonuna eklendi.' : '${chapters.length} bölüm mevcut listenin sonuna eklendi. Hiçbir bölüm silinmedi.');
      if (!mounted || !context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bölümler eklendi. Mevcut bölümler silinmedi.')));
      return;
    }

    if (action == 'delete_one') {
      final selectedIndex = await _selectChapterIndexToDelete(context);
      if (selectedIndex == null) return;

      final deletedTitle = cleanBookChapterTitle(widget.items[selectedIndex].title);
      final updatedList = [...widget.items]..removeAt(selectedIndex);
      await _applyBookReplacement(updatedList, 'Seçilen bölüm silindi: $deletedTitle. Diğer bölümler korundu.');

      if (!mounted || !context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seçilen bölüm silindi. Diğer bölümler korunuyor.')),
      );
      return;
    }

    if (action == 'replace_one') {
      final selectedIndex = await _selectChapterIndexToReplace(context, chapters.first);
      if (selectedIndex == null) return;

      final updatedList = [...widget.items];
      updatedList[selectedIndex] = _mergeImportedChapterIntoExisting(updatedList[selectedIndex], chapters.first);
      await _applyBookReplacement(updatedList, '${bookChapterLabelFromList(updatedList, selectedIndex)} değiştirildi. Diğer bölümlerin tamamı korundu.');

      if (!mounted || !context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seçilen bölüm değiştirildi. Diğer bölümler korunuyor.')),
      );
      return;
    }
  }

  Future<void> _importDocumentFiles(BuildContext context) async {
    try {
      setState(() => operationStatus = 'Word, PDF veya TXT dosyaları seçiliyor...');
      final files = await ExternalDocumentImporter.pickDocuments();
      if (files.isEmpty) {
        setState(() => operationStatus = 'Dosya seçilmedi.');
        return;
      }

      setState(() => operationStatus = '${files.length} dosya okunuyor ve kitap formatına çevriliyor...');
      final batch = await ExternalDocumentImporter.importFiles(files);
      if (!context.mounted) return;

      if (batch.chapters.isEmpty) {
        setState(() => operationStatus = 'Seçilen dosyalarda eklenebilir bölüm bulunamadı.');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              batch.failedFiles.isEmpty
                  ? 'Bölüm bulunamadı.'
                  : 'Dosyalar okunamadı: ${batch.failedFiles.join(', ')}',
            ),
          ),
        );
        return;
      }

      await _handleImportedChapters(context, batch.chapters);
      if (!mounted) return;
      final numberedCount = batch.chapters.where((item) => explicitBookChapterNumber(item) != null).length;
      setState(() {
        operationStatus = '${batch.chapters.length} bölüm hazırlandı. '
            '${batch.wordFileCount} Word, ${batch.pdfFileCount} PDF, ${batch.textFileCount} TXT işlendi.'
            '${numberedCount > 0 ? ' $numberedCount bölüm numaraya göre sıralandı.' : ''}';
      });
      if (batch.unreadableFileCount > 0 && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${batch.unreadableFileCount} dosya okunamadı: ${batch.failedFiles.join(', ')}')),
        );
      }
    } catch (e) {
      if (!context.mounted) return;
      setState(() => operationStatus = 'Dosyalar içe aktarılamadı: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Dosyalar içe aktarılamadı: $e')),
      );
    }
  }

  Future<void> _pasteWholeBook(BuildContext context) async {
    final chapters = await Navigator.of(context).push<List<AppContent>>(
      MaterialPageRoute(builder: (_) => const BulkBookPastePage()),
    );
    if (chapters == null) return;
    if (!context.mounted) return;
    await _handleImportedChapters(context, chapters);
  }

  Widget _tabButton(String id, IconData icon, String label) {
    final selected = activeBookTab == id;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Material(
          color: selected ? const Color(0xFF5B3B18) : const Color(0xFFFFF4DD),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => setState(() => activeBookTab = id),
            child: Container(
              height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: selected ? const Color(0xFFFFBE78) : const Color(0xFFD8C39A),
                  width: selected ? 2 : 1,
                ),
              ),
              padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 3),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 16, color: selected ? const Color(0xFFFFBE78) : const Color(0xFF5B452C)),
                  const SizedBox(height: 4),
                  Text(
                    label,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 10,
                      color: selected ? const Color(0xFFFFE8C6) : const Color(0xFF2B2117),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _chooseReorderSpeed(BuildContext context) async {
    final selected = await showDialog<double>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Bölüm taşıma hızı'),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.of(context).pop(2.0),
            child: const ListTile(leading: Icon(Icons.slow_motion_video), title: Text('Yavaş'), subtitle: Text('Kontrollü ve sakin kaydırma')),
          ),
          SimpleDialogOption(
            onPressed: () => Navigator.of(context).pop(4.0),
            child: const ListTile(leading: Icon(Icons.drag_handle), title: Text('Normal'), subtitle: Text('Dengeli varsayılan hız')),
          ),
          SimpleDialogOption(
            onPressed: () => Navigator.of(context).pop(8.0),
            child: const ListTile(leading: Icon(Icons.fast_forward), title: Text('Hızlı'), subtitle: Text('Uzun bölüm listelerinde rahat taşıma')),
          ),
          SimpleDialogOption(
            onPressed: () => Navigator.of(context).pop(14.0),
            child: const ListTile(leading: Icon(Icons.rocket_launch_outlined), title: Text('Çok hızlı'), subtitle: Text('Listenin başına veya sonuna hızlı geçiş')),
          ),
        ],
      ),
    );
    if (selected == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_reorderSpeedPreferenceKey, selected);
    if (!mounted) return;
    setState(() {
      _reorderSpeed = selected;
      operationStatus = 'Bölüm taşıma hızı: $_reorderSpeedLabel';
    });
  }

  Future<void> _openSmartChapterSort(BuildContext context) async {
    if (widget.items.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sıralama için en az iki bölüm gerekli.')));
      return;
    }

    var selectedMode = BookFlowSortMode.balanced;
    var keepLocked = true;

    final selectedPlan = await showDialog<BookFlowPlan>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          final plan = BookFlowAnalyzer.buildPlan(
            widget.items,
            selectedMode,
            keepLockedPositions: keepLocked,
          );
          final changedCount = plan.descriptors.where((entry) => entry.originalIndex != entry.proposedIndex).length;

          return AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.auto_awesome),
                SizedBox(width: 8),
                Expanded(child: Text('Akıllı bölüm akışı')),
              ],
            ),
            content: SizedBox(
              width: double.maxFinite,
              height: MediaQuery.of(context).size.height * 0.66,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Başlık, konu ve coğrafya birlikte analiz edilir. Örnek akış: David Icke → Anunnakiler → Ubeyd figürleri. Uyguladıktan sonra bölümleri yine elle değiştirebilirsiniz.',
                    style: TextStyle(height: 1.3),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<BookFlowSortMode>(
                    value: selectedMode,
                    decoration: const InputDecoration(labelText: 'Sıralama yöntemi', border: OutlineInputBorder()),
                    items: BookFlowSortMode.values
                        .map((mode) => DropdownMenuItem(value: mode, child: Text(mode.label)))
                        .toList(),
                    onChanged: (mode) {
                      if (mode == null) return;
                      setDialogState(() => selectedMode = mode);
                    },
                  ),
                  const SizedBox(height: 6),
                  Text(selectedMode.description, style: Theme.of(context).textTheme.bodySmall),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Kilitli bölümleri yerinde tut'),
                    subtitle: const Text('Açıksa kilitli bölümlerin sırası değişmez.'),
                    value: keepLocked,
                    onChanged: (value) => setDialogState(() => keepLocked = value),
                  ),
                  Text('$changedCount bölüm için yeni konum öneriliyor.', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Expanded(
                    child: ListView.separated(
                      itemCount: plan.ordered.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, proposedIndex) {
                        final item = plan.ordered[proposedIndex];
                        final descriptor = plan.descriptorFor(item);
                        final moved = descriptor.originalIndex != proposedIndex;
                        return ListTile(
                          dense: true,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
                          leading: CircleAvatar(
                            radius: 17,
                            child: Text('${proposedIndex + 1}', style: const TextStyle(fontSize: 12)),
                          ),
                          title: Text(cleanBookChapterTitle(item.title), maxLines: 2, overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                            '${descriptor.originalIndex + 1}. sıradan ${proposedIndex + 1}. sıraya${moved ? '' : ' • aynı konum'}\n${descriptor.reason}',
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: item.locked
                              ? const Icon(Icons.lock_outline, size: 18)
                              : Icon(moved ? Icons.swap_vert : Icons.check, size: 18),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Vazgeç')),
              FilledButton.icon(
                onPressed: () => Navigator.of(dialogContext).pop(plan),
                icon: const Icon(Icons.auto_awesome),
                label: const Text('Önerilen sırayı uygula'),
              ),
            ],
          );
        },
      ),
    );

    if (selectedPlan == null) return;
    final currentIds = widget.items.map((item) => item.id).toList();
    final proposedIds = selectedPlan.ordered.map((item) => item.id).toList();
    if (listEquals(currentIds, proposedIds)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mevcut sıra zaten seçilen akışa uygun.')));
      return;
    }

    await _applyBookReplacement(
      selectedPlan.ordered,
      'Akıllı sıralama uygulandı: ${selectedPlan.mode.label}. İsterseniz sürükleyerek veya sıra numarası yazarak değiştirebilirsiniz.',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Akıllı bölüm sırası uygulandı.'),
        action: SnackBarAction(label: 'Geri al', onPressed: _undoLastBookChange),
      ),
    );
  }

  Future<void> _moveChapterToPosition(int index) async {
    if (index < 0 || index >= widget.items.length) return;
    final item = widget.items[index];
    final controller = TextEditingController(text: '${index + 1}');
    final targetPosition = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Belirli sıraya taşı'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(cleanBookChapterTitle(item.title), maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              autofocus: true,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: InputDecoration(
                labelText: 'Yeni sıra numarası',
                helperText: '1 ile ${widget.items.length} arasında',
                border: const OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Vazgeç')),
          FilledButton(
            onPressed: () {
              final parsed = int.tryParse(controller.text.trim());
              if (parsed == null || parsed < 1 || parsed > widget.items.length) return;
              Navigator.of(context).pop(parsed);
            },
            child: const Text('Taşı'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (targetPosition == null) return;
    final targetIndex = targetPosition - 1;
    if (targetIndex == index) return;

    final updated = [...widget.items];
    final moved = updated.removeAt(index);
    updated.insert(targetIndex, moved);
    await _applyBookReplacement(updated, '${cleanBookChapterTitle(moved.title)} $targetPosition. sıraya taşındı.');
  }

  Future<void> _reorderChapters(int oldIndex, int newIndex) async {
    if (oldIndex < 0 || oldIndex >= widget.items.length) return;

    var targetIndex = newIndex;
    if (targetIndex > oldIndex) targetIndex -= 1;
    if (targetIndex < 0) targetIndex = 0;
    if (targetIndex >= widget.items.length) targetIndex = widget.items.length - 1;
    if (oldIndex == targetIndex) return;

    final updated = [...widget.items];
    final moved = updated.removeAt(oldIndex);
    updated.insert(targetIndex, moved);

    await _applyBookReplacement(updated, '${cleanBookChapterTitle(moved.title)} yeni sıraya taşındı. Bölüm numaraları otomatik güncellendi.');
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Bölüm ${oldIndex + 1}, ${targetIndex + 1}. sıraya taşındı.')),
    );
  }

  Future<void> _moveChapterOneStep(int index, int direction) async {
    final targetIndex = index + direction;
    if (index < 0 || index >= widget.items.length) return;
    if (targetIndex < 0 || targetIndex >= widget.items.length) return;

    final updated = [...widget.items];
    final moved = updated.removeAt(index);
    updated.insert(targetIndex, moved);

    await _applyBookReplacement(updated, '${cleanBookChapterTitle(moved.title)} ${targetIndex + 1}. sıraya alındı.');
    if (!mounted) return;
  }

  void _toggleChapterSelectionMode() {
    setState(() {
      _chapterSelectionMode = !_chapterSelectionMode;
      if (!_chapterSelectionMode) _selectedChapterIds.clear();
      activeBookTab = 'bolumler';
      operationStatus = _chapterSelectionMode
          ? 'Silmek istediğiniz bölümleri işaretleyin.'
          : 'Bölüm seçimi kapatıldı.';
    });
  }

  void _toggleChapterSelection(AppContent item) {
    if (item.locked) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kilitli bölüm seçilemez. Önce kilidini açın.')),
      );
      return;
    }
    setState(() {
      _chapterSelectionMode = true;
      if (!_selectedChapterIds.add(item.id)) _selectedChapterIds.remove(item.id);
      operationStatus = '${_selectedChapterIds.length} bölüm seçildi.';
    });
  }

  void _selectAllUnlockedChapters() {
    final selectableIds = widget.items.where((item) => !item.locked).map((item) => item.id).toSet();
    setState(() {
      _chapterSelectionMode = true;
      if (_selectedChapterIds.length == selectableIds.length && _selectedChapterIds.containsAll(selectableIds)) {
        _selectedChapterIds.clear();
        operationStatus = 'Bölüm seçimleri kaldırıldı.';
      } else {
        _selectedChapterIds
          ..clear()
          ..addAll(selectableIds);
        operationStatus = '${_selectedChapterIds.length} bölüm seçildi.';
      }
    });
  }

  Future<void> _deleteSelectedChapters() async {
    if (_selectedChapterIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce silinecek bölümleri işaretleyin.')));
      return;
    }

    final selected = widget.items.where((item) => _selectedChapterIds.contains(item.id) && !item.locked).toList();
    if (selected.isEmpty) return;

    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${selected.length} bölüm silinsin mi?'),
        content: Text(
          selected.length <= 5
              ? selected.map((item) => '• ${cleanBookChapterTitle(item.title)}').join('\n')
              : '${selected.take(5).map((item) => '• ${cleanBookChapterTitle(item.title)}').join('\n')}\n• ve ${selected.length - 5} bölüm daha',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Seçilenleri sil'),
          ),
        ],
      ),
    );

    if (approved != true) return;
    final updated = widget.items.where((item) => !_selectedChapterIds.contains(item.id) || item.locked).toList();
    final deletedCount = widget.items.length - updated.length;
    await _applyBookReplacement(updated, '$deletedCount bölüm toplu olarak silindi.');
    if (!mounted) return;
    setState(() {
      _selectedChapterIds.clear();
      _chapterSelectionMode = false;
      operationStatus = '$deletedCount bölüm silindi. Geri al düğmesiyle işlemi geri alabilirsiniz.';
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$deletedCount bölüm silindi.'),
        action: SnackBarAction(label: 'Geri al', onPressed: _undoLastBookChange),
      ),
    );
  }

  Future<void> _deleteChapter(AppContent item) async {
    if (item.locked) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bu bölüm kilitli. Silmek için önce kilidi aç.')));
      return;
    }

    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bölüm silinsin mi?'),
        content: Text('“${item.title}” bölümü silinecek. Diğer bölümler korunur.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );

    if (approved != true) return;
    final updated = widget.items.where((existing) => existing.id != item.id).toList();
    await _applyBookReplacement(updated, 'Bölüm silindi: ${cleanBookChapterTitle(item.title)}');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bölüm silindi.')));
  }

  Future<void> _toggleChapterLock(AppContent item) async {
    final index = widget.items.indexWhere((existing) => existing.id == item.id);
    if (index < 0) return;

    final updated = [...widget.items];
    updated[index] = item.copyWith(locked: !item.locked);
    await _applyBookReplacement(
      updated,
      item.locked ? 'Bölüm kilidi açıldı: ${cleanBookChapterTitle(item.title)}' : 'Bölüm kilitlendi: ${cleanBookChapterTitle(item.title)}',
    );
  }

  Widget _activeTabBody() {
    switch (activeBookTab) {
      case 'durum':
        return _BookStatusTab(
          stats: stats,
          operationStatus: operationStatus,
          items: widget.items,
          canUndo: _canUndoBookChange,
          onUndo: _undoLastBookChange,
        );
      case 'arama':
        return _BookSearchTab(items: widget.items, onEdit: widget.onEdit);
      case 'eksikler':
        return _BookMissingTab(stats: stats, items: widget.items);
      case 'bolumler':
      default:
        return _BookChaptersTab(
          items: widget.items,
          onEdit: widget.onEdit,
          onDelete: _deleteChapter,
          onExport: _exportSingleChapter,
          onWriter: _openChapterWriterMode,
          onShowWriterReport: _showWriterEditReport,
          onNewChapter: _openNewChapterWriterMode,
          onReorder: _reorderChapters,
          onMoveOneStep: _moveChapterOneStep,
          onMoveToPosition: _moveChapterToPosition,
          onToggleLock: _toggleChapterLock,
          selectionMode: _chapterSelectionMode,
          selectedIds: _selectedChapterIds,
          onToggleSelection: _toggleChapterSelection,
          onSelectAll: _selectAllUnlockedChapters,
          onDeleteSelected: _deleteSelectedChapters,
          onCloseSelection: _toggleChapterSelectionMode,
          reorderSpeed: _reorderSpeed,
        );
    }
  }

  Widget _bookActionChip(IconData icon, String label, VoidCallback onPressed) {
    return ActionChip(
      avatar: Icon(icon, size: 18),
      label: Text(label),
      onPressed: onPressed,
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentStats = stats;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
          child: Card(
            elevation: 0,
            color: const Color(0xFFF1E4CC),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Antik Medeniyetlerde Reptilyanların İzinde',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF2B2117),
                          height: 1.05,
                        ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${currentStats.chapterCount} bölüm • yaklaşık ${currentStats.estimatedPages} sayfa',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C)),
                  ),
                  const SizedBox(height: 6),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _bookActionChip(Icons.library_add_outlined, 'Düzenle', widget.onOpenBookAdmin),
                        const SizedBox(width: 6),
                        _bookActionChip(Icons.upload_file_outlined, 'Word/PDF yükle', () => _importDocumentFiles(context)),
                        const SizedBox(width: 6),
                        _bookActionChip(
                          _chapterSelectionMode ? Icons.close : Icons.library_add_check_outlined,
                          _chapterSelectionMode ? 'Seçimi kapat' : 'Bölüm seç',
                          _toggleChapterSelectionMode,
                        ),
                        const SizedBox(width: 6),
                        _bookActionChip(Icons.auto_awesome, 'Akıllı sırala', () => _openSmartChapterSort(context)),
                        const SizedBox(width: 6),
                        _bookActionChip(Icons.speed, 'Taşıma: $_reorderSpeedLabel', () => _chooseReorderSpeed(context)),
                        const SizedBox(width: 6),
                        _bookActionChip(Icons.inventory_2_outlined, 'Yayınevi Paket', () => _exportPublisherPackage(context)),
                        if (_canUndoBookChange) ...[
                          const SizedBox(width: 6),
                          _bookActionChip(Icons.undo_outlined, 'Geri al', _undoLastBookChange),
                        ],
                      ],
                    ),
                  ),
                  if (operationStatus.trim().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      operationStatus,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xFF5B452C), height: 1.15, fontSize: 12),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 4),
          child: Material(
            elevation: 6,
            color: Colors.transparent,
            child: Row(
              children: [
                _tabButton('bolumler', Icons.menu_book_outlined, 'Bölümler'),
                _tabButton('durum', Icons.analytics_outlined, 'Durum'),
                _tabButton('arama', Icons.search_outlined, 'Ara'),
                _tabButton('eksikler', Icons.checklist_outlined, 'Eksikler'),
              ],
            ),
          ),
        ),
        Expanded(child: _activeTabBody()),
      ],
    );
  }
}

class _BookChaptersTab extends StatelessWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;
  final void Function(AppContent item) onDelete;
  final void Function(BuildContext context, AppContent item, int index) onExport;
  final void Function(BuildContext context, AppContent item, int index) onWriter;
  final void Function(BuildContext context, AppContent item, int index) onShowWriterReport;
  final void Function(BuildContext context) onNewChapter;
  final Future<void> Function(int oldIndex, int newIndex) onReorder;
  final Future<void> Function(int index, int direction) onMoveOneStep;
  final Future<void> Function(int index) onMoveToPosition;
  final Future<void> Function(AppContent item) onToggleLock;
  final bool selectionMode;
  final Set<String> selectedIds;
  final void Function(AppContent item) onToggleSelection;
  final VoidCallback onSelectAll;
  final Future<void> Function() onDeleteSelected;
  final VoidCallback onCloseSelection;
  final double reorderSpeed;

  const _BookChaptersTab({
    required this.items,
    required this.onEdit,
    required this.onDelete,
    required this.onExport,
    required this.onWriter,
    required this.onShowWriterReport,
    required this.onNewChapter,
    required this.onReorder,
    required this.onMoveOneStep,
    required this.onMoveToPosition,
    required this.onToggleLock,
    required this.selectionMode,
    required this.selectedIds,
    required this.onToggleSelection,
    required this.onSelectAll,
    required this.onDeleteSelected,
    required this.onCloseSelection,
    required this.reorderSpeed,
  });

  Widget _smallAction({
    required IconData icon,
    required String tooltip,
    required VoidCallback onPressed,
  }) {
    return IconButton(
      tooltip: tooltip,
      icon: Icon(icon, size: 22),
      visualDensity: VisualDensity.compact,
      padding: const EdgeInsets.all(6),
      constraints: const BoxConstraints(minWidth: 38, minHeight: 38),
      onPressed: onPressed,
    );
  }

  Widget _headerCard(BuildContext context, BookStats stats) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: selectionMode
              ? Row(
                  children: [
                    const Icon(Icons.library_add_check_outlined, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${selectedIds.length} bölüm seçildi', style: const TextStyle(fontWeight: FontWeight.bold)),
                          const Text('Kartlara dokunarak seçin; kilitli bölümler silinmez.', maxLines: 2, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                    IconButton(tooltip: 'Tümünü seç / bırak', onPressed: onSelectAll, icon: const Icon(Icons.select_all)),
                    IconButton(
                      tooltip: 'Seçilenleri sil',
                      onPressed: selectedIds.isEmpty ? null : onDeleteSelected,
                      icon: const Icon(Icons.delete_outline),
                    ),
                    IconButton(tooltip: 'Seçimi kapat', onPressed: onCloseSelection, icon: const Icon(Icons.close)),
                  ],
                )
              : Row(
                  children: [
                    const Icon(Icons.auto_stories_outlined, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Bölüm listesi • yaklaşık ${stats.estimatedPages} sayfa', maxLines: 1, overflow: TextOverflow.ellipsis),
                          const Text('Sürükle, okları kullan veya sıra numarasını yaz. Uzun basarak çoklu seçime geçebilirsin.', maxLines: 2, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Yazar Modu: Yeni bölüm yaz',
                      icon: const Icon(Icons.auto_fix_high_outlined),
                      onPressed: () => onNewChapter(context),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _chapterCard(BuildContext context, int index) {
    final item = items[index];
    final chapterPages = BookStats.estimatedPagesForItem(item);

    final selected = selectedIds.contains(item.id);
    final leading = selectionMode
        ? Checkbox(
            value: selected,
            onChanged: item.locked ? null : (_) => onToggleSelection(item),
          )
        : item.hasImage
            ? ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(width: 54, height: 68, child: GalleryImage(item: item, fit: BoxFit.cover)),
              )
            : CircleAvatar(radius: 27, child: Text(isBookFrontMatter(item.title, item.category) ? 'Ö' : '${index + 1}'));

    return Card(
      key: ValueKey('book_chapter_${item.id}'),
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: selectionMode
            ? () => onToggleSelection(item)
            : () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BookReaderPage(items: items, initialIndex: index, onEdit: onEdit)),
                ),
        onLongPress: () => onToggleSelection(item),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  leading,
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.locked ? '🔒 ${cleanBookChapterTitle(item.title)}' : cleanBookChapterTitle(item.title),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          softWrap: true,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            height: 1.18,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${bookChapterLabelFromList(items, index)} • yaklaşık $chapterPages sayfa',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (!selectionMode)
                    ReorderableDragStartListener(
                      index: index,
                      child: const Padding(
                        padding: EdgeInsets.all(6),
                        child: Icon(Icons.drag_handle, size: 28),
                      ),
                    ),
                ],
              ),
              if (!selectionMode) ...[
                const SizedBox(height: 6),
                Wrap(
                  alignment: WrapAlignment.end,
                  spacing: 0,
                  runSpacing: 0,
                  children: [
                  _smallAction(
                    tooltip: 'Bir sıra yukarı al',
                    icon: Icons.keyboard_arrow_up,
                    onPressed: index == 0 ? () {} : () => onMoveOneStep(index, -1),
                  ),
                  _smallAction(
                    tooltip: 'Bir sıra aşağı al',
                    icon: Icons.keyboard_arrow_down,
                    onPressed: index == items.length - 1 ? () {} : () => onMoveOneStep(index, 1),
                  ),
                  _smallAction(
                    tooltip: 'Belirli sıraya taşı',
                    icon: Icons.format_list_numbered,
                    onPressed: () => onMoveToPosition(index),
                  ),
                  _smallAction(
                    tooltip: item.locked ? 'Bölüm kilidini aç' : 'Bölümü kilitle',
                    icon: item.locked ? Icons.lock_outline : Icons.lock_open_outlined,
                    onPressed: () => onToggleLock(item),
                  ),
                  _smallAction(
                    tooltip: 'Bölümü düzenle',
                    icon: Icons.edit_outlined,
                    onPressed: item.locked
                        ? () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bu bölüm kilitli. Düzenlemek için önce kilidi aç.')))
                        : () => onEdit(item),
                  ),
                  _smallAction(
                    tooltip: 'Bölümü sil',
                    icon: Icons.delete_outline,
                    onPressed: () => onDelete(item),
                  ),
                  _smallAction(
                    tooltip: 'Uygulama içi yazar modu',
                    icon: Icons.auto_fix_high_outlined,
                    onPressed: () => onWriter(context, item, index),
                  ),
                  if (item.writerEditReport.trim().isNotEmpty)
                    _smallAction(
                      tooltip: 'Yapay zekâ değişikliklerini gör',
                      icon: Icons.fact_check_outlined,
                      onPressed: () => onShowWriterReport(context, item, index),
                    ),
                    _smallAction(
                      tooltip: 'Bölümü Word/PDF aktar',
                      icon: Icons.ios_share_outlined,
                      onPressed: () => onExport(context, item, index),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final stats = BookStats.from(items);

    if (items.isEmpty) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 120),
        children: [
          _headerCard(context, stats),
          const EmptyPanel(text: 'Kitap alanı boş. Yalnızca yüklediğiniz veya kendiniz eklediğiniz bölümler burada görünür.'),
        ],
      );
    }

    return Column(
      children: [
        _headerCard(context, stats),
        Expanded(
          child: ReorderableListView.builder(
            buildDefaultDragHandles: false,
            autoScrollerVelocityScalar: reorderSpeed,
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 120),
            itemCount: items.length,
            onReorder: (oldIndex, newIndex) => onReorder(oldIndex, newIndex),
            itemBuilder: (context, index) => _chapterCard(context, index),
          ),
        ),
      ],
    );
  }
}


class _BookSearchTab extends StatefulWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;

  const _BookSearchTab({required this.items, required this.onEdit});

  @override
  State<_BookSearchTab> createState() => _BookSearchTabState();
}

class _BookSearchTabState extends State<_BookSearchTab> {
  final controller = TextEditingController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  List<int> _matches() {
    final q = controller.text.trim().toLowerCase();
    if (q.isEmpty) return List<int>.generate(widget.items.length, (index) => index);

    final result = <int>[];
    for (var i = 0; i < widget.items.length; i++) {
      final item = widget.items[i];
      final haystack = '${item.title}\n${item.category}\n${item.summary}\n${item.body}\n${item.source}'.toLowerCase();
      if (haystack.contains(q)) result.add(i);
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final matches = _matches();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 140),
      children: [
        TextField(
          controller: controller,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search_outlined),
            labelText: 'Bölüm içinde ara',
            hintText: 'Kelime, yer, kişi veya kaynak ara...',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        Text('${matches.length} sonuç', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (matches.isEmpty)
          const EmptyPanel(text: 'Aradığın kelimeye uygun bölüm bulunamadı.')
        else
          ...matches.map((index) {
            final item = widget.items[index];
            final label = bookChapterLabelFromList(widget.items, index);
            return Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: CircleAvatar(child: Text('${index + 1}')),
                title: Text(item.locked ? '🔒 ${cleanBookChapterTitle(item.title)}' : cleanBookChapterTitle(item.title), maxLines: 2, overflow: TextOverflow.ellipsis),
                subtitle: Text('$label • yaklaşık ${BookStats.estimatedPagesForItem(item)} sayfa', maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BookReaderPage(items: widget.items, initialIndex: index, onEdit: widget.onEdit)),
                ),
              ),
            );
          }),
      ],
    );
  }
}

class _BookStatusTab extends StatelessWidget {
  final BookStats stats;
  final String operationStatus;
  final List<AppContent> items;
  final bool canUndo;
  final VoidCallback onUndo;

  const _BookStatusTab({
    required this.stats,
    required this.operationStatus,
    required this.items,
    required this.canUndo,
    required this.onUndo,
  });

  int _visualMarkerCount(AppContent item) {
    return item.body.split('\n').where((line) {
      final value = line.trim().toLowerCase().replaceAll('[', '').replaceAll(']', '');
      return value == 'görsel' || value == 'gorsel' || value.startsWith('görsel ') || value.startsWith('gorsel ');
    }).length;
  }

  bool _hasSourceOrLicense(AppContent item) {
    final value = '${item.source}\n${item.body}\n${item.summary}'.toLowerCase();
    return item.source.trim().isNotEmpty ||
        value.contains('kaynak:') ||
        value.contains('lisans:') ||
        value.contains('wikimedia commons') ||
        value.contains('public domain') ||
        value.contains('creative commons') ||
        value.contains('cc by') ||
        value.contains('cc-by') ||
        value.contains('museum') ||
        value.contains('müze') ||
        value.contains('library') ||
        value.contains('kütüphane');
  }

  @override
  Widget build(BuildContext context) {
    final missingImageCount = stats.chapterCount - stats.imageCount;
    final safeMissingImages = missingImageCount < 0 ? 0 : missingImageCount;
    final extraVisualPages = stats.imageAwarePages - stats.textOnlyPages;
    final safeExtraVisualPages = extraVisualPages < 0 ? 0 : extraVisualPages;
    final targetPages = 300;
    final progress = stats.imageAwarePages <= 0 ? 0.0 : (stats.imageAwarePages / targetPages).clamp(0.0, 1.0).toDouble();
    final missingInlineVisuals = items.fold<int>(0, (sum, item) {
      final markers = _visualMarkerCount(item);
      final selected = item.cleanInlineImagePaths.length;
      return sum + (markers > selected ? markers - selected : 0);
    });
    final sourceCount = items.where(_hasSourceOrLicense).length;
    final lockedCount = items.where((item) => item.locked).length;

    Widget row(IconData icon, String title, String value, String note) {
      return Card(
        elevation: 0,
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          leading: Icon(icon, size: 30),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(note),
          trailing: Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 150),
      children: [
        Text('Yayın Hazırlık Durumu', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('300 sayfa hedefi, görseller, eksikler, kaynaklar ve güvenlik kontrolleri burada görünür.'),
        const SizedBox(height: 12),
        Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('300 sayfa hedefi', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                LinearProgressIndicator(value: progress),
                const SizedBox(height: 8),
                Text('${stats.imageAwarePages} / $targetPages sayfa • kalan yaklaşık ${stats.imageAwarePages >= targetPages ? 0 : targetPages - stats.imageAwarePages} sayfa'),
                if (canUndo) ...[
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: onUndo,
                    icon: const Icon(Icons.undo_outlined),
                    label: const Text('Son işlemi geri al'),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        row(Icons.auto_stories_outlined, 'Görselli kitap tahmini', '${stats.imageAwarePages}', 'Yazı + görseller + bölüm başlangıç payı birlikte hesaplanır.'),
        row(Icons.text_fields_outlined, 'Sadece metin hesabı', '${stats.textOnlyPages}', 'Görseller hiç yokmuş gibi yalnızca kelimeye göre tahmin.'),
        row(Icons.add_photo_alternate_outlined, 'Görsellerin sayfa etkisi', '+$safeExtraVisualPages', 'Görsellerin ve dizgi boşluklarının tahmini eklediği sayfa.'),
        row(Icons.image_outlined, 'Toplam görsel', '${stats.imageCount}', 'Ana görseller ve metin içi görseller birlikte sayılır.'),
        row(Icons.broken_image_outlined, 'Metin içi eksik görsel', '$missingInlineVisuals', 'Metinde görsel yazıp görsel seçilmeyen yerlerin sayısı.'),
        row(Icons.link_outlined, 'Kaynak bilgisi olan bölüm', '$sourceCount', 'Görsel altında Kaynak/Lisans yazıyorsa yeterli sayılır.'),
        row(Icons.lock_outline, 'Kilitli bölüm', '$lockedCount', 'Yanlışlıkla değişmesin diye kilitlenen bölüm sayısı.'),
        row(Icons.broken_image_outlined, 'Eksik görsel', '$safeMissingImages', 'Görseli olmayan bölüm sayısı.'),
        row(Icons.view_list_outlined, 'Toplam bölüm', '${stats.chapterCount}', 'Word’den veya elle eklenen bölüm sayısı.'),
        row(Icons.notes_outlined, 'Kelime sayısı', '${stats.wordCount}', 'Yaklaşık toplam kelime sayısı.'),
        row(Icons.auto_fix_high_outlined, 'Yazar Modu', 'Açık', 'Program temiz açılır; bölüm/Word işlemleri yalnızca sen butona basınca açılır.'),
        const SizedBox(height: 8),
        InfoPanel(
          title: 'Hesaplama mantığı',
          text: BookStats.imageCalculationNote(),
        ),
        const SizedBox(height: 8),
        InfoPanel(title: 'Son işlem', text: operationStatus),
      ],
    );
  }
}

class _BookMissingTab extends StatelessWidget {
  final BookStats stats;
  final List<AppContent> items;

  const _BookMissingTab({required this.stats, required this.items});

  bool _hasXmlNoise(AppContent item) {
    final value = '${item.title}\n${item.category}\n${item.body}';
    return RegExp(r'<\/?(?:w|xml|r|a|wp|pic|mc|v):|w:ascii|rFonts|document\.xml', caseSensitive: false).hasMatch(value);
  }

  bool _hasSourceOrLicense(AppContent item) {
    final value = '${item.source}\n${item.body}\n${item.summary}'.toLowerCase();
    return item.source.trim().isNotEmpty ||
        value.contains('kaynak:') ||
        value.contains('lisans:') ||
        value.contains('wikimedia commons') ||
        value.contains('public domain') ||
        value.contains('creative commons') ||
        value.contains('cc by') ||
        value.contains('cc-by') ||
        value.contains('museum') ||
        value.contains('müze') ||
        value.contains('library') ||
        value.contains('kütüphane');
  }

  @override
  Widget build(BuildContext context) {
    final missing = <String>[...stats.missingItems];
    final missingTitles = items.where((item) => item.title.trim().isEmpty).length;
    final missingImages = items.where((item) => item.imageCount == 0).length;
    final missingSources = items.where((item) => item.imageCount > 0 && !_hasSourceOrLicense(item)).length;
    final inlineMissing = items.fold<int>(0, (sum, item) {
      final markerCount = item.body.split('\n').where((line) {
        final value = line.trim().toLowerCase().replaceAll('[', '').replaceAll(']', '');
        return value == 'görsel' || value == 'gorsel' || value.startsWith('görsel ') || value.startsWith('gorsel ');
      }).length;
      final selected = item.cleanInlineImagePaths.length;
      return sum + (markerCount > selected ? markerCount - selected : 0);
    });
    final badXml = items.where(_hasXmlNoise).length;

    if (missingTitles > 0) missing.add('$missingTitles bölümde başlık eksik.');
    if (missingImages > 0) missing.add('$missingImages bölümde görsel eksik.');
    if (inlineMissing > 0) missing.add('$inlineMissing satır arası görsel yeri boş: metinde görsel yazıyor ama dosya seçilmemiş.');
    if (missingSources > 0) missing.add('$missingSources görselli bölümde kaynak/lisans bilgisi görünmüyor. Görselin altında Kaynak: ve Lisans: yazıyorsa ayrıca kaynak alanı doldurman gerekmez.');
    if (badXml > 0) missing.add('$badXml bölümde Word/XML kalıntısı görünüyor; Word dosyasını yeniden yükle.');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 150),
      children: [
        Text('Eksik Kontrolü', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Yayın evine vermeden önce buradaki uyarılara bak.'),
        const SizedBox(height: 14),
        if (missing.isEmpty)
          const InfoPanel(
            title: 'Durum iyi',
            text: 'Temel kitap düzeni için büyük eksik görünmüyor. Yine de kaynakça ve görsel izinlerini ayrıca kontrol et.',
          )
        else
          ...missing.map(
            (item) => Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.warning_amber_outlined),
                title: Text(item, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Düzeltmek için Bölümler sekmesinden ilgili bölümü düzenleyebilirsin.'),
              ),
            ),
          ),
        const SizedBox(height: 12),
        const InfoPanel(
          title: 'Son kontrol listesi',
          text: 'Önsöz/Giriş, bölüm sıralaması, sonuç bölümü, kaynakça, görsel altı Kaynak/Lisans bilgileri, kapak ve arka kapak yazısı kontrol edilmeli.',
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon),
            const SizedBox(height: 8),
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}



class BulkBookPastePage extends StatefulWidget {
  const BulkBookPastePage({super.key});

  @override
  State<BulkBookPastePage> createState() => _BulkBookPastePageState();
}

class _BulkBookPastePageState extends State<BulkBookPastePage> {
  final controller = TextEditingController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _createBook() {
    final chapters = BookImporter.fromPlainText(controller.text);
    if (chapters.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Metinde bölüm bulunamadı.')));
      return;
    }
    Navigator.of(context).pop(chapters);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kitabı toplu yapıştır'),
        actions: [
          TextButton(onPressed: _createBook, child: const Text('Kitaba çevir')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const InfoPanel(
            title: 'Nasıl çalışır?',
            text:
                'Word metnini buraya komple yapıştır. Uygulama “1. Bölüm”, “Bölüm 1” gibi satırları bölüm başı kabul eder. Hemen sonraki satırı bölüm adı yapar. Kopyala-yapıştırda görseller genelde gelmez; görsellerin otomatik gelmesi için DOCX dosyasını Word içe aktar butonuyla seç.',
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            minLines: 18,
            maxLines: null,
            textInputAction: TextInputAction.newline,
            decoration: const InputDecoration(
              labelText: 'Komple kitap metni',
              hintText: 'Word metnini buraya yapıştır...',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _createBook,
            icon: const Icon(Icons.auto_fix_high_outlined),
            label: const Text('Otomatik kitap formatına çevir'),
          ),
        ],
      ),
    );
  }
}

class BookImporter {

  static Future<List<AppContent>> fromDocx({String? path, Uint8List? bytes}) async {
    final docxBytes = bytes ?? (path == null ? null : await File(path).readAsBytes());
    if (docxBytes == null || docxBytes.isEmpty) {
      throw Exception('DOCX dosyası okunamadı.');
    }

    final archive = ZipDecoder().decodeBytes(docxBytes);
    final documentFile = archive.findFile('word/document.xml');
    if (documentFile == null) {
      throw Exception('Bu dosya DOCX gibi görünmüyor.');
    }

    final documentXml = utf8.decode(documentFile.content as List<int>);
    final relMap = _readRelationships(archive);
    final importDir = await _prepareImportDir();

    final lines = <String>[];
    final imagePaths = <String>[];

    final paragraphs = RegExp(r'<w:p(?:\s[^>]*)?>[\s\S]*?</w:p>').allMatches(documentXml);
    for (final paragraphMatch in paragraphs) {
      final paragraphXml = paragraphMatch.group(0) ?? '';
      final paragraphText = _cleanImportedText(_paragraphText(paragraphXml));

      final isHeadingStyle = RegExp(r'<w:pStyle[^>]+w:val="(?:Heading1|Heading2|Title|Baslik|Baslık|Balk|Bölüm|Bolum|Heading)[^"]*"', caseSensitive: false)
          .hasMatch(paragraphXml);

      if (paragraphText.isNotEmpty &&
          !_looksLikeXmlNoise(paragraphText) &&
          !_isIgnoredGenericBookHeading(paragraphText)) {
        if (isHeadingStyle && !_isChapterHeading(paragraphText) && _looksLikeHeadingTitle(paragraphText)) {
          lines.add('Bölüm ${lines.where(_isChapterHeading).length + 1}: $paragraphText');
        } else {
          lines.add(paragraphText);
        }
      }

      final embeds = RegExp(r'r:embed="([^"]+)"').allMatches(paragraphXml);
      for (final embed in embeds) {
        final rId = embed.group(1) ?? '';
        final target = relMap[rId];
        if (target == null) continue;

        final savedPath = await _saveImageFromArchive(archive, target, importDir);
        if (savedPath.isNotEmpty) {
          imagePaths.add(savedPath);
          lines.add('görsel');
        }
      }
    }

    return _buildChaptersFromLines(lines, imagePathsByMarker: imagePaths);
  }

  static Future<Directory> _prepareImportDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final importDir = Directory('${dir.path}/word_imports');
    if (!await importDir.exists()) {
      await importDir.create(recursive: true);
    }
    return importDir;
  }

  static Map<String, String> _readRelationships(Archive archive) {
    final relFile = archive.findFile('word/_rels/document.xml.rels');
    if (relFile == null) return {};
    final xml = utf8.decode(relFile.content as List<int>);
    final map = <String, String>{};
    final rels = RegExp(r'<Relationship[^>]+Id="([^"]+)"[^>]+Target="([^"]+)"[^>]*/?>').allMatches(xml);

    for (final rel in rels) {
      final id = rel.group(1) ?? '';
      final targetRaw = _decodeXml(rel.group(2) ?? '');
      if (id.isEmpty || targetRaw.isEmpty || targetRaw.startsWith('http')) continue;

      var target = targetRaw;
      if (!target.startsWith('word/')) {
        target = 'word/$target';
      }
      target = target.replaceAll('word/../', '');
      map[id] = target;
    }
    return map;
  }

  static Future<String> _saveImageFromArchive(Archive archive, String target, Directory importDir) async {
    final candidates = <String>[
      target,
      target.replaceFirst('word/', ''),
      'word/$target',
    ];

    ArchiveFile? imageFile;
    for (final candidate in candidates) {
      imageFile = archive.findFile(candidate);
      if (imageFile != null) break;
    }
    if (imageFile == null) return '';

    final extensionRaw = target.split('.').last.toLowerCase();
    final extension = ['jpg', 'jpeg', 'png', 'webp'].contains(extensionRaw) ? extensionRaw : 'jpg';
    final out = File('${importDir.path}/word_${DateTime.now().microsecondsSinceEpoch}_${imageFile.name.hashCode}.$extension');
    await out.writeAsBytes(imageFile.content as List<int>, flush: true);
    return out.path;
  }

  static String _paragraphText(String xml) {
    final buffer = StringBuffer();
    final texts = RegExp(r'<w:t(?:\s[^>]*)?>([\s\S]*?)</w:t>').allMatches(xml);
    for (final t in texts) {
      buffer.write(_decodeXml(t.group(1) ?? ''));
    }
    return buffer.toString();
  }

  static String _decodeXml(String value) {
    return value
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&');
  }

  static String _cleanImportedText(String value) {
    var cleaned = _fixMojibake(_decodeXml(value));
    cleaned = cleaned.replaceAll(RegExp(r'<[^>]+>'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'\b(?:w|r|xml|a|wp|pic|mc|v):[A-Za-z0-9_-]+\b'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'\b(?:rFonts|eastAsia|ascii|hAnsi|cs)\b', caseSensitive: false), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ').trim();
    cleaned = cleaned.replaceAll(RegExp(r'^Seçilmemiş görsel alanı\\.?$', caseSensitive: false), 'Bölüm arası');
    return cleaned;
  }

  static String _fixMojibake(String value) {
    return value
        .replaceAll('Ä±', 'ı')
        .replaceAll('Ä°', 'İ')
        .replaceAll('ÅŸ', 'ş')
        .replaceAll('Åž', 'Ş')
        .replaceAll('ÄŸ', 'ğ')
        .replaceAll('Äž', 'Ğ')
        .replaceAll('Ã¼', 'ü')
        .replaceAll('Ãœ', 'Ü')
        .replaceAll('Ã¶', 'ö')
        .replaceAll('Ã–', 'Ö')
        .replaceAll('Ã§', 'ç')
        .replaceAll('Ã‡', 'Ç')
        .replaceAll('â€™', '’')
        .replaceAll('â€œ', '“')
        .replaceAll('â€', '”')
        .replaceAll('â€“', '–')
        .replaceAll('â€”', '—');
  }

  static bool _isIgnoredGenericBookHeading(String value) {
    final normalized = _normalizeBookLabelText(value)
        .replaceAll(RegExp(r'[^a-z0-9 ]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    // Bunlar kitabın genel/tekrarlanan üst başlıklarıdır; bağımsız bölüm değildir.
    // Word veya düz metin içe aktarımında her tekrarlandığında yeni bölüm açılmasını engeller.
    const ignoredHeadings = <String>{
      'antik medeniyetler',
      'antik medeniyetlerde',
      'antik medeniyetlerde reptilyanlarin izinde',
      'antik medeniyetlerde reptilyanlarin izleri',
      'antik medeniyetlerde reptilyan izi',
    };

    return ignoredHeadings.contains(normalized);
  }

  static bool _looksLikeXmlNoise(String value) {
    final lowered = value.toLowerCase();
    return lowered.contains('<w:') ||
        lowered.contains('</w:') ||
        lowered.contains('rfonts') ||
        lowered.contains('w:ascii') ||
        lowered.contains('w:eastasia') ||
        lowered.contains('document.xml') ||
        lowered.contains('word/fonttable') ||
        RegExp(r'<\/?[a-z]+:[^>]+>').hasMatch(lowered);
  }

  static bool _looksLikeHeadingTitle(String line) {
    if (line.length > 180) return false;
    if (_looksLikeXmlNoise(line)) return false;
    final lower = line.toLowerCase();
    if (lower.endsWith('.') && line.length > 80) return false;
    return true;
  }

  static List<AppContent> fromPlainText(String rawText) {
    final lines = rawText.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n');
    return _buildChaptersFromLines(lines, imagePathsByMarker: const []);
  }






  static List<AppContent> _buildChaptersFromLines(List<String> rawLines, {required List<String> imagePathsByMarker}) {
    final drafts = <_BookDraft>[];
    _BookDraft? current;
    var imageCursor = 0;

    void startChapter(String label) {
      if (current != null && current!.hasContent) {
        drafts.add(current!);
      }
      current = _BookDraft(category: _cleanChapterLabel(label));
    }

    void ensureChapter() {
      current ??= _BookDraft(category: 'Giriş');
    }

    void addImageMarker() {
      ensureChapter();
      if (imageCursor < imagePathsByMarker.length) {
        current!.inlineImagePaths.add(imagePathsByMarker[imageCursor]);
        imageCursor++;
      }
      current!.bodyLines.add('görsel');
    }

    for (final rawLine in rawLines) {
      final line = _cleanImportedText(rawLine).trim();
      if (line.isEmpty || _looksLikeXmlNoise(line)) {
        current?.bodyLines.add('');
        continue;
      }

      if (_isIgnoredGenericBookHeading(line)) {
        continue;
      }

      if (_isImageMarker(line)) {
        addImageMarker();
        continue;
      }

      if (_isChapterHeading(line)) {
        startChapter(line);
        final title = _titleFromChapterHeading(line);
        if (title.trim().isNotEmpty) {
          current!.title = title.trim();
        }
        continue;
      }

      ensureChapter();
      if (current!.title.trim().isEmpty && !_looksLikeParagraph(line)) {
        current!.title = line;
      } else if (_shouldMergeIntoTitle(current!.title, line, current!.bodyLines)) {
        current!.title = '${current!.title.trim()} ${line.trim()}'.trim();
      } else {
        current!.bodyLines.add(line);
      }
    }

    if (current != null && current!.hasContent) {
      drafts.add(current!);
    }

    for (var i = 0; i < drafts.length; i++) {
      if (drafts[i].title.trim().isEmpty) {
        drafts[i].title = drafts[i].category.trim().isEmpty ? '${i + 1}. Bölüm' : drafts[i].category;
      }
      if (drafts[i].category.trim().isEmpty || drafts[i].category == 'Giriş') {
        drafts[i].category = i == 0 ? 'Giriş' : '${i + 1}. Bölüm';
      }
    }

    return List.generate(drafts.length, (index) {
      final draft = drafts[index];
      return AppContent(
        id: 'book_import_${DateTime.now().microsecondsSinceEpoch}_$index',
        type: ContentTypes.book,
        title: cleanBookChapterTitle(draft.title.trim()),
        category: draft.category.trim(),
        summary: '',
        body: [
          if (bookChapterTitleOverflow(draft.title).isNotEmpty) bookChapterTitleOverflow(draft.title),
          draft.bodyLines.join('\n').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim(),
        ].where((part) => part.trim().isNotEmpty).join('\n\n'),
        inlineImagePaths: draft.inlineImagePaths,
      );
    });
  }

  static bool _isImageMarker(String line) {
    final normalized = line.toLowerCase().replaceAll('[', '').replaceAll(']', '').trim();
    return normalized == 'görsel' || normalized == 'gorsel' || normalized.startsWith('görsel ') || normalized.startsWith('gorsel ');
  }

  static bool _isChapterHeading(String line) {
    final upper = line.toUpperCase()
        .replaceAll('İ', 'I')
        .replaceAll('Ş', 'S')
        .replaceAll('Ğ', 'G')
        .replaceAll('Ü', 'U')
        .replaceAll('Ö', 'O')
        .replaceAll('Ç', 'C');
    return RegExp(r'^\d+[\.\-]?\s*BOLUM\b').hasMatch(upper) ||
        RegExp(r'^BOLUM\s*\d+').hasMatch(upper) ||
        RegExp(r'^\d+[\.\-]\s+').hasMatch(upper) && upper.contains('BOLUM');
  }

  static String _cleanChapterLabel(String line) {
    final match = RegExp(r'^(\d+[\.\-]?\s*(?:Bölüm|BOLUM)|(?:Bölüm|BOLUM)\s*\d+)', caseSensitive: false).firstMatch(line);
    if (match == null) return line;
    return match.group(1) ?? line;
  }

  static String _titleFromChapterHeading(String line) {
    final trimmed = line.trim();

    // Örn: "2. Bölüm ANUNNAKİLER:" satırında "ANUNNAKİLER:" kısmını başlık olarak koru.
    final withoutChapterPrefix = trimmed
        .replaceFirst(
          RegExp(r'^\s*(?:\d+[\.\-]?\s*(?:Bölüm|BOLUM)|(?:Bölüm|BOLUM)\s*\d+)\s*[:\-–—]?\s*', caseSensitive: false),
          '',
        )
        .trim();

    if (withoutChapterPrefix.isNotEmpty && withoutChapterPrefix != trimmed) {
      return withoutChapterPrefix;
    }

    final colonIndex = trimmed.indexOf(':');
    if (colonIndex >= 0 && colonIndex < trimmed.length - 1) {
      return trimmed.substring(colonIndex + 1).trim();
    }
    return '';
  }

  static bool _isMostlyUpperTitleLine(String line) {
    final letters = line.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
    if (letters.isEmpty) return false;
    final upperLetters = letters.replaceAll(RegExp(r'[^A-ZÇĞİÖŞÜ]'), '');
    return upperLetters.length / letters.length > 0.70;
  }

  static bool _shouldMergeIntoTitle(String currentTitle, String nextLine, List<String> bodyLines) {
    if (currentTitle.trim().isEmpty || nextLine.trim().isEmpty) return false;
    if (bodyLines.any((line) => line.trim().isNotEmpty)) return false;
    if (nextLine.length > 140) return false;

    final currentUpper = _isMostlyUpperTitleLine(currentTitle);
    final nextUpper = _isMostlyUpperTitleLine(nextLine);

    // Başlık iki satıra bölündüyse birleştir:
    // "ANUNNAKİLER:" + "GÖKTEN İNENLER..." gibi.
    if (currentTitle.trim().endsWith(':') && nextUpper) return true;
    if (currentUpper && nextUpper) return true;

    return false;
  }

  static bool _looksLikeParagraph(String line) {
    if (line.length > 95) return true;
    if (RegExp(r'[.!?…:]\s*$').hasMatch(line) && line.length > 45) return true;
    final letters = line.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
    final upperLetters = letters.replaceAll(RegExp(r'[^A-ZÇĞİÖŞÜ]'), '');
    if (letters.isNotEmpty && upperLetters.length / letters.length > 0.75 && line.length < 95) {
      return false;
    }
    final lower = line.toLowerCase();
    final sentenceHints = ['dır', 'dir', 'olarak', 'çünkü', 'ancak', 'ile ', ' ve ', ' bu ', ' göre ', 'dolayısıyla', 'gerçeklik', 'insanlar'];
    return sentenceHints.any(lower.contains);
  }
}

class _BookDraft {
  String title;
  String category;
  final List<String> bodyLines;
  final List<String> inlineImagePaths;

  _BookDraft({
    this.title = '',
    required this.category,
    List<String>? bodyLines,
    List<String>? inlineImagePaths,
  })  : bodyLines = bodyLines ?? [],
        inlineImagePaths = inlineImagePaths ?? [];

  bool get hasContent => title.trim().isNotEmpty || bodyLines.any((line) => line.trim().isNotEmpty) || inlineImagePaths.isNotEmpty;
}

class _ExportImageData {
  final Uint8List bytes;
  final String extension;
  final String contentType;
  final int width;
  final int height;

  const _ExportImageData({
    required this.bytes,
    required this.extension,
    required this.contentType,
    required this.width,
    required this.height,
  });
}

typedef ExportProgressCallback = void Function(String message, int current, int total);

class BookExporter {
  static const String defaultBookTitle = 'Antik Medeniyetlerde Reptilyanların İzinde';
  static const String defaultAuthor = 'Altay Aytın';

  static String _safeFileName(String value) {
    final cleaned = value
        .replaceAll(RegExp(r'[^\w\sığüşöçİĞÜŞÖÇ-]', unicode: true), '')
        .trim()
        .replaceAll(RegExp(r'\s+'), '_');
    return cleaned.isEmpty ? 'kitap_taslagi' : cleaned;
  }

  static String _safeArchiveSegment(String value) {
    final cleaned = _safeFileName(value).replaceAll(RegExp(r'_+'), '_');
    return cleaned.isEmpty ? 'dosya' : cleaned;
  }

  static String _cleanExportText(String value) {
    var result = value.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    result = result
        .replaceAll(RegExp(r'<\?xml[^>]*>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'</?(?:w|wp|a|pic|r|mc|v|o|m|cp|dc|dcterms|vt):[^>]*>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'</?(?:document|body|p|r|t|tbl|tr|tc|styles|style|relationships|relationship)[^>]*>', caseSensitive: false), ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&#39;', "'")
        .replaceAll(RegExp(r'[\u0000-\u0008\u000B\u000C\u000E-\u001F]'), '');

    final lines = result.split('\n');
    final cleanedLines = <String>[];
    var previousBlank = false;
    for (final raw in lines) {
      final line = raw.replaceAll(RegExp(r'[\t ]+'), ' ').trim();
      final isBlank = line.isEmpty;
      if (isBlank && previousBlank) continue;
      cleanedLines.add(line);
      previousBlank = isBlank;
    }
    return cleanedLines.join('\n').trim();
  }

  static String _xml(String value) {
    return _cleanExportText(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&apos;');
  }

  static bool _isJpeg(Uint8List bytes) => bytes.length >= 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF;
  static bool _isPng(Uint8List bytes) =>
      bytes.length >= 8 &&
      bytes[0] == 0x89 &&
      bytes[1] == 0x50 &&
      bytes[2] == 0x4E &&
      bytes[3] == 0x47 &&
      bytes[4] == 0x0D &&
      bytes[5] == 0x0A &&
      bytes[6] == 0x1A &&
      bytes[7] == 0x0A;

  static Future<Uint8List?> _readExportImageBytes(String source) async {
    final clean = source.trim();
    if (clean.isEmpty) return null;
    final uri = Uri.tryParse(clean);
    final isNetwork = uri != null && (uri.scheme == 'http' || uri.scheme == 'https');
    if (!isNetwork) {
      final file = File(clean);
      if (!await file.exists() || await file.length() == 0) return null;
      return file.readAsBytes();
    }

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final request = await client.getUrl(uri);
      request.followRedirects = true;
      request.maxRedirects = 5;
      request.headers.set(HttpHeaders.userAgentHeader, 'AltayParanormal/84');
      final response = await request.close().timeout(const Duration(seconds: 30));
      if (response.statusCode < 200 || response.statusCode >= 300) return null;
      final builder = BytesBuilder(copy: false);
      await for (final chunk in response) {
        builder.add(chunk);
        if (builder.length > 30 * 1024 * 1024) return null;
      }
      final bytes = builder.takeBytes();
      return bytes.isEmpty ? null : bytes;
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }

  static Future<_ExportImageData?> _loadExportImage(String pathOrUrl) async {
    final clean = pathOrUrl.trim();
    if (clean.isEmpty) return null;
    final uri = Uri.tryParse(clean);
    final isNetwork = uri != null && (uri.scheme == 'http' || uri.scheme == 'https');

    // Yerel büyük fotoğrafları Dart belleğine ham hâliyle almadan önce Android
    // tarafında güvenli boyuta indirir. Ağ görselleri aşağıdaki Dart yedeğiyle
    // indirilip DOCX içine gömülür.
    if (!isNetwork) {
      final source = File(clean);
      if (!await source.exists() || await source.length() == 0) return null;
      try {
        final prepared = await docxPickerChannel.invokeMapMethod<String, dynamic>(
          'prepareExportImage',
          <String, Object>{'path': clean, 'maxDimension': 1600},
        );
        final preparedPath = prepared?['path']?.toString() ?? '';
        if (preparedPath.isNotEmpty) {
          final preparedFile = File(preparedPath);
          if (await preparedFile.exists() && await preparedFile.length() > 0) {
            final bytes = await preparedFile.readAsBytes();
            return _ExportImageData(
              bytes: bytes,
              extension: prepared?['extension']?.toString() == 'png' ? 'png' : 'jpg',
              contentType: prepared?['extension']?.toString() == 'png' ? 'image/png' : 'image/jpeg',
              width: (prepared?['width'] as num?)?.toInt() ?? 1,
              height: (prepared?['height'] as num?)?.toInt() ?? 1,
            );
          }
        }
      } catch (_) {
        // Eski Android katmanıyla açılırsa aşağıdaki güvenli Dart yedeği kullanılır.
      }
    }

    try {
      final original = await _readExportImageBytes(clean);
      if (original == null || original.isEmpty) return null;
      final result = await Isolate.run<Map<String, Object?>?>(() {
        final decodedOriginal = im.decodeImage(original);
        if (decodedOriginal == null) return null;
        var decoded = im.bakeOrientation(decodedOriginal);
        const maxDimension = 1600;
        if (decoded.width > maxDimension || decoded.height > maxDimension) {
          if (decoded.width >= decoded.height) {
            decoded = im.copyResize(decoded, width: maxDimension, interpolation: im.Interpolation.average);
          } else {
            decoded = im.copyResize(decoded, height: maxDimension, interpolation: im.Interpolation.average);
          }
        }
        final bytes = Uint8List.fromList(im.encodeJpg(decoded, quality: 88));
        return <String, Object?>{
          'bytes': bytes,
          'extension': 'jpg',
          'contentType': 'image/jpeg',
          'width': decoded.width,
          'height': decoded.height,
        };
      });
      if (result == null) return null;
      return _ExportImageData(
        bytes: result['bytes']! as Uint8List,
        extension: result['extension']! as String,
        contentType: result['contentType']! as String,
        width: result['width']! as int,
        height: result['height']! as int,
      );
    } catch (_) {
      return null;
    }
  }

  static List<int> _fitImageEmu(_ExportImageData image) {
    // DOCX boyutları piksel değil EMU ister. Eski hesaplama piksel değerini
    // doğrudan EMU olarak yazdığı için görseller Word'de mikroskobik kalıyor ve
    // görünmüyordu. 96 DPI karşılığı: 1 piksel = 9525 EMU.
    const emuPerPixelAt96Dpi = 9525.0;
    const maxWidth = 5.55 * 914400.0;
    const maxHeight = 7.15 * 914400.0;
    final naturalWidth = (image.width <= 0 ? 1.0 : image.width.toDouble()) * emuPerPixelAt96Dpi;
    final naturalHeight = (image.height <= 0 ? 1.0 : image.height.toDouble()) * emuPerPixelAt96Dpi;
    final scale = [maxWidth / naturalWidth, maxHeight / naturalHeight, 1.0].reduce((a, b) => a < b ? a : b);
    final fittedWidth = (naturalWidth * scale).round().clamp(1, maxWidth.round()).toInt();
    final fittedHeight = (naturalHeight * scale).round().clamp(1, maxHeight.round()).toInt();
    return [fittedWidth, fittedHeight];
  }

  static String _docxParagraph(
    String text, {
    bool bold = false,
    bool italic = false,
    int size = 23,
    String align = 'both',
    int after = 150,
    int before = 0,
    bool firstLineIndent = true,
    bool keepNext = false,
  }) {
    final safe = _xml(text);
    if (safe.isEmpty) return '<w:p/>';
    final boldTag = bold ? '<w:b/>' : '';
    final italicTag = italic ? '<w:i/>' : '';
    final keepTag = keepNext ? '<w:keepNext/>' : '';
    final indentTag = firstLineIndent ? '<w:ind w:firstLine="360"/>' : '';
    const widowTag = '<w:widowControl/>';
    return '''
<w:p>
  <w:pPr>
    <w:jc w:val="$align"/>
    <w:spacing w:before="$before" w:after="$after" w:line="330" w:lineRule="auto"/>
    $indentTag
    $keepTag
    $widowTag
  </w:pPr>
  <w:r>
    <w:rPr>$boldTag$italicTag<w:sz w:val="$size"/><w:szCs w:val="$size"/></w:rPr>
    <w:t xml:space="preserve">$safe</w:t>
  </w:r>
</w:p>''';
  }

  static String _docxImageXml(String rId, int id, {String caption = '', required int cx, required int cy}) {
    final cap = caption.trim().isEmpty
        ? ''
        : _docxParagraph(caption, size: 18, align: 'center', firstLineIndent: false, italic: true, after: 180);
    return '''
<w:p>
  <w:pPr><w:jc w:val="center"/><w:spacing w:before="120" w:after="100"/></w:pPr>
  <w:r>
    <w:drawing>
      <wp:inline distT="0" distB="0" distL="0" distR="0">
        <wp:extent cx="$cx" cy="$cy"/>
        <wp:docPr id="$id" name="Görsel $id"/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr>
                <pic:cNvPr id="$id" name="Görsel $id"/>
                <pic:cNvPicPr/>
              </pic:nvPicPr>
              <pic:blipFill>
                <a:blip r:embed="$rId"/>
                <a:stretch><a:fillRect/></a:stretch>
              </pic:blipFill>
              <pic:spPr>
                <a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
              </pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing>
  </w:r>
</w:p>
$cap''';
  }

  static void _addArchiveString(Archive archive, String name, String content) {
    final bytes = utf8.encode(content);
    archive.addFile(ArchiveFile(name, bytes.length, bytes));
  }

  static Uint8List _archiveBytes(ArchiveFile file) {
    final content = file.content;
    if (content is Uint8List) return content;
    if (content is List<int>) return Uint8List.fromList(content);
    return Uint8List(0);
  }

  static bool _validDocxBytes(Uint8List bytes) {
    try {
      final archive = ZipDecoder().decodeBytes(bytes);
      final names = archive.files.map((file) => file.name).toSet();
      return names.contains('[Content_Types].xml') &&
          names.contains('word/document.xml') &&
          names.contains('_rels/.rels');
    } catch (_) {
      return false;
    }
  }

  static bool _validPdfBytes(Uint8List bytes) {
    return bytes.length > 5 && String.fromCharCodes(bytes.take(5)) == '%PDF-';
  }

  static Future<pw.ThemeData> _loadPdfTheme() async {
    Future<pw.Font?> loadFont(List<String> paths) async {
      for (final path in paths) {
        try {
          final file = File(path);
          if (await file.exists()) {
            final bytes = await file.readAsBytes();
            final data = ByteData.view(bytes.buffer, bytes.offsetInBytes, bytes.lengthInBytes);
            return pw.Font.ttf(data);
          }
        } catch (_) {}
      }
      return null;
    }

    final regular = await loadFont(const [
      '/system/fonts/Roboto-Regular.ttf',
      '/system/fonts/RobotoStatic-Regular.ttf',
      '/system/fonts/NotoSans-Regular.ttf',
      '/system/fonts/NotoSansDisplay-Regular.ttf',
      '/system/fonts/DroidSans.ttf',
    ]);
    final bold = await loadFont(const [
      '/system/fonts/Roboto-Bold.ttf',
      '/system/fonts/RobotoStatic-Bold.ttf',
      '/system/fonts/NotoSans-Bold.ttf',
      '/system/fonts/NotoSansDisplay-Bold.ttf',
      '/system/fonts/DroidSans-Bold.ttf',
    ]);
    final italic = await loadFont(const [
      '/system/fonts/Roboto-Italic.ttf',
      '/system/fonts/NotoSans-Italic.ttf',
    ]);

    if (regular == null) {
      throw Exception('Türkçe karakterleri destekleyen Android yazı tipi bulunamadı.');
    }
    return pw.ThemeData.withFont(
      base: regular,
      bold: bold ?? regular,
      italic: italic ?? regular,
      boldItalic: bold ?? regular,
    );
  }

  static PdfPageFormat get _bookPageFormat => PdfPageFormat(
        13.5 * PdfPageFormat.cm,
        21 * PdfPageFormat.cm,
      );


  /// PDF MultiPage, tek bir çok uzun Text widget'ını sayfalar arasında
  /// bölemezse "Widget won't fit into the page" hatası verir. Metni
  /// silmeden küçük bloklara ayırır ve çok uzun URL/kelimelere görünmez
  /// kırılma noktaları ekler.
  static String _softBreakPdfTokens(String value) {
    final words = value.split(RegExp(r'\s+'));
    return words.map((word) {
      if (word.length <= 36) return word;
      final buffer = StringBuffer();
      for (var index = 0; index < word.length; index++) {
        if (index > 0 && index % 30 == 0) buffer.write('\u200B');
        buffer.write(word[index]);
      }
      return buffer.toString();
    }).join(' ');
  }

  static List<String> _splitPdfTextBlocks(
    String value, {
    int maxCharacters = 650,
    int maxWords = 90,
  }) {
    final cleaned = _cleanExportText(value).replaceAll('\n', ' ').trim();
    if (cleaned.isEmpty) return const <String>[];

    final words = cleaned.split(RegExp(r'\s+'));
    final blocks = <String>[];
    final current = StringBuffer();
    var wordCount = 0;

    void flush() {
      final text = current.toString().trim();
      if (text.isNotEmpty) blocks.add(_softBreakPdfTokens(text));
      current.clear();
      wordCount = 0;
    }

    for (final rawWord in words) {
      if (rawWord.isEmpty) continue;
      final projectedLength = current.length + (current.isEmpty ? 0 : 1) + rawWord.length;
      if (current.isNotEmpty && (projectedLength > maxCharacters || wordCount >= maxWords)) {
        flush();
      }
      if (current.isNotEmpty) current.write(' ');
      current.write(rawWord);
      wordCount++;
    }
    flush();
    return blocks;
  }

  static void _addPdfTextBlocks(
    List<pw.Widget> target,
    String value, {
    required pw.TextStyle style,
    pw.TextAlign align = pw.TextAlign.left,
    pw.EdgeInsets padding = pw.EdgeInsets.zero,
    int maxCharacters = 650,
    int maxWords = 90,
  }) {
    for (final block in _splitPdfTextBlocks(
      value,
      maxCharacters: maxCharacters,
      maxWords: maxWords,
    )) {
      target.add(
        pw.Padding(
          padding: padding,
          child: pw.Text(
            block,
            textAlign: align,
            style: style,
          ),
        ),
      );
    }
  }

  static Future<File> createDocx(
    List<AppContent> chapters, {
    List<AppContent>? numberingChapters,
    int indexOffset = 0,
    String? fileName,
    bool includeBookTitlePage = true,
    ExportProgressCallback? onProgress,
    int progressOffset = 0,
    int progressTotal = 0,
    String progressLabel = 'Word hazırlanıyor',
  }) async {
    final dir = await getApplicationDocumentsDirectory();
    final temp = await getTemporaryDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final output = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay Aytin Kitap Taslagi')}.docx');
    final runId = DateTime.now().microsecondsSinceEpoch;
    final staging = Directory('${temp.path}/docx_stream_$runId');
    await staging.create(recursive: true);
    await Directory('${staging.path}/word/media').create(recursive: true);
    await Directory('${staging.path}/word/_rels').create(recursive: true);
    await Directory('${staging.path}/_rels').create(recursive: true);
    await Directory('${staging.path}/docProps').create(recursive: true);

    final relationships = <String>[
      '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>',
      '<Relationship Id="rIdSettings" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>',
      '<Relationship Id="rIdFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>',
    ];
    final numberingSource = numberingChapters ?? chapters;
    var imageId = 1;
    var embeddedImageCount = 0;
    final failedImageSources = <String>[];
    final requestedImageCount = chapters.fold<int>(0, (total, item) {
      final coverCount = item.imagePath.trim().isNotEmpty || item.imageUrl.trim().isNotEmpty ? 1 : 0;
      return total + coverCount + item.inlineImagePaths.where((value) => value.trim().isNotEmpty).length;
    });
    final documentFile = File('${staging.path}/word/document.xml');
    final document = documentFile.openWrite();

    Future<String> addImage(String path, {String caption = '', String fallback = ''}) async {
      final primary = path.trim();
      final secondary = fallback.trim();
      _ExportImageData? image;
      if (primary.isNotEmpty) image = await _loadExportImage(primary);
      if (image == null && secondary.isNotEmpty && secondary != primary) {
        image = await _loadExportImage(secondary);
      }
      if (image == null) {
        final label = primary.isNotEmpty ? primary : secondary;
        if (label.isNotEmpty) failedImageSources.add(label);
        return '';
      }
      final mediaName = 'image_$imageId.${image.extension}';
      final relationId = 'rIdImage$imageId';
      await File('${staging.path}/word/media/$mediaName').writeAsBytes(image.bytes, flush: true);
      relationships.add('<Relationship Id="$relationId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/$mediaName"/>');
      final size = _fitImageEmu(image);
      final xml = _docxImageXml(relationId, imageId, caption: caption, cx: size[0], cy: size[1]);
      imageId++;
      embeddedImageCount++;
      return xml;
    }

    try {
      document.writeln('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" mc:Ignorable="w14"><w:body>''');
      if (includeBookTitlePage) {
        document.writeln(_docxParagraph(defaultBookTitle.toUpperCase(), bold: true, size: 34, align: 'center', firstLineIndent: false, before: 1800, after: 420));
        document.writeln(_docxParagraph(defaultAuthor, size: 23, align: 'center', firstLineIndent: false, after: 200));
        document.writeln('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      }
      final marker = RegExp(r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*(\d*)\s*(?::\s*(.*))?\s*\]?)\s*$', caseSensitive: false);
      for (var index = 0; index < chapters.length; index++) {
        final item = chapters[index];
        final chapterHeader = _cleanExportText(bookExportChapterHeaderFromList(numberingSource, indexOffset + index));
        final chapterTitle = _cleanExportText(cleanBookChapterTitle(item.title));
        final subtitle = _cleanExportText(item.summary);
        document.writeln(_docxParagraph(chapterHeader, bold: true, size: 27, align: 'center', firstLineIndent: false, before: 220, after: 180, keepNext: true));
        if (chapterTitle.isNotEmpty && !_sameBookHeading(chapterHeader, chapterTitle)) document.writeln(_docxParagraph(chapterTitle.toUpperCase(), bold: true, size: 25, align: 'center', firstLineIndent: false, after: 160, keepNext: true));
        if (subtitle.isNotEmpty && !_sameBookHeading(subtitle, chapterTitle)) document.writeln(_docxParagraph(subtitle, bold: true, size: 22, align: 'center', firstLineIndent: false, after: 260, keepNext: true));
        final coverImage = await addImage(item.imagePath, fallback: item.imageUrl);
        if (coverImage.isNotEmpty) document.writeln(coverImage);
        final used = <int>{};
        var autoImageIndex = 0;
        final paragraphLines = <String>[];
        int nextAutoImageIndex() { while (used.contains(autoImageIndex)) autoImageIndex++; return autoImageIndex++; }
        void flushParagraph() { final value = _cleanExportText(paragraphLines.join(' ')); if (value.isNotEmpty) document.writeln(_docxParagraph(value)); paragraphLines.clear(); }
        final titleOverflow = _cleanExportText(bookChapterTitleOverflow(item.title));
        final body = _cleanExportText([if (titleOverflow.isNotEmpty) titleOverflow, if (item.body.trim().isNotEmpty) item.body].join('\n\n'));
        for (final line in body.split('\n')) {
          final match = marker.firstMatch(line);
          if (match != null) {
            flushParagraph();
            final rawNumber = ((match.group(1) ?? '').trim().isNotEmpty ? match.group(1) : match.group(2))?.trim() ?? '';
            final explicitNumber = int.tryParse(rawNumber);
            final imageIndex = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
            used.add(imageIndex);
            if (imageIndex >= 0 && imageIndex < item.inlineImagePaths.length) {
              final imageXml = await addImage(item.inlineImagePaths[imageIndex], caption: _cleanExportText(match.group(3) ?? ''));
              if (imageXml.isNotEmpty) document.writeln(imageXml);
            }
          } else if (line.trim().isEmpty) { flushParagraph(); } else { paragraphLines.add(line.trim()); }
        }
        flushParagraph();
        for (var imageIndex = 0; imageIndex < item.inlineImagePaths.length; imageIndex++) {
          if (!used.contains(imageIndex)) { final imageXml = await addImage(item.inlineImagePaths[imageIndex]); if (imageXml.isNotEmpty) document.writeln(imageXml); }
        }
        final sourceText = _cleanExportText(item.source);
        if (sourceText.isNotEmpty) document.writeln(_docxParagraph('Kaynak / görsel bilgisi: $sourceText', italic: true, size: 18, align: 'left', firstLineIndent: false, before: 180, after: 160));
        if (index != chapters.length - 1) document.writeln('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
        await document.flush();
        final total = progressTotal > 0 ? progressTotal : chapters.length;
        onProgress?.call('$progressLabel (${index + 1}/${chapters.length})', progressOffset + index + 1, total);
        await Future<void>.delayed(Duration.zero);
      }
      if (failedImageSources.isNotEmpty || embeddedImageCount != requestedImageCount) {
        final examples = failedImageSources.take(3).map((value) => value.split('/').last).join(', ');
        throw Exception(
          'Word görselleri gömülemedi. Beklenen: $requestedImageCount, gömülen: $embeddedImageCount.'
          '${examples.isEmpty ? '' : ' Okunamayan: $examples'}',
        );
      }
      document.writeln('<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="7654" w:h="11906"/><w:pgMar w:top="850" w:right="780" w:bottom="850" w:left="1020" w:gutter="280" w:footer="420"/><w:cols w:space="720"/></w:sectPr></w:body></w:document>');
      await document.flush();
      await document.close();
      await File('${staging.path}/[Content_Types].xml').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>''', flush: true);
      await File('${staging.path}/_rels/.rels').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>''', flush: true);
      await File('${staging.path}/word/_rels/document.xml.rels').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships.join('\n')}</Relationships>''', flush: true);
      await File('${staging.path}/word/styles.xml').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:lang w:val="tr-TR"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="150" w:line="330" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style></w:styles>''', flush: true);
      await File('${staging.path}/word/settings.xml').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:zoom w:percent="100"/><w:defaultTabStop w:val="720"/><w:updateFields w:val="true"/><w:compat/></w:settings>''', flush: true);
      await File('${staging.path}/word/footer1.xml').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>''', flush: true);
      await File('${staging.path}/docProps/core.xml').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${_xml(defaultBookTitle)}</dc:title><dc:creator>${_xml(defaultAuthor)}</dc:creator></cp:coreProperties>''', flush: true);
      await File('${staging.path}/docProps/app.xml').writeAsString('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Altay Paranormal</Application><AppVersion>84.0</AppVersion></Properties>''', flush: true);
      final result = await _streamZipDirectory(
        staging,
        output,
        onProgress: onProgress,
        current: progressOffset + chapters.length,
        total: progressTotal > 0 ? progressTotal : chapters.length,
      );
      if (!await _looksLikeDocxFile(result)) throw Exception('Oluşturulan Word dosyasının yapısı geçersiz.');
      return result;
    } finally {
      try { await document.close(); } catch (_) {}
      try { if (await staging.exists()) await staging.delete(recursive: true); } catch (_) {}
    }
  }

  static Future<File> _createBookTitlePdf({required String fileName}) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final file = File('${exportDir.path}/${_safeFileName(fileName)}.pdf');
    final document = pw.Document();
    final theme = await _loadPdfTheme();
    document.addPage(
      pw.Page(
        pageFormat: _bookPageFormat,
        theme: theme,
        margin: const pw.EdgeInsets.fromLTRB(38, 34, 30, 34),
        build: (_) => pw.Center(
          child: pw.Column(
            mainAxisSize: pw.MainAxisSize.min,
            children: <pw.Widget>[
              pw.Text(
                defaultBookTitle.toUpperCase(),
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontSize: 21, fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(height: 18),
              pw.Text(defaultAuthor, textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 13)),
            ],
          ),
        ),
      ),
    );
    final bytes = Uint8List.fromList(await document.save());
    if (!_validPdfBytes(bytes)) throw Exception('Kitap başlık PDF dosyası oluşturulamadı.');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  static Future<File> createPdf(
    List<AppContent> chapters, {
    List<AppContent>? numberingChapters,
    int indexOffset = 0,
    String? fileName,
    bool includeBookTitlePage = true,
  }) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final file = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay Aytin Kitap Taslagi')}.pdf');

    final document = pw.Document();
    final numberingSource = numberingChapters ?? chapters;
    final theme = await _loadPdfTheme();
    final widgets = <pw.Widget>[];

    if (includeBookTitlePage) {
      widgets.add(pw.SizedBox(height: 100));
      widgets.add(pw.Text(defaultBookTitle.toUpperCase(), textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 21, fontWeight: pw.FontWeight.bold)));
      widgets.add(pw.SizedBox(height: 18));
      widgets.add(pw.Text(defaultAuthor, textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 13)));
      widgets.add(pw.NewPage());
    }

    final marker = RegExp(
      r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*(\d*)\s*(?::\s*(.*))?\s*\]?)\s*$',
      caseSensitive: false,
    );

    Future<void> addImage(String path, {String caption = ''}) async {
      final image = await _loadExportImage(path);
      if (image == null) return;
      widgets.add(pw.SizedBox(height: 8));
      widgets.add(
        pw.Center(
          child: pw.ConstrainedBox(
            constraints: const pw.BoxConstraints(maxWidth: 320, maxHeight: 430),
            child: pw.Image(pw.MemoryImage(image.bytes), fit: pw.BoxFit.contain),
          ),
        ),
      );
      final cleanCaption = _cleanExportText(caption);
      if (cleanCaption.isNotEmpty) {
        widgets.add(pw.SizedBox(height: 4));
        _addPdfTextBlocks(
          widgets,
          cleanCaption,
          align: pw.TextAlign.center,
          style: pw.TextStyle(fontSize: 8.5, fontStyle: pw.FontStyle.italic),
          maxCharacters: 320,
          maxWords: 45,
        );
      }
      widgets.add(pw.SizedBox(height: 8));
    }

    for (var index = 0; index < chapters.length; index++) {
      final item = chapters[index];
      final chapterHeader = _cleanExportText(bookExportChapterHeaderFromList(numberingSource, indexOffset + index));
      final chapterTitle = _cleanExportText(cleanBookChapterTitle(item.title));
      final subtitle = _cleanExportText(item.summary);

      _addPdfTextBlocks(
        widgets,
        chapterHeader,
        align: pw.TextAlign.center,
        style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold),
        maxCharacters: 220,
        maxWords: 28,
      );
      if (chapterTitle.isNotEmpty && !_sameBookHeading(chapterHeader, chapterTitle)) {
        widgets.add(pw.SizedBox(height: 5));
        _addPdfTextBlocks(
          widgets,
          chapterTitle.toUpperCase(),
          align: pw.TextAlign.center,
          style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
          maxCharacters: 220,
          maxWords: 28,
        );
      }
      if (subtitle.isNotEmpty && !_sameBookHeading(subtitle, chapterTitle)) {
        widgets.add(pw.SizedBox(height: 5));
        _addPdfTextBlocks(
          widgets,
          subtitle,
          align: pw.TextAlign.center,
          style: pw.TextStyle(fontSize: 11.5, fontWeight: pw.FontWeight.bold),
          maxCharacters: 300,
          maxWords: 40,
        );
      }
      widgets.add(pw.SizedBox(height: 10));

      await addImage(item.imagePath);

      final used = <int>{};
      var autoImageIndex = 0;
      final paragraphLines = <String>[];

      int nextAutoImageIndex() {
        while (used.contains(autoImageIndex)) autoImageIndex++;
        return autoImageIndex++;
      }

      void flushParagraph() {
        final value = _cleanExportText(paragraphLines.join(' '));
        if (value.isNotEmpty) {
          _addPdfTextBlocks(
            widgets,
            value,
            align: pw.TextAlign.justify,
            style: const pw.TextStyle(fontSize: 10.8, height: 1.45),
            padding: const pw.EdgeInsets.only(bottom: 7),
            maxCharacters: 650,
            maxWords: 90,
          );
        }
        paragraphLines.clear();
      }

      final titleOverflow = bookChapterTitleOverflow(item.title);
      final body = _cleanExportText([
        if (titleOverflow.trim().isNotEmpty) titleOverflow,
        if (item.body.trim().isNotEmpty) item.body,
      ].join('\n\n'));

      for (final line in body.split('\n')) {
        final match = marker.firstMatch(line);
        if (match != null) {
          flushParagraph();
          final rawNumber = ((match.group(1) ?? '').trim().isNotEmpty ? match.group(1) : match.group(2))?.trim() ?? '';
          final explicitNumber = int.tryParse(rawNumber);
          final imageIndex = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
          used.add(imageIndex);
          if (imageIndex >= 0 && imageIndex < item.inlineImagePaths.length) {
            await addImage(item.inlineImagePaths[imageIndex], caption: match.group(3) ?? '');
          }
        } else if (line.trim().isEmpty) {
          flushParagraph();
        } else {
          paragraphLines.add(line.trim());
        }
      }
      flushParagraph();

      for (var imageIndex = 0; imageIndex < item.inlineImagePaths.length; imageIndex++) {
        if (!used.contains(imageIndex)) await addImage(item.inlineImagePaths[imageIndex]);
      }

      final sourceText = _cleanExportText(item.source);
      if (sourceText.isNotEmpty) {
        widgets.add(pw.SizedBox(height: 8));
        _addPdfTextBlocks(
          widgets,
          'Kaynak / görsel bilgisi: $sourceText',
          style: pw.TextStyle(fontSize: 8, fontStyle: pw.FontStyle.italic),
          maxCharacters: 500,
          maxWords: 70,
        );
      }

      if (index != chapters.length - 1) widgets.add(pw.NewPage());
    }

    document.addPage(
      pw.MultiPage(
        pageFormat: _bookPageFormat,
        theme: theme,
        margin: const pw.EdgeInsets.fromLTRB(38, 34, 30, 34),
        footer: (context) => pw.Align(
          alignment: pw.Alignment.center,
          child: pw.Text('${context.pageNumber}', style: const pw.TextStyle(fontSize: 8)),
        ),
        build: (_) => widgets,
      ),
    );

    final bytes = Uint8List.fromList(await document.save());
    if (!_validPdfBytes(bytes)) throw Exception('Oluşturulan PDF dosyasının yapısı geçersiz.');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  static Future<void> _addChapterImagesToArchive(
    Archive archive,
    AppContent item,
    String chapterFolder,
    List<String> manifestLines,
  ) async {
    final paths = <String>[
      if (item.imagePath.trim().isNotEmpty) item.imagePath,
      ...item.inlineImagePaths.where((path) => path.trim().isNotEmpty),
    ];
    for (var index = 0; index < paths.length; index++) {
      final image = await _loadExportImage(paths[index]);
      if (image == null) {
        manifestLines.add('Eksik görsel: ${paths[index]}');
        continue;
      }
      final name = index == 0 && item.imagePath.trim().isNotEmpty
          ? 'ana_gorsel.${image.extension}'
          : 'gorsel_${(index + 1).toString().padLeft(3, '0')}.${image.extension}';
      final archivePath = 'GORSELLER/$chapterFolder/$name';
      archive.addFile(ArchiveFile(archivePath, image.bytes.length, image.bytes));
    }
  }

  static Future<void> _reportExportProgress(
    ExportProgressCallback? onProgress,
    String message,
    int current,
    int total,
  ) async {
    onProgress?.call(message, current, total);
    await Future<void>.delayed(const Duration(milliseconds: 24));
  }

  static Future<bool> _looksLikeDocxFile(File file) async {
    if (!await file.exists()) return false;
    final length = await file.length();
    if (length < 500) return false;
    final handle = await file.open();
    try {
      final header = await handle.read(4);
      if (header.length < 4 || header[0] != 0x50 || header[1] != 0x4B) return false;
      final tailSize = length < 262144 ? length : 262144;
      await handle.setPosition(length - tailSize);
      final tail = await handle.read(tailSize);
      final text = latin1.decode(tail, allowInvalid: true);
      return text.contains('PK\x05\x06') &&
          text.contains('[Content_Types].xml') &&
          text.contains('word/document.xml') &&
          text.contains('_rels/.rels');
    } finally {
      await handle.close();
    }
  }

  static Future<bool> _looksLikePdfFile(File file) async {
    if (!await file.exists()) return false;
    final length = await file.length();
    if (length < 100) return false;
    final handle = await file.open();
    try {
      final header = await handle.read(5);
      if (header.length != 5 || utf8.decode(header, allowMalformed: true) != '%PDF-') return false;
      final tailSize = length < 4096 ? length : 4096;
      await handle.setPosition(length - tailSize);
      final tail = await handle.read(tailSize);
      return latin1.decode(tail, allowInvalid: true).contains('%%EOF');
    } finally {
      await handle.close();
    }
  }

  static Future<void> _copyFileTo(File source, File target) async {
    if (!await source.exists()) throw Exception('Geçici çıktı dosyası bulunamadı: ${source.path}');
    await target.parent.create(recursive: true);
    if (await target.exists()) await target.delete();
    await source.copy(target.path);
  }

  static String _imageExtensionFromPath(String path) {
    final normalized = path.replaceAll('\\', '/');
    final name = normalized.split('/').last;
    final dot = name.lastIndexOf('.');
    if (dot < 0 || dot == name.length - 1) return 'bin';
    final extension = name.substring(dot + 1).toLowerCase();
    return RegExp(r'^[a-z0-9]{2,5}$').hasMatch(extension) ? extension : 'bin';
  }

  static Future<void> _copyChapterImagesToDirectory(
    Directory staging,
    AppContent item,
    String chapterFolder,
    List<String> manifestLines,
  ) async {
    final paths = <String>[
      if (item.imagePath.trim().isNotEmpty) item.imagePath,
      ...item.inlineImagePaths.where((path) => path.trim().isNotEmpty),
    ];
    for (var index = 0; index < paths.length; index++) {
      final clean = paths[index].trim();
      final source = File(clean);
      if (!await source.exists() || await source.length() == 0) {
        manifestLines.add('Eksik görsel: $clean');
        continue;
      }
      final extension = _imageExtensionFromPath(clean);
      final fileName = index == 0 && item.imagePath.trim().isNotEmpty
          ? 'ana_gorsel.$extension'
          : 'gorsel_${(index + 1).toString().padLeft(3, '0')}.$extension';
      final target = File('${staging.path}/GORSELLER/$chapterFolder/$fileName');
      await _copyFileTo(source, target);
    }
  }

  static Future<File> _streamZipDirectory(
    Directory staging,
    File output, {
    ExportProgressCallback? onProgress,
    int current = 1,
    int total = 1,
  }) async {
    if (!await staging.exists()) {
      throw Exception('ZIP yapılacak geçici klasör bulunamadı.');
    }
    if (await output.exists()) await output.delete();
    await output.parent.create(recursive: true);

    // Büyük kitap paketlerini Dart belleğinde ZIP'lemek uygulamanın %100 aşamasında
    // sistem tarafından kapatılmasına yol açabiliyor. ZIP işlemi Android'in arka plan
    // iş parçacığında, dosyalar tek tek okunarak yapılır.
    onProgress?.call('ZIP paketi Android tarafından diske yazılıyor', current, total);
    final resultPath = await docxPickerChannel.invokeMethod<String>(
      'zipDirectory',
      <String, Object>{
        'sourceDirectory': staging.path,
        'outputPath': output.path,
      },
    );
    final result = File(
      resultPath?.trim().isNotEmpty == true ? resultPath!.trim() : output.path,
    );

    if (!await result.exists() || await result.length() < 100) {
      throw Exception('ZIP dosyası diske yazılamadı. Telefonda yeterli boş alan olduğundan emin olun.');
    }
    final handle = await result.open();
    try {
      final length = await result.length();
      final header = await handle.read(4);
      if (header.length < 4 || header[0] != 0x50 || header[1] != 0x4B) {
        throw Exception('ZIP dosyasının başlangıç yapısı geçersiz.');
      }
      final tailSize = length < 65536 ? length : 65536;
      await handle.setPosition(length - tailSize);
      final tail = await handle.read(tailSize);
      if (!latin1.decode(tail, allowInvalid: true).contains('PK\x05\x06')) {
        throw Exception('ZIP dosyası tamamlanmadan kesildi.');
      }
    } finally {
      await handle.close();
    }
    return result;
  }


  static Future<File> createSeparatedChapterZip(
    List<AppContent> chapters, {
    required bool includeWord,
    required bool includePdf,
    String? fileName,
  }) async {
    if (!includeWord && !includePdf) throw ArgumentError('En az bir çıktı türü seçilmelidir.');
    final dir = await getApplicationDocumentsDirectory();
    final temp = await getTemporaryDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final runId = DateTime.now().microsecondsSinceEpoch;
    final staging = Directory('${temp.path}/chapter_export_$runId');
    await staging.create(recursive: true);
    final manifest = <String>[
      'ALTAY AYTIN — BÖLÜM DOSYALARI',
      'Oluşturulma: ${DateTime.now().toIso8601String()}',
      'Bölüm sayısı: ${chapters.length}',
      'Her bölüm ayrı ve gerçek Word/PDF dosyasıdır.',
      'Görseller ayrıca GORSELLER klasörüne de eklenmiştir.',
      '',
    ];
    try {
      for (var index = 0; index < chapters.length; index++) {
        final item = chapters[index];
        final chapterLabel = bookChapterLabelFromList(chapters, index);
        final cleanTitle = _cleanExportText(cleanBookChapterTitle(item.title));
        final baseName = _safeFileName('$chapterLabel ${cleanTitle.isEmpty ? 'Bölüm' : cleanTitle}');
        manifest.add('${index + 1}. $baseName');
        if (includeWord) {
          final generated = await createDocx([item], numberingChapters: chapters, indexOffset: index, fileName: '_chapter_word_${runId}_$index', includeBookTitlePage: false);
          if (!await _looksLikeDocxFile(generated)) throw Exception('$baseName Word dosyası doğrulanamadı.');
          await _copyFileTo(generated, File('${staging.path}/WORD/$baseName.docx'));
          try { await generated.delete(); } catch (_) {}
        }
        if (includePdf) {
          final generated = await createPdf([item], numberingChapters: chapters, indexOffset: index, fileName: '_chapter_pdf_${runId}_$index', includeBookTitlePage: false);
          if (!await _looksLikePdfFile(generated)) throw Exception('$baseName PDF dosyası doğrulanamadı.');
          await _copyFileTo(generated, File('${staging.path}/PDF/$baseName.pdf'));
          try { await generated.delete(); } catch (_) {}
        }
        await _copyChapterImagesToDirectory(staging, item, baseName, manifest);
        await Future<void>.delayed(Duration.zero);
      }
      await File('${staging.path}/PAKET_BILGISI.txt').writeAsString(manifest.join('\n'), flush: true);
      final output = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay_Aytin_Bolum_Paketi')}.zip');
      return await _streamZipDirectory(staging, output);
    } finally {
      try { if (await staging.exists()) await staging.delete(recursive: true); } catch (_) {}
    }
  }


  static Future<void> _cleanupStaleTemporaryExports() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final exportDir = Directory('${dir.path}/exports');
      if (!await exportDir.exists()) return;
      final now = DateTime.now();
      await for (final entity in exportDir.list(followLinks: false)) {
        if (entity is! File) continue;
        final name = entity.path.replaceAll('\\', '/').split('/').last;
        final temporary = name.startsWith('_publisher_') ||
            name.startsWith('_chapter_') ||
            name.startsWith('_full_pdf_') ||
            name.startsWith('_backup_preview_');
        if (!temporary) continue;
        final modified = await entity.lastModified();
        if (now.difference(modified).inHours >= 1) {
          try { await entity.delete(); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  static Future<List<String>> validatePublisherPackage(
    List<AppContent> chapters, {
    ExportProgressCallback? onProgress,
  }) async {
    await _cleanupStaleTemporaryExports();
    final issues = <String>[];
    if (chapters.isEmpty) return <String>['Kitapta dışa aktarılacak bölüm bulunmuyor.'];

    final uniqueImages = <String>{};
    var sourceImageBytes = 0;
    for (final chapter in chapters) {
      for (final path in <String>[chapter.imagePath, ...chapter.inlineImagePaths]) {
        final clean = path.trim();
        if (clean.isNotEmpty) uniqueImages.add(clean);
      }
    }

    var checked = 0;
    for (final path in uniqueImages) {
      final file = File(path);
      if (!await file.exists() || await file.length() == 0) {
        issues.add('Görsel bulunamadı: ${path.replaceAll('\\', '/').split('/').last}');
      } else {
        sourceImageBytes += await file.length();
        final image = await _loadExportImage(path);
        if (image == null || image.bytes.isEmpty || image.width < 1 || image.height < 1) {
          issues.add('Görsel okunamıyor: ${path.replaceAll('\\', '/').split('/').last}');
        }
      }
      checked++;
      onProgress?.call('Görseller kontrol ediliyor ($checked/${uniqueImages.length})', checked, uniqueImages.isEmpty ? 1 : uniqueImages.length);
      await Future<void>.delayed(Duration.zero);
    }

    try {
      final capabilities = await docxPickerChannel.invokeMapMethod<String, dynamic>('getExportCapabilities');
      if (capabilities == null || capabilities['mergePdfFiles'] != true) {
        issues.add('PDF birleştirme bileşeni hazır değil. Altay Paranormal uygulamasını güncelleyin.');
      }
      if (capabilities == null || capabilities['saveExportToDownloads'] != true) {
        issues.add('Download klasörüne otomatik kayıt bileşeni hazır değil. v82 veya daha yeni sürümü kurun.');
      }
      if (capabilities == null || capabilities['zipDirectory'] != true) {
        issues.add('Büyük paketler için güvenli ZIP bileşeni hazır değil. v82 veya daha yeni sürümü kurun.');
      }
    } on MissingPluginException {
      issues.add('Uygulamanın Android dışa aktarma bileşeni eski. v82 APK sürümünü kurmadan paket oluşturmayın.');
    } catch (error) {
      issues.add('Dışa aktarma bileşeni kontrol edilemedi: $error');
    }

    try {
      final freeBytes = await docxPickerChannel.invokeMethod<int>('getExportFreeSpace') ?? 0;
      final requiredBytes = (sourceImageBytes * 6) + (600 * 1024 * 1024);
      if (freeBytes > 0 && freeBytes < requiredBytes) {
        final freeMb = freeBytes / (1024 * 1024);
        final requiredMb = requiredBytes / (1024 * 1024);
        issues.add('Telefon alanı yetersiz. Boş: ${freeMb.toStringAsFixed(0)} MB, gereken yaklaşık: ${requiredMb.toStringAsFixed(0)} MB.');
      }
    } catch (_) {
      // Eski Android katmanı boş alan bilgisini vermiyorsa işlem diğer kontrollerle devam eder.
    }

    return issues;
  }

  static Future<File> createFullPdf(
    List<AppContent> chapters, {
    String? fileName,
    ExportProgressCallback? onProgress,
  }) async {
    if (chapters.isEmpty) throw Exception('PDF için bölüm bulunamadı.');
    final dir = await getApplicationDocumentsDirectory();
    final temp = await getTemporaryDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final runId = DateTime.now().microsecondsSinceEpoch;
    final staging = Directory('${temp.path}/full_pdf_$runId');
    await staging.create(recursive: true);
    final parts = <File>[];
    try {
      final titlePdf = await _createBookTitlePdf(fileName: '_full_pdf_title_$runId');
      final titleTarget = File('${staging.path}/part_0000.pdf');
      await _copyFileTo(titlePdf, titleTarget);
      parts.add(titleTarget);
      try { await titlePdf.delete(); } catch (_) {}
      for (var index = 0; index < chapters.length; index++) {
        onProgress?.call('Tam PDF hazırlanıyor (${index + 1}/${chapters.length})', index + 1, chapters.length + 2);
        final generated = await createPdf(
          <AppContent>[chapters[index]],
          numberingChapters: chapters,
          indexOffset: index,
          fileName: '_full_pdf_${runId}_$index',
          includeBookTitlePage: false,
        );
        final target = File('${staging.path}/part_${(index + 1).toString().padLeft(4, '0')}.pdf');
        await _copyFileTo(generated, target);
        if (!await _looksLikePdfFile(target)) throw Exception('${index + 1}. bölüm PDF dosyası doğrulanamadı.');
        parts.add(target);
        try { await generated.delete(); } catch (_) {}
        onProgress?.call('Tam PDF bölümü tamamlandı (${index + 1}/${chapters.length})', index + 2, chapters.length + 2);
        await Future<void>.delayed(Duration.zero);
      }
      final output = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay_Aytin_Tam_Kitap')}.pdf');
      onProgress?.call('PDF sayfaları birleştiriliyor', chapters.length + 1, chapters.length + 2);
      final merged = await _mergePdfFilesNative(parts, output);
      onProgress?.call('Tam PDF hazır', chapters.length + 2, chapters.length + 2);
      return merged;
    } finally {
      try { if (await staging.exists()) await staging.delete(recursive: true); } catch (_) {}
    }
  }

  static Future<File> _mergePdfFilesNative(List<File> files, File output) async {
    if (files.isEmpty) throw Exception('Birleştirilecek PDF bulunamadı.');
    await output.parent.create(recursive: true);
    if (await output.exists()) await output.delete();
    final result = await docxPickerChannel.invokeMethod<String>('mergePdfFiles', <String, Object>{
      'paths': files.map((file) => file.path).toList(),
      'outputPath': output.path,
    });
    final merged = File(result?.trim().isNotEmpty == true ? result! : output.path);
    if (!await _looksLikePdfFile(merged)) throw Exception('Tam kitap PDF birleştirilemedi.');
    return merged;
  }

  static Future<File> createPublisherPackage(
    List<AppContent> chapters, {
    String? fileName,
    ExportProgressCallback? onProgress,
  }) async {
    if (chapters.isEmpty) throw Exception('Yayınevi paketi için bölüm bulunamadı.');
    await _cleanupStaleTemporaryExports();
    final dir = await getApplicationDocumentsDirectory();
    final temp = await getTemporaryDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final runId = DateTime.now().microsecondsSinceEpoch;
    final staging = Directory('${temp.path}/publisher_package_$runId');
    await staging.create(recursive: true);
    final totalSteps = (chapters.length * 2) + 4;

    try {
      await _reportExportProgress(onProgress, 'Görselleri gömülü düzenlenebilir Word hazırlanıyor', 1, totalSteps);
      final fullWord = await createDocx(
        chapters,
        fileName: '_publisher_full_word_$runId',
        includeBookTitlePage: true,
        onProgress: (message, current, total) {
          onProgress?.call(message, current.clamp(1, chapters.length).toInt(), totalSteps);
        },
        progressOffset: 0,
        progressTotal: totalSteps,
        progressLabel: 'Düzenlenebilir Word hazırlanıyor',
      );
      if (!await _looksLikeDocxFile(fullWord)) throw Exception('Düzenlenebilir tam Word dosyası doğrulanamadı.');
      final wordTarget = File('${staging.path}/Altay_Aytin_Tam_Kitap_Duzenlenebilir.docx');
      await _copyFileTo(fullWord, wordTarget);
      try { await fullWord.delete(); } catch (_) {}
      await _reportExportProgress(onProgress, 'Düzenlenebilir Word tamamlandı', chapters.length + 1, totalSteps);

      await _reportExportProgress(onProgress, 'Baskıya hazır tam PDF hazırlanıyor', chapters.length + 2, totalSteps);
      final fullPdf = await createFullPdf(
        chapters,
        fileName: '_publisher_full_pdf_$runId',
        onProgress: (message, current, total) {
          final mapped = chapters.length + 1 + current.clamp(1, chapters.length + 2).toInt();
          onProgress?.call(message, mapped.clamp(1, totalSteps), totalSteps);
        },
      );
      if (!await _looksLikePdfFile(fullPdf)) throw Exception('Baskıya hazır tam PDF dosyası doğrulanamadı.');
      final pdfTarget = File('${staging.path}/Altay_Aytin_Tam_Kitap_Baskiya_Hazir.pdf');
      await _copyFileTo(fullPdf, pdfTarget);
      try { await fullPdf.delete(); } catch (_) {}
      await _reportExportProgress(onProgress, 'Baskıya hazır PDF tamamlandı', totalSteps - 1, totalSteps);

      final output = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay_Aytin_Yayinevi_Paketi')}.zip');
      final result = await _streamZipDirectory(
        staging,
        output,
        onProgress: onProgress,
        current: totalSteps - 1,
        total: totalSteps,
      );
      await _reportExportProgress(onProgress, 'Yayınevi paketi hazır', totalSteps, totalSteps);
      return result;
    } finally {
      try { if (await staging.exists()) await staging.delete(recursive: true); } catch (_) {}
    }
  }


  static String _backupAssetExtension(String path, Uint8List bytes) {
    if (_isJpeg(bytes)) return 'jpg';
    if (_isPng(bytes)) return 'png';
    final ext = path.split('.').last.toLowerCase();
    if (RegExp(r'^[a-z0-9]{2,5}$').hasMatch(ext)) return ext;
    return 'bin';
  }

  static Future<File> createProjectBackup(List<AppContent> chapters, {String? fileName}) async {
    final dir = await getApplicationDocumentsDirectory();
    final temp = await getTemporaryDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) await exportDir.create(recursive: true);
    final runId = DateTime.now().microsecondsSinceEpoch;
    final staging = Directory('${temp.path}/project_backup_$runId');
    await staging.create(recursive: true);
    final chapterJson = <Map<String, dynamic>>[];
    final missingImages = <String>[];

    try {
      for (var index = 0; index < chapters.length; index++) {
        final item = chapters[index];
        final json = Map<String, dynamic>.from(item.toJson());
        final folder = 'GORSELLER/${(index + 1).toString().padLeft(3, '0')}_${_safeArchiveSegment(cleanBookChapterTitle(item.title))}';

        Future<String> backupPath(String path, String name) async {
          final clean = path.trim();
          if (clean.isEmpty) return '';
          final source = File(clean);
          if (!await source.exists() || await source.length() == 0) {
            missingImages.add(clean);
            return '';
          }
          final extension = _imageExtensionFromPath(clean);
          final relative = '$folder/$name.$extension';
          await _copyFileTo(source, File('${staging.path}/$relative'));
          return relative;
        }

        json['imagePath'] = await backupPath(item.imagePath, 'ana_gorsel');
        final inline = <String>[];
        for (var imageIndex = 0; imageIndex < item.inlineImagePaths.length; imageIndex++) {
          inline.add(await backupPath(item.inlineImagePaths[imageIndex], 'gorsel_${(imageIndex + 1).toString().padLeft(3, '0')}'));
        }
        json['inlineImagePaths'] = inline;
        chapterJson.add(json);
        await Future<void>.delayed(Duration.zero);
      }

      final payload = const JsonEncoder.withIndent('  ').convert({
        'type': 'altay_paranormal_project_backup',
        'formatVersion': 3,
        'appVersion': appVersionLabel,
        'createdAt': DateTime.now().toIso8601String(),
        'bookTitle': defaultBookTitle,
        'author': defaultAuthor,
        'bookChapters': chapterJson,
        'missingImages': missingImages,
      });
      final projectJson = File('${staging.path}/PROJE/kitap_yedegi.json');
      await projectJson.parent.create(recursive: true);
      await projectJson.writeAsString(payload, flush: true);

      final previewWord = await createDocx(chapters, fileName: '_backup_preview_word_$runId', includeBookTitlePage: true);
      if (await _looksLikeDocxFile(previewWord)) {
        await _copyFileTo(previewWord, File('${staging.path}/OKUNABILIR/Yedek_Onizleme.docx'));
      }
      try { await previewWord.delete(); } catch (_) {}

      final previewPdf = await createFullPdf(chapters, fileName: '_backup_preview_pdf_$runId');
      if (await _looksLikePdfFile(previewPdf)) {
        await _copyFileTo(previewPdf, File('${staging.path}/OKUNABILIR/Yedek_Onizleme.pdf'));
      }
      try { await previewPdf.delete(); } catch (_) {}

      final explanation = File('${staging.path}/YEDEK_ACIKLAMASI.txt');
      await explanation.writeAsString(
        'ALTAY PARANORMAL PROJE YEDEGI\n\n'
        'Bu ZIP gerçek proje yedeğidir.\n'
        '- PROJE/kitap_yedegi.json uygulamaya geri yükleme içindir.\n'
        '- GORSELLER klasöründe gerçek görsel dosyaları bulunur.\n'
        '- OKUNABILIR klasöründe Word ve PDF ön izlemesi bulunur.\n\n'
        'Yedeği geri yüklemek için ZIP dosyasını değiştirmeden uygulamadaki Yedek yükle düğmesini kullanın.\n',
        flush: true,
      );

      final output = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay_Paranormal_Proje_Yedegi')}.zip');
      return await _streamZipDirectory(staging, output);
    } finally {
      try { if (await staging.exists()) await staging.delete(recursive: true); } catch (_) {}
    }
  }


  static Future<List<AppContent>> restoreProjectBackup(Uint8List bytes) async {
    if (bytes.isEmpty) return const [];

    if (bytes.length >= 2 && bytes[0] == 0x50 && bytes[1] == 0x4B) {
      final archive = ZipDecoder().decodeBytes(bytes);
      ArchiveFile? jsonFile;
      for (final file in archive.files) {
        if (file.name == 'PROJE/kitap_yedegi.json') {
          jsonFile = file;
          break;
        }
      }
      if (jsonFile == null) throw Exception('ZIP içinde proje yedeği bulunamadı.');
      final decoded = jsonDecode(utf8.decode(_archiveBytes(jsonFile)));
      final rawChapters = decoded is Map ? decoded['bookChapters'] : null;
      if (rawChapters is! List) throw Exception('Yedek bölüm listesi okunamadı.');

      final dir = await getApplicationDocumentsDirectory();
      final restoreRoot = Directory('${dir.path}/restored_backups/${DateTime.now().millisecondsSinceEpoch}');
      await restoreRoot.create(recursive: true);
      final filesByName = <String, ArchiveFile>{for (final file in archive.files) file.name: file};

      Future<String> restoreAsset(String relative) async {
        final clean = relative.replaceAll('\\', '/').trim();
        if (clean.isEmpty) return '';
        final archiveFile = filesByName[clean];
        if (archiveFile == null) return '';
        final safeName = clean.split('/').where((part) => part.isNotEmpty && part != '..').join('_');
        final output = File('${restoreRoot.path}/$safeName');
        await output.writeAsBytes(_archiveBytes(archiveFile), flush: true);
        return output.path;
      }

      final restored = <AppContent>[];
      for (final raw in rawChapters.whereType<Map>()) {
        final json = raw.map((key, value) => MapEntry(key.toString(), value));
        json['imagePath'] = await restoreAsset(json['imagePath']?.toString() ?? '');
        final restoredInline = <String>[];
        final inline = json['inlineImagePaths'];
        if (inline is List) {
          for (final value in inline) {
            restoredInline.add(await restoreAsset(value.toString()));
          }
        }
        json['inlineImagePaths'] = restoredInline;
        restored.add(AppContent.fromJson(json, ContentTypes.book).copyWith(type: ContentTypes.book));
      }
      return restored;
    }

    // Eski JSON yedekleriyle geriye dönük uyumluluk.
    final decoded = jsonDecode(utf8.decode(bytes));
    final rawChapters = decoded is Map ? decoded['bookChapters'] ?? decoded['book'] : decoded;
    return LocalStore.decodeList(rawChapters, ContentTypes.book)
        .map((item) => item.copyWith(type: ContentTypes.book))
        .toList();
  }
}


class BookStats {
  static const int wordsPerPage = 240;
  static const double mainImagePageShare = 0.45;
  static const double inlineImagePageShare = 0.58;
  static const double chapterLayoutShare = 0.08;

  final int chapterCount;
  final int wordCount;
  final int estimatedPages;
  final int textOnlyPages;
  final int imageAwarePages;
  final int layoutBufferPages;
  final double imagePageEstimate;
  final int imageCount;
  final int shortChapterCount;
  final bool hasIntro;
  final bool hasConclusion;
  final bool hasSources;

  const BookStats({
    required this.chapterCount,
    required this.wordCount,
    required this.estimatedPages,
    required this.textOnlyPages,
    required this.imageAwarePages,
    required this.layoutBufferPages,
    required this.imagePageEstimate,
    required this.imageCount,
    required this.shortChapterCount,
    required this.hasIntro,
    required this.hasConclusion,
    required this.hasSources,
  });

  factory BookStats.from(List<AppContent> items) {
    final words = items.fold<int>(0, (sum, item) => sum + countWords('${item.title} ${item.summary} ${item.body}'));
    final textOnly = pagesFromWords(words);
    final images = items.fold<int>(0, (sum, item) => sum + item.imageCount);
    final imagePages = items.fold<double>(0, (sum, item) => sum + imagePageEstimateFor(item));
    final layoutPages = items.isEmpty ? 0 : (items.length * chapterLayoutShare).ceil();
    final imageAware = (words / wordsPerPage + imagePages + layoutPages).ceil();

    final lowerTitles = items.map((item) => item.title.toLowerCase()).join(' ');
    final lowerAll = items.map((item) => '${item.title} ${item.body} ${item.source}'.toLowerCase()).join(' ');

    return BookStats(
      chapterCount: items.length,
      wordCount: words,
      estimatedPages: imageAware,
      textOnlyPages: textOnly,
      imageAwarePages: imageAware,
      layoutBufferPages: layoutPages,
      imagePageEstimate: imagePages,
      imageCount: images,
      shortChapterCount: items.where((item) => countWords(item.body) < 120).length,
      hasIntro: lowerTitles.contains('giriş') || lowerTitles.contains('giris') || lowerTitles.contains('önsöz') || lowerTitles.contains('onsoz'),
      hasConclusion: lowerTitles.contains('sonuç') || lowerTitles.contains('sonuc') || lowerTitles.contains('kapanış') || lowerTitles.contains('kapanis'),
      hasSources: lowerAll.contains('kaynak') || items.any((item) => item.source.trim().isNotEmpty),
    );
  }

  static int countWords(String value) {
    final matches = RegExp(r'\S+').allMatches(value.trim());
    return matches.length;
  }

  static int pagesFromWords(int words) {
    if (words <= 0) return 0;
    return (words / wordsPerPage).ceil();
  }

  static double imagePageEstimateFor(AppContent item) {
    var total = 0.0;
    if (item.hasImage) total += mainImagePageShare;
    total += item.cleanInlineImagePaths.length * inlineImagePageShare;

    // Görsel kaynak/caption satırları da kitapta boşluk yer.
    if (item.imageCount > 0 && item.source.trim().isNotEmpty) {
      total += 0.06;
    }

    return total;
  }

  static int estimatedPagesFor(String text) => pagesFromWords(countWords(text));

  static int estimatedPagesForItem(AppContent item) {
    final words = countWords('${item.title} ${item.summary} ${item.body}');
    final visual = words / wordsPerPage + imagePageEstimateFor(item) + chapterLayoutShare;
    return visual <= 0 ? 0 : visual.ceil();
  }

  static String imageCalculationNote() {
    return 'Standart kitap tahmini: yaklaşık $wordsPerPage kelime/sayfa, ana görsel ≈ yarım sayfa, metin içi görsel ≈ yarım sayfadan biraz fazla, bölüm başlangıcı için küçük dizgi payı.';
  }

  List<String> get missingItems {
    final list = <String>[];
    if (chapterCount == 0) list.add('Henüz kitap bölümü eklenmemiş.');
    if (!hasIntro) list.add('Giriş veya önsöz bölümü görünmüyor.');
    if (!hasConclusion) list.add('Sonuç / kapanış bölümü görünmüyor.');
    if (!hasSources) list.add('Kaynakça veya kaynak bilgisi görünmüyor.');
    if (imageCount < chapterCount) list.add('${chapterCount - imageCount} bölümde görsel yok.');
    if (shortChapterCount > 0) list.add('$shortChapterCount bölüm çok kısa görünüyor; metin geliştirilebilir.');
    if (estimatedPages < 80) list.add('Kitap hacmi şu an kısa görünüyor: görseller dahil yaklaşık $estimatedPages sayfa.');
    return list;
  }
}

class BookReaderPage extends StatefulWidget {
  final List<AppContent> items;
  final int initialIndex;
  final void Function(AppContent item)? onEdit;

  const BookReaderPage({super.key, required this.items, required this.initialIndex, this.onEdit});

  @override
  State<BookReaderPage> createState() => _BookReaderPageState();
}

class _BookReaderPageState extends State<BookReaderPage> {
  late final PageController controller;
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.initialIndex;
    controller = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _goTo(int index) {
    controller.animateToPage(index, duration: const Duration(milliseconds: 280), curve: Curves.easeOut);
  }

  List<Widget> _buildBookBody(BuildContext context, AppContent item) {
    const textColor = Color(0xFF2B2117);
    const textStyle = TextStyle(fontSize: 20, height: 1.65, color: textColor, fontWeight: FontWeight.w400);
    final widgets = <Widget>[];
    final buffer = <String>[];
    final usedImageIndexes = <int>{};
    var autoImageIndex = 0;

    int nextAutoImageIndex() {
      while (usedImageIndexes.contains(autoImageIndex)) {
        autoImageIndex++;
      }
      return autoImageIndex++;
    }

    final marker = RegExp(r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*(\d*)\s*(?::\s*(.*))?\s*\]?)\s*$', caseSensitive: false);

    void flushText() {
      final text = buffer.join('\n').trim();
      if (text.isNotEmpty) {
        widgets.add(SelectableText(text, style: textStyle));
        widgets.add(const SizedBox(height: 16));
      }
      buffer.clear();
    }

    final titleOverflow = bookChapterTitleOverflow(item.title);
    final body = [
      if (titleOverflow.isNotEmpty) titleOverflow,
      if (item.body.trim().isNotEmpty) item.body.trim(),
    ].join('\n\n').replaceAll(RegExp(r'Seçilmemiş görsel alanı\\.?', caseSensitive: false), 'Bölüm arası').trim();
    if (body.isEmpty) {
      widgets.add(SelectableText('Bu bölüm için henüz metin eklenmemiş.', style: textStyle));
      return widgets;
    }

    for (final line in body.split('\n')) {
      final match = marker.firstMatch(line);
      if (match != null) {
        flushText();
        final rawNumber = ((match.group(1) ?? '').trim().isNotEmpty ? match.group(1) : match.group(2))?.trim() ?? '';
        final explicitNumber = int.tryParse(rawNumber);
        final index = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
        final imageNumber = index + 1;
        final caption = (match.group(3) ?? '').trim();
        usedImageIndexes.add(index);
        widgets.add(BookInlineImage(path: index >= 0 && index < item.inlineImagePaths.length ? item.inlineImagePaths[index] : '', number: imageNumber, caption: caption));
        widgets.add(const SizedBox(height: 18));
      } else {
        buffer.add(line);
      }
    }
    flushText();

    for (var i = 0; i < item.inlineImagePaths.length; i++) {
      if (!usedImageIndexes.contains(i) && item.inlineImagePaths[i].trim().isNotEmpty) {
        widgets.add(BookInlineImage(path: item.inlineImagePaths[i], number: i + 1, caption: ''));
        widgets.add(const SizedBox(height: 18));
      }
    }

    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    final pages = widget.items;
    final stats = BookStats.from(pages);
    return Scaffold(
      appBar: AppBar(
        title: Text(pages.isEmpty ? 'Kitap' : 'Kitap • ${currentIndex + 1}/${pages.length}'),
        actions: [
          if (widget.onEdit != null && pages.isNotEmpty)
            IconButton(
              tooltip: 'Bu bölümü düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => widget.onEdit!(pages[currentIndex]),
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: LinearProgressIndicator(value: pages.isEmpty ? 0 : (currentIndex + 1) / pages.length),
          ),
          Expanded(
            child: PageView.builder(
              controller: controller,
              itemCount: pages.length,
              onPageChanged: (value) => setState(() => currentIndex = value),
              itemBuilder: (context, index) {
                final item = pages[index];
                final chapterPages = BookStats.estimatedPagesForItem(item);
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7EFD9),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFD8C39A)),
                        boxShadow: const [
                          BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 4)),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              'Yaklaşık $chapterPages sayfa',
                              style: Theme.of(context).textTheme.labelMedium?.copyWith(color: const Color(0xFF5B452C)),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            cleanBookChapterTitle(item.title),
                            softWrap: true,
                            style: const TextStyle(
                              fontSize: 15,
                              height: 1.16,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF2B2117),
                            ),
                          ),
                          if (item.summary.trim().isNotEmpty) ...[
                            const SizedBox(height: 10),
                            Text(item.summary, style: const TextStyle(fontSize: 17, height: 1.35, color: Color(0xFF4A3925))),
                          ],
                          if (item.hasImage) ...[
                            const SizedBox(height: 18),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: AspectRatio(
                                aspectRatio: 4 / 3,
                                child: GalleryImage(item: item, fit: BoxFit.cover),
                              ),
                            ),
                          ],
                          const SizedBox(height: 10),
                          ..._buildBookBody(context, item),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: currentIndex > 0 ? () => _goTo(currentIndex - 1) : null,
                      icon: const Icon(Icons.chevron_left),
                      label: const Text('Önceki'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: currentIndex < pages.length - 1 ? () => _goTo(currentIndex + 1) : null,
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('Sonraki'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class BookInlineImage extends StatelessWidget {
  final String path;
  final int number;
  final String caption;

  const BookInlineImage({super.key, required this.path, required this.number, this.caption = ''});

  @override
  Widget build(BuildContext context) {
    const textColor = Color(0xFF2B2117);
    if (path.trim().isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF6E6),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFD8C39A)),
        ),
        child: Text('Görsel $number seçilmemiş. Yönetim panelinden Görsel $number seç.', style: const TextStyle(color: textColor)),
      );
    }

    final file = File(path);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: file.existsSync()
              ? Image.file(file, width: double.infinity, fit: BoxFit.contain)
              : Container(
                  height: 180,
                  alignment: Alignment.center,
                  color: const Color(0xFFFFF6E6),
                  child: Text('Görsel $number bulunamadı.', style: const TextStyle(color: textColor)),
                ),
        ),
        if (caption.trim().isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(caption, style: const TextStyle(color: Color(0xFF5B452C), fontSize: 13)),
        ],
      ],
    );
  }
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hakkımda')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          InfoPanel(
            title: 'Altay Aytın',
            text:
                'Gizem, UFO ve paranormal alanlara ilgi duyan bağımsız araştırmacı. Anadolu’da saha gözlemleri, antik yapılar, mitolojik anlatılar ve semboller üzerine notlar tutar.',
          ),
          SizedBox(height: 12),
          InfoPanel(
            title: 'Araştırma yaklaşımı',
            text:
                'Akademik iddia yerine merak, gözlem, kaynak taraması ve sahada görme isteği ön plandadır. Uygulama da bu kişisel araştırma arşivini düzenli şekilde sunmak için hazırlanmıştır.',
          ),
        ],
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    const email = 'altaynesee@gmail.com';
    const handle = '@altaynesee';

    return Scaffold(
      appBar: AppBar(title: const Text('İletişim')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.email_outlined),
              title: const Text(email),
              subtitle: const Text('E-posta adresini kopyala'),
              onTap: () => copyText(context, email),
            ),
          ),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.alternate_email),
              title: const Text(handle),
              subtitle: const Text('Sosyal medya kullanıcı adını kopyala'),
              onTap: () => copyText(context, handle),
            ),
          ),
          const SizedBox(height: 12),
          const InfoPanel(
            title: 'Not',
            text:
                'Bu sürümde bağlantılar kopyalama şeklinde çalışır. Sonraki sürümde WhatsApp, Instagram, YouTube veya web sitesi bağlantıları doğrudan açılabilir.',
          ),
        ],
      ),
    );
  }

  static Future<void> copyText(BuildContext context, String value) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Kopyalandı: $value')));
  }
}

class AdminPage extends StatefulWidget {
  final int initialTabIndex;
  final List<AppContent> articles;
  final List<AppContent> fieldNotes;
  final List<AppContent> galleryItems;
  final List<AppContent> bookChapters;
  final Future<void> Function(AppContent item) onAdd;
  final Future<void> Function(AppContent item) onUpdate;
  final Future<void> Function(AppContent item) onDelete;
  final Future<void> Function() onReset;
  final String Function() exportData;
  final Future<void> Function(String raw) importData;

  const AdminPage({
    super.key,
    this.initialTabIndex = 0,
    required this.articles,
    required this.fieldNotes,
    required this.galleryItems,
    required this.bookChapters,
    required this.onAdd,
    required this.onUpdate,
    required this.onDelete,
    required this.onReset,
    required this.exportData,
    required this.importData,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late List<AppContent> articles;
  late List<AppContent> fieldNotes;
  late List<AppContent> galleryItems;
  late List<AppContent> bookChapters;

  @override
  void initState() {
    super.initState();
    articles = [...widget.articles];
    fieldNotes = [...widget.fieldNotes];
    galleryItems = [...widget.galleryItems];
    bookChapters = [...widget.bookChapters];
  }

  List<AppContent> _itemsForType(String type) {
    if (type == ContentTypes.article) return articles;
    if (type == ContentTypes.field) return fieldNotes;
    if (type == ContentTypes.gallery) return galleryItems;
    return bookChapters;
  }

  void _setItemsForType(String type, List<AppContent> items) {
    setState(() {
      if (type == ContentTypes.article) articles = items;
      if (type == ContentTypes.field) fieldNotes = items;
      if (type == ContentTypes.gallery) galleryItems = items;
      if (type == ContentTypes.book) bookChapters = items;
    });
  }

  Future<void> _openEditor(String type, {AppContent? item}) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: type, item: item),
    );
    if (result == null) return;

    final current = _itemsForType(type);
    if (item == null) {
      _setItemsForType(type, [...current, result]);
      await widget.onAdd(result);
    } else {
      final updated = current.map((existing) => existing.id == result.id ? result : existing).toList();
      _setItemsForType(type, updated);
      await widget.onUpdate(result);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kaydedildi.')));
  }

  Future<void> _delete(AppContent item) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    final updated = _itemsForType(item.type).where((existing) => existing.id != item.id).toList();
    _setItemsForType(item.type, updated);
    await widget.onDelete(item);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  Future<void> _reset() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Başlangıç verilerine dönülsün mü?'),
        content: const Text('Eklediğin yerel içerikler silinir. Önce yedek alman iyi olur.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sıfırla')),
        ],
      ),
    );
    if (approved != true) return;
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
      bookChapters = [...defaultBookChapters];
    });
    await widget.onReset();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Veriler sıfırlandı. Kitap bölümü boş bırakıldı.')));
  }

  Future<void> _copyBackup() async {
    final data = widget.exportData();
    await Clipboard.setData(ClipboardData(text: data));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek panoya kopyalandı. Notlara yapıştırıp saklayabilirsin.')));
  }

  Future<void> _importBackup() async {
    final controller = TextEditingController();
    final raw = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yedekten yükle'),
        content: TextField(
          controller: controller,
          minLines: 6,
          maxLines: 10,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'Yedek metnini buraya yapıştır',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Yükle')),
        ],
      ),
    );
    controller.dispose();
    if (raw == null || raw.trim().isEmpty) return;
    try {
      await widget.importData(raw);
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek yüklendi. Yönetimi tekrar açınca yeni liste görünür.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Yedek okunamadı: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      initialIndex: widget.initialTabIndex,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Yönetim Paneli'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Yazı'),
              Tab(text: 'Saha'),
              Tab(text: 'Galeri'),
              Tab(text: 'Kitap'),
            ],
          ),
          actions: [
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'backup') _copyBackup();
                if (value == 'import') _importBackup();
                if (value == 'reset') _reset();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'backup', child: Text('Yedek kopyala')),
                PopupMenuItem(value: 'import', child: Text('Yedekten yükle')),
                PopupMenuItem(value: 'reset', child: Text('Verileri sıfırla')),
              ],
            ),
          ],
        ),
        body: TabBarView(
          children: [
            AdminList(
              title: 'Makale / yazı ekle',
              buttonText: 'Yeni yazı ekle',
              type: ContentTypes.article,
              items: articles,
              onAdd: () => _openEditor(ContentTypes.article),
              onEdit: (item) => _openEditor(ContentTypes.article, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Saha notu ekle',
              buttonText: 'Yeni saha notu ekle',
              type: ContentTypes.field,
              items: fieldNotes,
              onAdd: () => _openEditor(ContentTypes.field),
              onEdit: (item) => _openEditor(ContentTypes.field, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Galeri kaydı ekle',
              buttonText: 'Yeni galeri kaydı ekle',
              type: ContentTypes.gallery,
              items: galleryItems,
              onAdd: () => _openEditor(ContentTypes.gallery),
              onEdit: (item) => _openEditor(ContentTypes.gallery, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Kitap bölümü ekle',
              buttonText: 'Yeni bölüm ekle',
              type: ContentTypes.book,
              items: bookChapters,
              onAdd: () => _openEditor(ContentTypes.book),
              onEdit: (item) => _openEditor(ContentTypes.book, item: item),
              onDelete: _delete,
            ),
          ],
        ),
      ),
    );
  }
}

class AdminList extends StatelessWidget {
  final String title;
  final String buttonText;
  final String type;
  final List<AppContent> items;
  final VoidCallback onAdd;
  final void Function(AppContent item) onEdit;
  final void Function(AppContent item) onDelete;

  const AdminList({
    super.key,
    required this.title,
    required this.buttonText,
    required this.type,
    required this.items,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(_helpText(type)),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: Text(buttonText)),
        const SizedBox(height: 16),
        for (final item in items)
          Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 12),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => onEdit(item),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(child: Icon(item.icon)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, height: 1.25),
                              ),
                              const SizedBox(height: 6),
                              if (item.summary.trim().isNotEmpty)
                                Text(
                                  item.summary,
                                  maxLines: 4,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                              if (item.summary.trim().isEmpty && item.category.trim().isNotEmpty)
                                Text(
                                  item.category,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton.icon(
                          onPressed: () => onEdit(item),
                          icon: const Icon(Icons.edit_outlined),
                          label: const Text('Düzenle'),
                        ),
                        const SizedBox(width: 8),
                        TextButton.icon(
                          onPressed: () => onDelete(item),
                          icon: const Icon(Icons.delete_outline),
                          label: const Text('Sil'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  String _helpText(String type) {
    if (type == ContentTypes.gallery) {
      return 'Telefondan fotoğraf seçebilir veya gerçek/telifsiz görselin doğrudan URL bağlantısını ekleyebilirsin. Kaynak bilgisini de yaz.';
    }
    if (type == ContentTypes.book) {
      return 'Kitap bölümünü ekle. Satır arasına görsel koymak için metinde tek satır olarak “görsel” yaz; seçtiğin görseller sırayla o yerlere yerleşir.';
    }
    return 'Başlık, kategori, kısa açıklama ve uzun metin gir. Kayıt telefonda saklanır.';
  }
}

class ContentEditor extends StatefulWidget {
  final String type;
  final AppContent? item;

  const ContentEditor({super.key, required this.type, this.item});

  @override
  State<ContentEditor> createState() => _ContentEditorState();
}

class _ContentEditorState extends State<ContentEditor> {
  late final TextEditingController titleController;
  late final TextEditingController categoryController;
  late final TextEditingController summaryController;
  late final TextEditingController bodyController;
  late final TextEditingController imageUrlController;
  late final TextEditingController sourceController;
  String localImagePath = '';
  List<String> inlineImagePaths = List.filled(maxInlineBookImages, '');
  bool pickingImage = false;

  static const int maxInlineBookImages = 20;

  bool get isGallery => widget.type == ContentTypes.gallery;
  bool get isBook => widget.type == ContentTypes.book;

  @override
  void initState() {
    super.initState();
    final item = widget.item;
    titleController = TextEditingController(text: item?.title ?? '');
    categoryController = TextEditingController(text: item?.category ?? (isGallery ? 'Galeri' : ''));
    summaryController = TextEditingController(text: item?.summary ?? '');
    bodyController = TextEditingController(text: item?.body ?? '');
    imageUrlController = TextEditingController(text: item?.imageUrl ?? '');
    sourceController = TextEditingController(text: item?.source ?? '');
    localImagePath = item?.imagePath ?? '';
    final existingInline = item?.inlineImagePaths ?? const <String>[];
    inlineImagePaths = List.generate(maxInlineBookImages, (index) => index < existingInline.length ? existingInline[index] : '');
  }

  @override
  void dispose() {
    titleController.dispose();
    categoryController.dispose();
    summaryController.dispose();
    bodyController.dispose();
    imageUrlController.dispose();
    sourceController.dispose();
    super.dispose();
  }

  void _save() {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Başlık boş olamaz.')));
      return;
    }
    final nowId = DateTime.now().microsecondsSinceEpoch.toString();
    Navigator.pop(
      context,
      AppContent(
        id: widget.item?.id ?? nowId,
        type: widget.type,
        title: title,
        category: categoryController.text.trim().isEmpty ? (isGallery ? 'Galeri' : (isBook ? 'Bölüm' : 'Genel')) : categoryController.text.trim(),
        summary: isBook ? '' : summaryController.text.trim(),
        body: bodyController.text.trim(),
        imageUrl: imageUrlController.text.trim(),
        imagePath: localImagePath.trim(),
        source: sourceController.text.trim(),
        inlineImagePaths: List<String>.from(inlineImagePaths),
        locked: widget.item?.locked ?? false,
        writerEditReport: widget.item?.writerEditReport ?? '',
        writerPreviousBody: widget.item?.writerPreviousBody ?? '',
        writerEditedAt: widget.item?.writerEditedAt ?? '',
      ),
    );
  }

  Future<void> _pickFromPhoneGallery({int? inlineIndex}) async {
    if ((!isGallery && !isBook) || pickingImage) return;
    setState(() => pickingImage = true);
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final galleryDir = Directory('${dir.path}/altay_gallery_images');
      if (!await galleryDir.exists()) {
        await galleryDir.create(recursive: true);
      }
      final extension = picked.path.split('.').last.toLowerCase();
      final safeExtension = ['jpg', 'jpeg', 'png', 'webp'].contains(extension) ? extension : 'jpg';
      final target = File('${galleryDir.path}/galeri_${DateTime.now().millisecondsSinceEpoch}.$safeExtension');
      final saved = await File(picked.path).copy(target.path);
      if (!mounted) return;
      setState(() {
        if (inlineIndex == null) {
          localImagePath = saved.path;
        } else {
          inlineImagePaths[inlineIndex] = saved.path;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fotoğraf seçilemedi: $e')));
    } finally {
      if (mounted) setState(() => pickingImage = false);
    }
  }

  void _clearLocalImage() {
    setState(() => localImagePath = '');
  }

  void _clearInlineImage(int index) {
    setState(() => inlineImagePaths[index] = '');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 6,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(widget.item == null ? 'Yeni kayıt' : 'Kaydı düzenle', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _field(titleController, isBook ? 'Bölüm başlığı' : 'Başlık', maxLines: isBook ? 10 : 3),
            const SizedBox(height: 10),
            _field(categoryController, isGallery ? 'Kategori / yer' : (isBook ? 'Bölüm etiketi' : 'Kategori')),
            if (!isBook) ...[
              const SizedBox(height: 10),
              _field(summaryController, 'Kısa açıklama', maxLines: 2),
            ],
            const SizedBox(height: 10),
            _field(bodyController, isGallery ? 'Not / açıklama' : (isBook ? 'Bölüm metni' : 'Uzun metin'), maxLines: isBook ? 14 : 10),
            if (isBook) ...[
              const SizedBox(height: 8),
              const Text(
                'Satır arasına görsel koymak için metinde görselin geleceği yere tek satır olarak görsel yaz. En fazla 20 satır arası görsel seçebilirsin; uygulama sıradaki görseli oraya koyar.',
              ),
            ],
            if (isGallery || isBook) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: pickingImage ? null : () => _pickFromPhoneGallery(),
                      icon: pickingImage
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.photo_library_outlined),
                      label: Text(isBook ? 'Bölüm kapak görseli seç' : 'Telefondan fotoğraf seç'),
                    ),
                  ),
                  if (localImagePath.trim().isNotEmpty) ...[
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: 'Seçilen fotoğrafı kaldır',
                      onPressed: _clearLocalImage,
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ],
              ),
              if (localImagePath.trim().isNotEmpty) ...[
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.file(
                    File(localImagePath),
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => const Text('Seçilen fotoğraf gösterilemedi.'),
                  ),
                ),
              ],
              const SizedBox(height: 10),
              _field(imageUrlController, 'İstersen görsel URL bağlantısı'),
              const SizedBox(height: 10),
              _field(sourceController, 'Kaynak / lisans bilgisi'),
              if (isBook) ...[
                const SizedBox(height: 16),
                Text('Satır arası görseller', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Örnek: Bölüm metninde tek satır görsel yazan yerin yerine sıradaki görsel gelir. Toplam 20 görsel alanı kullanılabilir.'),
                const SizedBox(height: 10),
                for (int i = 0; i < maxInlineBookImages; i++)
                  Card(
                    elevation: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(child: Text('Görsel ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold))),
                              if (inlineImagePaths[i].trim().isNotEmpty)
                                IconButton(
                                  tooltip: 'Bu görseli kaldır',
                                  onPressed: () => _clearInlineImage(i),
                                  icon: const Icon(Icons.close),
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: pickingImage ? null : () => _pickFromPhoneGallery(inlineIndex: i),
                                  icon: const Icon(Icons.add_photo_alternate_outlined),
                                  label: Text(inlineImagePaths[i].trim().isEmpty ? 'Görsel ${i + 1} seç' : 'Görsel ${i + 1} değiştir'),
                                ),
                              ),
                            ],
                          ),
                          if (inlineImagePaths[i].trim().isNotEmpty) ...[
                            const SizedBox(height: 8),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.file(
                                File(inlineImagePaths[i]),
                                height: 120,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) => const Text('Bu görsel gösterilemedi.'),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
              ],
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Kaydet')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    );
  }
}

class InfoPanel extends StatelessWidget {
  final String title;
  final String text;

  const InfoPanel({super.key, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(text, style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}

class EmptyPanel extends StatelessWidget {
  final String text;

  const EmptyPanel({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(child: Text(text, textAlign: TextAlign.center)),
    );
  }
}

class ContentTypes {
  static const article = 'article';
  static const field = 'field';
  static const gallery = 'gallery';
  static const book = 'book';
}

class AppContent {
  final String id;
  final String type;
  final String title;
  final String category;
  final String summary;
  final String body;
  final String imageUrl;
  final String imagePath;
  final String source;
  final List<String> inlineImagePaths;
  final bool locked;
  final String writerEditReport;
  final String writerPreviousBody;
  final String writerEditedAt;

  const AppContent({
    required this.id,
    required this.type,
    required this.title,
    required this.category,
    required this.summary,
    required this.body,
    this.imageUrl = '',
    this.imagePath = '',
    this.source = '',
    this.inlineImagePaths = const [],
    this.locked = false,
    this.writerEditReport = '',
    this.writerPreviousBody = '',
    this.writerEditedAt = '',
  });

  bool get hasImage => imagePath.trim().isNotEmpty || imageUrl.trim().isNotEmpty;
  List<String> get cleanInlineImagePaths => inlineImagePaths.where((value) => value.trim().isNotEmpty).toList();
  int get imageCount => (hasImage ? 1 : 0) + cleanInlineImagePaths.length;

  IconData get icon {
    if (type == ContentTypes.field) return Icons.location_on_outlined;
    if (type == ContentTypes.gallery) return Icons.photo_library_outlined;
    if (type == ContentTypes.book) return Icons.menu_book_outlined;
    final lower = category.toLowerCase();
    if (lower.contains('arkeoloji')) return Icons.account_balance_outlined;
    if (lower.contains('gökyüzü') || lower.contains('ufo')) return Icons.public;
    if (lower.contains('mitoloji')) return Icons.auto_awesome_outlined;
    return Icons.article_outlined;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'category': category,
        'summary': summary,
        'body': body,
        'imageUrl': imageUrl,
        'imagePath': imagePath,
        'source': source,
        'inlineImagePaths': inlineImagePaths,
        'locked': locked,
        'writerEditReport': writerEditReport,
        'writerPreviousBody': writerPreviousBody,
        'writerEditedAt': writerEditedAt,
      };

  factory AppContent.fromJson(Map<String, dynamic> json, String fallbackType) {
    return AppContent(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      type: json['type']?.toString() ?? fallbackType,
      title: json['title']?.toString() ?? 'Başlıksız',
      category: json['category']?.toString() ?? 'Genel',
      summary: json['summary']?.toString() ?? '',
      body: json['body']?.toString() ?? '',
      imageUrl: json['imageUrl']?.toString() ?? '',
      imagePath: json['imagePath']?.toString() ?? '',
      source: json['source']?.toString() ?? '',
      inlineImagePaths: json['inlineImagePaths'] is List
          ? (json['inlineImagePaths'] as List).map((value) => value.toString()).toList()
          : const [],
      locked: json['locked'] == true || json['locked']?.toString() == 'true',
      writerEditReport: json['writerEditReport']?.toString() ?? '',
      writerPreviousBody: json['writerPreviousBody']?.toString() ?? '',
      writerEditedAt: json['writerEditedAt']?.toString() ?? '',
    );
  }

  AppContent copyWith({
    String? id,
    String? type,
    String? title,
    String? category,
    String? summary,
    String? body,
    String? imageUrl,
    String? imagePath,
    String? source,
    List<String>? inlineImagePaths,
    bool? locked,
    String? writerEditReport,
    String? writerPreviousBody,
    String? writerEditedAt,
  }) {
    return AppContent(
      id: id ?? this.id,
      type: type ?? this.type,
      title: title ?? this.title,
      category: category ?? this.category,
      summary: summary ?? this.summary,
      body: body ?? this.body,
      imageUrl: imageUrl ?? this.imageUrl,
      imagePath: imagePath ?? this.imagePath,
      source: source ?? this.source,
      inlineImagePaths: inlineImagePaths ?? this.inlineImagePaths,
      locked: locked ?? this.locked,
      writerEditReport: writerEditReport ?? this.writerEditReport,
      writerPreviousBody: writerPreviousBody ?? this.writerPreviousBody,
      writerEditedAt: writerEditedAt ?? this.writerEditedAt,
    );
  }
}

bool isBundledSampleBookChapter(AppContent item) {
  const seededIds = {'book_1', 'book_2', 'book_3'};
  const seededTitles = {
    'Giriş: Taşların Sessiz Dili',
    'Şahmeran ve Bilgeliğin Gizli Bedeni',
    'Göbekli Tepe, Sembol Hafızası ve Taşlardaki İzler',
  };
  return item.type == ContentTypes.book && seededIds.contains(item.id) && seededTitles.contains(item.title.trim());
}

class LocalStore {
  static const articlesKey = 'v2_articles_json';
  static const fieldNotesKey = 'v2_field_notes_json';
  static const galleryKey = 'v2_gallery_json';
  static const bookKey = 'v2_book_json';

  static Future<List<AppContent>> loadList(String key, List<AppContent> defaults) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.trim().isEmpty) return [...defaults];
    try {
      final decoded = jsonDecode(raw);
      final type = defaults.isEmpty ? ContentTypes.article : defaults.first.type;
      final list = decodeList(decoded, type);
      return list.isEmpty ? [...defaults] : list;
    } catch (_) {
      return [...defaults];
    }
  }

  static Future<void> saveList(String key, List<AppContent> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(items.map((item) => item.toJson()).toList()));
  }

  static List<AppContent> decodeList(dynamic decoded, String fallbackType) {
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((entry) => AppContent.fromJson(Map<String, dynamic>.from(entry), fallbackType))
        .toList();
  }
}

const defaultArticles = [
  AppContent(
    id: 'article_1',
    type: ContentTypes.article,
    title: 'Mağaralar, Hafıza ve Köken Anlatıları',
    category: 'Mitoloji',
    summary: 'Mağara mekânının eski anlatılardaki simgesel rolü.',
    body:
        'Mağara, birçok kadim anlatıda yalnızca saklanma yeri değildir. Karanlık, geçiş, yeniden doğuş, bilinmeyenle yüzleşme ve köken hafızası gibi anlamlar taşır. Kahramanın mağarada karşılaştığı varlık, çoğu zaman sıradan bir figür değil, soyun veya bilginin gizli tarafını temsil eden eşik varlığıdır.',
  ),
  AppContent(
    id: 'article_2',
    type: ContentTypes.article,
    title: 'Şahmeran: Yılan Bedenli Bilgelik Figürü',
    category: 'Anadolu Efsaneleri',
    summary: 'Şahmeran anlatısında bilgelik, sır ve beden sembolizmi.',
    body:
        'Şahmeran anlatısı; yarı insan yarı yılan formuyla hem korkuyu hem bilgeliği aynı bedende toplar. Bu ikili yapı, eski toplumların doğa, ölüm, şifa ve gizli bilgiyle kurduğu ilişkiyi okumak için güçlü bir kapı açar.',
  ),
  AppContent(
    id: 'article_3',
    type: ContentTypes.article,
    title: 'Draco Takımyıldızı ve Antik Gökyüzü Haritaları',
    category: 'Gökyüzü',
    summary: 'Ejderha/yılan sembolünün göksel karşılıkları.',
    body:
        'Draco takımyıldızı, gökyüzünde yılanımsı uzun formuyla tarih boyunca dikkat çekmiştir. Antik toplumların gökyüzünü yalnızca takvim için değil, mitolojik hafıza için de kullandığı düşünülür.',
  ),
  AppContent(
    id: 'article_4',
    type: ContentTypes.article,
    title: 'Göbekli Tepe ve Sembol Hafızası',
    category: 'Arkeoloji',
    summary: 'Taş sütunlar, hayvan kabartmaları ve ritüel alan fikri.',
    body:
        'Göbekli Tepe, sembollerin taş üzerine işlendiği güçlü bir hafıza alanı olarak görülebilir. Hayvan kabartmaları, ritüel düzen ve anıtsal mimari; insanlığın erken dönem inanç dünyasına dair büyük sorular doğurur.',
  ),
  AppContent(
    id: 'article_5',
    type: ContentTypes.article,
    title: 'Derinkuyu: Yeraltı, Koridor ve Saklı Yaşam',
    category: 'Yeraltı Şehirleri',
    summary: 'Kapalı mekân, geçitler ve savunma mimarisi.',
    body:
        'Derinkuyu gibi yeraltı şehirleri; dar koridorları, taş kapıları ve katmanlı yapısıyla yalnızca mimari değil, psikolojik bir atmosfer de oluşturur. Yeraltına iniş, eski anlatılardaki bilinmeyene geçiş temasını hatırlatır.',
  ),
];

const defaultFieldNotes = [
  AppContent(
    id: 'field_1',
    type: ContentTypes.field,
    title: 'Hattuşa Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Büyük Mabed, Yeşil Taş ve Hitit başkentinin izleri.',
    body:
        'Hattuşa gezisi, taş mimariyi ve kutsal alan düzenini yerinde görmek için güçlü bir saha noktasıdır. Büyük Mabed ve Yeşil Taş, araştırma arşivinde ayrıca incelenebilir.',
  ),
  AppContent(
    id: 'field_2',
    type: ContentTypes.field,
    title: 'Yazılıkaya Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Tanrı kabartmaları, geçit ve kaya tapınağı atmosferi.',
    body:
        'Yazılıkaya, açık hava kaya tapınağı atmosferiyle mitolojik figürleri taş üzerine taşıyan özel bir alandır. Kabartmalar, geçit ve kaya yüzeyi bir arada okunmalıdır.',
  ),
  AppContent(
    id: 'field_3',
    type: ContentTypes.field,
    title: 'Efes Saha Notu',
    category: 'İzmir / Selçuk',
    summary: 'Celsus, Yamaç Evleri ve antik şehir dokusu.',
    body:
        'Efes, Roma dönemi mimari hafızasını güçlü şekilde taşır. Yamaç Evleri, Celsus ve Herakles Kapısı gibi noktalar görsel arşiv için değerlidir.',
  ),
  AppContent(
    id: 'field_4',
    type: ContentTypes.field,
    title: 'Myra Saha Notu',
    category: 'Antalya / Demre',
    summary: 'Kaya mezarları, Medusa imgesi ve Likya dokusu.',
    body:
        'Myra, kaya mezarları ve antik tiyatrosuyla Likya dünyasının güçlü izlerini taşır. Medusa ve koruyucu sembol fikri burada ayrıca araştırılabilir.',
  ),
];


const defaultBookChapters = <AppContent>[];

const defaultGalleryItems = [
  AppContent(
    id: 'gallery_1',
    type: ContentTypes.gallery,
    title: 'Göbekli Tepe',
    category: 'Galeri',
    summary: 'Gerçek/telifsiz görsel bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_2',
    type: ContentTypes.gallery,
    title: 'Hattuşa',
    category: 'Galeri',
    summary: 'Gerçek saha fotoğrafı için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_3',
    type: ContentTypes.gallery,
    title: 'Yazılıkaya',
    category: 'Galeri',
    summary: 'Açık lisanslı kaynak görsel için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_4',
    type: ContentTypes.gallery,
    title: 'Derinkuyu',
    category: 'Galeri',
    summary: 'Gerçek fotoğraf bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
];
