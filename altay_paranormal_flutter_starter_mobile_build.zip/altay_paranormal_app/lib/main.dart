import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const AltayParanormalApp());
}

class AltayParanormalApp extends StatelessWidget {
  const AltayParanormalApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8A5A22);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gizem ve Paranormal Araştırman',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F1E6),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;
  bool loading = true;
  List<AppContent> articles = [];
  List<AppContent> fieldNotes = [];
  List<AppContent> galleryItems = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedArticles = await LocalStore.loadList(LocalStore.articlesKey, defaultArticles);
    final loadedFieldNotes = await LocalStore.loadList(LocalStore.fieldNotesKey, defaultFieldNotes);
    final loadedGallery = await LocalStore.loadList(LocalStore.galleryKey, defaultGalleryItems);
    if (!mounted) return;
    setState(() {
      articles = loadedArticles;
      fieldNotes = loadedFieldNotes;
      galleryItems = loadedGallery;
      loading = false;
    });
  }

  Future<void> _saveAll() async {
    await LocalStore.saveList(LocalStore.articlesKey, articles);
    await LocalStore.saveList(LocalStore.fieldNotesKey, fieldNotes);
    await LocalStore.saveList(LocalStore.galleryKey, galleryItems);
  }

  List<AppContent> _listForType(String type) {
    switch (type) {
      case ContentTypes.article:
        return articles;
      case ContentTypes.field:
        return fieldNotes;
      case ContentTypes.gallery:
        return galleryItems;
      default:
        return articles;
    }
  }

  Future<void> _replaceList(String type, List<AppContent> list) async {
    setState(() {
      if (type == ContentTypes.article) articles = list;
      if (type == ContentTypes.field) fieldNotes = list;
      if (type == ContentTypes.gallery) galleryItems = list;
    });
    await _saveAll();
  }

  Future<void> _addItem(AppContent item) async {
    final list = [..._listForType(item.type), item];
    await _replaceList(item.type, list);
  }

  Future<void> _updateItem(AppContent item) async {
    final list = _listForType(item.type)
        .map((existing) => existing.id == item.id ? item : existing)
        .toList();
    await _replaceList(item.type, list);
  }

  Future<void> _deleteItem(AppContent item) async {
    final list = _listForType(item.type).where((existing) => existing.id != item.id).toList();
    await _replaceList(item.type, list);
  }

  Future<void> _resetData() async {
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
    });
    await _saveAll();
  }

  String _exportData() {
    return const JsonEncoder.withIndent('  ').convert({
      'articles': articles.map((item) => item.toJson()).toList(),
      'fieldNotes': fieldNotes.map((item) => item.toJson()).toList(),
      'gallery': galleryItems.map((item) => item.toJson()).toList(),
    });
  }

  Future<void> _importData(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Yedek metni geçerli değil.');
    }
    final newArticles = LocalStore.decodeList(decoded['articles'], ContentTypes.article);
    final newFieldNotes = LocalStore.decodeList(decoded['fieldNotes'], ContentTypes.field);
    final newGallery = LocalStore.decodeList(decoded['gallery'], ContentTypes.gallery);
    setState(() {
      articles = newArticles.isEmpty ? articles : newArticles;
      fieldNotes = newFieldNotes.isEmpty ? fieldNotes : newFieldNotes;
      galleryItems = newGallery.isEmpty ? galleryItems : newGallery;
    });
    await _saveAll();
  }

  void _openAdmin() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AdminPage(
          articles: articles,
          fieldNotes: fieldNotes,
          galleryItems: galleryItems,
          onAdd: _addItem,
          onUpdate: _updateItem,
          onDelete: _deleteItem,
          onReset: _resetData,
          exportData: _exportData,
          importData: _importData,
        ),
      ),
    );
  }

  void _openAbout() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutPage()));
  }

  void _openContact() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ContactPage()));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final pages = [
      HomePage(
        articlesCount: articles.length,
        fieldCount: fieldNotes.length,
        galleryCount: galleryItems.length,
        onOpenAdmin: _openAdmin,
      ),
      ArticlesPage(items: articles),
      FieldNotesPage(items: fieldNotes),
      GalleryPage(items: galleryItems),
      const BookPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gizem ve Paranormal Araştırman'),
        actions: [
          IconButton(
            tooltip: 'Yönetim',
            onPressed: _openAdmin,
            icon: const Icon(Icons.admin_panel_settings_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'about') _openAbout();
              if (value == 'contact') _openContact();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'about', child: Text('Hakkımda')),
              PopupMenuItem(value: 'contact', child: Text('İletişim')),
            ],
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: pages[selectedIndex],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana'),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Yazılar'),
          NavigationDestination(icon: Icon(Icons.travel_explore_outlined), selectedIcon: Icon(Icons.travel_explore), label: 'Saha'),
          NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'Galeri'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Kitap'),
        ],
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int articlesCount;
  final int fieldCount;
  final int galleryCount;
  final VoidCallback onOpenAdmin;

  const HomePage({
    super.key,
    required this.articlesCount,
    required this.fieldCount,
    required this.galleryCount,
    required this.onOpenAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const HeroHeader(),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: onOpenAdmin,
          icon: const Icon(Icons.edit_note),
          label: const Text('Yönetim paneli: yazı, saha notu ve galeri ekle'),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: CounterCard(title: 'Yazı', value: articlesCount.toString(), icon: Icons.article_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Saha', value: fieldCount.toString(), icon: Icons.travel_explore_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Galeri', value: galleryCount.toString(), icon: Icons.photo_library_outlined)),
          ],
        ),
        const SizedBox(height: 18),
        Text('Öne Çıkan Dosyalar', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: const [
            FeatureCard(icon: Icons.public, title: 'UFO Dosyaları', subtitle: 'Gözlem, rapor ve olay notları'),
            FeatureCard(icon: Icons.account_balance, title: 'Antik Medeniyetler', subtitle: 'Tapınaklar, semboller, mitler'),
            FeatureCard(icon: Icons.terrain, title: 'Saha Geçmişi', subtitle: 'Hattuşa, Yazılıkaya, Efes, Myra'),
            FeatureCard(icon: Icons.auto_stories, title: 'Kitap Projesi', subtitle: 'Antik Medeniyetlerde Reptilyanların İzinde'),
          ],
        ),
        const SizedBox(height: 18),
        const InfoPanel(
          title: 'Bu sürümde ne var?',
          text:
              'Bu 2. sürümde uygulamanın içinden makale, saha notu ve galeri kaydı ekleyebilir, düzenleyebilir ve silebilirsin. Kayıtlar telefonda saklanır. Yedek almayı unutma.',
        ),
      ],
    );
  }
}

class CounterCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const CounterCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class HeroHeader extends StatelessWidget {
  const HeroHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [scheme.primaryContainer, scheme.secondaryContainer],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.explore, size: 44, color: scheme.onPrimaryContainer),
          const SizedBox(height: 18),
          Text(
            'Gizem, UFO ve Paranormal Araştırman\nAltay Aytın',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            'Anadolu sahalarından antik sembollere, mitolojik anlatılardan modern gizem dosyalarına uzanan bağımsız araştırma arşivi.',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const FeatureCard({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width > 700 ? 260 : double.infinity,
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(child: Icon(icon)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(subtitle),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ArticlesPage extends StatefulWidget {
  final List<AppContent> items;

  const ArticlesPage({super.key, required this.items});

  @override
  State<ArticlesPage> createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  final controller = TextEditingController();
  String query = '';

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.items.where((item) {
      final q = query.toLowerCase().trim();
      if (q.isEmpty) return true;
      return item.title.toLowerCase().contains(q) ||
          item.summary.toLowerCase().contains(q) ||
          item.category.toLowerCase().contains(q) ||
          item.body.toLowerCase().contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Yazılar', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(
          controller: controller,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            labelText: 'Yazılarda ara',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) => setState(() => query = value),
        ),
        const SizedBox(height: 12),
        for (final article in filtered) ContentTile(item: article),
        if (filtered.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('Bu aramada sonuç bulunamadı.')),
          ),
      ],
    );
  }
}

class ContentTile extends StatelessWidget {
  final AppContent item;

  const ContentTile({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(child: Icon(item.icon)),
        title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('${item.category} • ${item.summary}'),
        ),
        isThreeLine: true,
        onTap: () => showModalBottomSheet(
          context: context,
          showDragHandle: true,
          isScrollControlled: true,
          builder: (context) => Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(item.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Chip(label: Text(item.category)),
                  const SizedBox(height: 12),
                  Text(item.body, style: Theme.of(context).textTheme.bodyLarge),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class FieldNotesPage extends StatelessWidget {
  final List<AppContent> items;

  const FieldNotesPage({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Saha Gezileri', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        for (final note in items) ContentTile(item: note),
        if (items.isEmpty) const EmptyPanel(text: 'Henüz saha notu yok. Yönetim panelinden ekleyebilirsin.'),
      ],
    );
  }
}

class GalleryPage extends StatelessWidget {
  final List<AppContent> items;

  const GalleryPage({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Galeri', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Gerçek, telifsiz, kamu malı veya izinli görseller için ayrıldı. Görsel eklemek için yönetim paneline görsel URL bağlantısı gir.'),
        const SizedBox(height: 14),
        GridView.builder(
          itemCount: items.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.82,
          ),
          itemBuilder: (context, index) => GalleryCard(item: items[index]),
        ),
        if (items.isEmpty) const EmptyPanel(text: 'Henüz galeri kaydı yok. Yönetim panelinden ekleyebilirsin.'),
      ],
    );
  }
}

class GalleryCard extends StatelessWidget {
  final AppContent item;

  const GalleryCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _openDetails(context),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: scheme.outlineVariant),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: item.imageUrl.trim().isEmpty
                  ? Center(child: Icon(Icons.image_outlined, size: 46, color: scheme.primary))
                  : Image.network(
                      item.imageUrl.trim(),
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Center(
                        child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
                      ),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 3),
                  Text(item.summary, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openDetails(BuildContext context) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (item.imageUrl.trim().isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.network(
                    item.imageUrl.trim(),
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => const SizedBox.shrink(),
                  ),
                ),
              const SizedBox(height: 14),
              Text(item.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(item.summary),
              if (item.source.trim().isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('Kaynak: ${item.source}', style: Theme.of(context).textTheme.bodySmall),
              ],
              if (item.body.trim().isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(item.body),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class BookPage extends StatelessWidget {
  const BookPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        InfoPanel(
          title: 'Antik Medeniyetlerde Reptilyanların İzinde',
          text:
              'Altay Aytın’ın kitap projesi; Mezopotamya, Anadolu antik merkezleri, mitoloji, semboller, mağaralar, tapınaklar ve yılan/ejderha anlatıları üzerinden sıra dışı bir araştırma hattı kurar.',
        ),
        SizedBox(height: 12),
        InfoPanel(
          title: 'Bölüm başlıkları için örnek alanlar',
          text:
              'Göbekli Tepe, Karahan Tepe, Hattuşa, Yazılıkaya, Derinkuyu, Efes, Myra, Şahmeran, Oannes ve Apkallu, Draco takımyıldızı, mağara sembolizmi ve antik tapınak hizalanmaları.',
        ),
        SizedBox(height: 12),
        InfoPanel(
          title: 'İçerik yönetimi',
          text:
              'Kitap bölümünü kalıcı olarak değiştirmek için sonraki sürümde kitap yönetimi de eklenebilir. Bu sürümde yazılar, saha notları ve galeri uygulama içinden düzenlenebilir.',
        ),
      ],
    );
  }
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hakkımda')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          InfoPanel(
            title: 'Altay Aytın',
            text:
                'Gizem, UFO ve paranormal alanlara ilgi duyan bağımsız araştırmacı. Anadolu’da saha gözlemleri, antik yapılar, mitolojik anlatılar ve semboller üzerine notlar tutar.',
          ),
          SizedBox(height: 12),
          InfoPanel(
            title: 'Araştırma yaklaşımı',
            text:
                'Akademik iddia yerine merak, gözlem, kaynak taraması ve sahada görme isteği ön plandadır. Uygulama da bu kişisel araştırma arşivini düzenli şekilde sunmak için hazırlanmıştır.',
          ),
        ],
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    const email = 'altaynesee@gmail.com';
    const handle = '@altaynesee';

    return Scaffold(
      appBar: AppBar(title: const Text('İletişim')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.email_outlined),
              title: const Text(email),
              subtitle: const Text('E-posta adresini kopyala'),
              onTap: () => copyText(context, email),
            ),
          ),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.alternate_email),
              title: const Text(handle),
              subtitle: const Text('Sosyal medya kullanıcı adını kopyala'),
              onTap: () => copyText(context, handle),
            ),
          ),
          const SizedBox(height: 12),
          const InfoPanel(
            title: 'Not',
            text:
                'Bu sürümde bağlantılar kopyalama şeklinde çalışır. Sonraki sürümde WhatsApp, Instagram, YouTube veya web sitesi bağlantıları doğrudan açılabilir.',
          ),
        ],
      ),
    );
  }

  static Future<void> copyText(BuildContext context, String value) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Kopyalandı: $value')));
  }
}

class AdminPage extends StatefulWidget {
  final List<AppContent> articles;
  final List<AppContent> fieldNotes;
  final List<AppContent> galleryItems;
  final Future<void> Function(AppContent item) onAdd;
  final Future<void> Function(AppContent item) onUpdate;
  final Future<void> Function(AppContent item) onDelete;
  final Future<void> Function() onReset;
  final String Function() exportData;
  final Future<void> Function(String raw) importData;

  const AdminPage({
    super.key,
    required this.articles,
    required this.fieldNotes,
    required this.galleryItems,
    required this.onAdd,
    required this.onUpdate,
    required this.onDelete,
    required this.onReset,
    required this.exportData,
    required this.importData,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late List<AppContent> articles;
  late List<AppContent> fieldNotes;
  late List<AppContent> galleryItems;

  @override
  void initState() {
    super.initState();
    articles = [...widget.articles];
    fieldNotes = [...widget.fieldNotes];
    galleryItems = [...widget.galleryItems];
  }

  List<AppContent> _itemsForType(String type) {
    if (type == ContentTypes.article) return articles;
    if (type == ContentTypes.field) return fieldNotes;
    return galleryItems;
  }

  void _setItemsForType(String type, List<AppContent> items) {
    setState(() {
      if (type == ContentTypes.article) articles = items;
      if (type == ContentTypes.field) fieldNotes = items;
      if (type == ContentTypes.gallery) galleryItems = items;
    });
  }

  Future<void> _openEditor(String type, {AppContent? item}) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: type, item: item),
    );
    if (result == null) return;

    final current = _itemsForType(type);
    if (item == null) {
      _setItemsForType(type, [...current, result]);
      await widget.onAdd(result);
    } else {
      final updated = current.map((existing) => existing.id == result.id ? result : existing).toList();
      _setItemsForType(type, updated);
      await widget.onUpdate(result);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kaydedildi.')));
  }

  Future<void> _delete(AppContent item) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    final updated = _itemsForType(item.type).where((existing) => existing.id != item.id).toList();
    _setItemsForType(item.type, updated);
    await widget.onDelete(item);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  Future<void> _reset() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Örnek içeriklere dönülsün mü?'),
        content: const Text('Eklediğin yerel içerikler silinir. Önce yedek alman iyi olur.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sıfırla')),
        ],
      ),
    );
    if (approved != true) return;
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
    });
    await widget.onReset();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Örnek içerikler geri yüklendi.')));
  }

  Future<void> _copyBackup() async {
    final data = widget.exportData();
    await Clipboard.setData(ClipboardData(text: data));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek panoya kopyalandı. Notlara yapıştırıp saklayabilirsin.')));
  }

  Future<void> _importBackup() async {
    final controller = TextEditingController();
    final raw = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yedekten yükle'),
        content: TextField(
          controller: controller,
          minLines: 6,
          maxLines: 10,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'Yedek metnini buraya yapıştır',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Yükle')),
        ],
      ),
    );
    controller.dispose();
    if (raw == null || raw.trim().isEmpty) return;
    try {
      await widget.importData(raw);
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek yüklendi. Yönetimi tekrar açınca yeni liste görünür.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Yedek okunamadı: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Yönetim Paneli'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Yazı'),
              Tab(text: 'Saha'),
              Tab(text: 'Galeri'),
            ],
          ),
          actions: [
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'backup') _copyBackup();
                if (value == 'import') _importBackup();
                if (value == 'reset') _reset();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'backup', child: Text('Yedek kopyala')),
                PopupMenuItem(value: 'import', child: Text('Yedekten yükle')),
                PopupMenuItem(value: 'reset', child: Text('Örnek içeriklere dön')),
              ],
            ),
          ],
        ),
        body: TabBarView(
          children: [
            AdminList(
              title: 'Makale / yazı ekle',
              buttonText: 'Yeni yazı ekle',
              type: ContentTypes.article,
              items: articles,
              onAdd: () => _openEditor(ContentTypes.article),
              onEdit: (item) => _openEditor(ContentTypes.article, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Saha notu ekle',
              buttonText: 'Yeni saha notu ekle',
              type: ContentTypes.field,
              items: fieldNotes,
              onAdd: () => _openEditor(ContentTypes.field),
              onEdit: (item) => _openEditor(ContentTypes.field, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Galeri kaydı ekle',
              buttonText: 'Yeni galeri kaydı ekle',
              type: ContentTypes.gallery,
              items: galleryItems,
              onAdd: () => _openEditor(ContentTypes.gallery),
              onEdit: (item) => _openEditor(ContentTypes.gallery, item: item),
              onDelete: _delete,
            ),
          ],
        ),
      ),
    );
  }
}

class AdminList extends StatelessWidget {
  final String title;
  final String buttonText;
  final String type;
  final List<AppContent> items;
  final VoidCallback onAdd;
  final void Function(AppContent item) onEdit;
  final void Function(AppContent item) onDelete;

  const AdminList({
    super.key,
    required this.title,
    required this.buttonText,
    required this.type,
    required this.items,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(_helpText(type)),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: Text(buttonText)),
        const SizedBox(height: 16),
        for (final item in items)
          Card(
            elevation: 0,
            child: ListTile(
              leading: CircleAvatar(child: Icon(item.icon)),
              title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(item.summary),
              onTap: () => onEdit(item),
              trailing: Wrap(
                children: [
                  IconButton(onPressed: () => onEdit(item), icon: const Icon(Icons.edit_outlined)),
                  IconButton(onPressed: () => onDelete(item), icon: const Icon(Icons.delete_outline)),
                ],
              ),
            ),
          ),
      ],
    );
  }

  String _helpText(String type) {
    if (type == ContentTypes.gallery) {
      return 'Gerçek/telifsiz görselin doğrudan görsel URL bağlantısını ekleyebilirsin. Kaynak bilgisini de yaz.';
    }
    return 'Başlık, kategori, kısa açıklama ve uzun metin gir. Kayıt telefonda saklanır.';
  }
}

class ContentEditor extends StatefulWidget {
  final String type;
  final AppContent? item;

  const ContentEditor({super.key, required this.type, this.item});

  @override
  State<ContentEditor> createState() => _ContentEditorState();
}

class _ContentEditorState extends State<ContentEditor> {
  late final TextEditingController titleController;
  late final TextEditingController categoryController;
  late final TextEditingController summaryController;
  late final TextEditingController bodyController;
  late final TextEditingController imageUrlController;
  late final TextEditingController sourceController;

  bool get isGallery => widget.type == ContentTypes.gallery;

  @override
  void initState() {
    super.initState();
    final item = widget.item;
    titleController = TextEditingController(text: item?.title ?? '');
    categoryController = TextEditingController(text: item?.category ?? (isGallery ? 'Galeri' : ''));
    summaryController = TextEditingController(text: item?.summary ?? '');
    bodyController = TextEditingController(text: item?.body ?? '');
    imageUrlController = TextEditingController(text: item?.imageUrl ?? '');
    sourceController = TextEditingController(text: item?.source ?? '');
  }

  @override
  void dispose() {
    titleController.dispose();
    categoryController.dispose();
    summaryController.dispose();
    bodyController.dispose();
    imageUrlController.dispose();
    sourceController.dispose();
    super.dispose();
  }

  void _save() {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Başlık boş olamaz.')));
      return;
    }
    final nowId = DateTime.now().microsecondsSinceEpoch.toString();
    Navigator.pop(
      context,
      AppContent(
        id: widget.item?.id ?? nowId,
        type: widget.type,
        title: title,
        category: categoryController.text.trim().isEmpty ? (isGallery ? 'Galeri' : 'Genel') : categoryController.text.trim(),
        summary: summaryController.text.trim(),
        body: bodyController.text.trim(),
        imageUrl: imageUrlController.text.trim(),
        source: sourceController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 6,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(widget.item == null ? 'Yeni kayıt' : 'Kaydı düzenle', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _field(titleController, 'Başlık'),
            const SizedBox(height: 10),
            _field(categoryController, isGallery ? 'Kategori / yer' : 'Kategori'),
            const SizedBox(height: 10),
            _field(summaryController, 'Kısa açıklama', maxLines: 2),
            const SizedBox(height: 10),
            _field(bodyController, isGallery ? 'Not / açıklama' : 'Uzun metin', maxLines: 6),
            if (isGallery) ...[
              const SizedBox(height: 10),
              _field(imageUrlController, 'Görsel URL bağlantısı'),
              const SizedBox(height: 10),
              _field(sourceController, 'Kaynak / lisans bilgisi'),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Kaydet')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    );
  }
}

class InfoPanel extends StatelessWidget {
  final String title;
  final String text;

  const InfoPanel({super.key, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(text, style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}

class EmptyPanel extends StatelessWidget {
  final String text;

  const EmptyPanel({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(child: Text(text, textAlign: TextAlign.center)),
    );
  }
}

class ContentTypes {
  static const article = 'article';
  static const field = 'field';
  static const gallery = 'gallery';
}

class AppContent {
  final String id;
  final String type;
  final String title;
  final String category;
  final String summary;
  final String body;
  final String imageUrl;
  final String source;

  const AppContent({
    required this.id,
    required this.type,
    required this.title,
    required this.category,
    required this.summary,
    required this.body,
    this.imageUrl = '',
    this.source = '',
  });

  IconData get icon {
    if (type == ContentTypes.field) return Icons.location_on_outlined;
    if (type == ContentTypes.gallery) return Icons.photo_library_outlined;
    final lower = category.toLowerCase();
    if (lower.contains('arkeoloji')) return Icons.account_balance_outlined;
    if (lower.contains('gökyüzü') || lower.contains('ufo')) return Icons.public;
    if (lower.contains('mitoloji')) return Icons.auto_awesome_outlined;
    return Icons.article_outlined;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'category': category,
        'summary': summary,
        'body': body,
        'imageUrl': imageUrl,
        'source': source,
      };

  factory AppContent.fromJson(Map<String, dynamic> json, String fallbackType) {
    return AppContent(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      type: json['type']?.toString() ?? fallbackType,
      title: json['title']?.toString() ?? 'Başlıksız',
      category: json['category']?.toString() ?? 'Genel',
      summary: json['summary']?.toString() ?? '',
      body: json['body']?.toString() ?? '',
      imageUrl: json['imageUrl']?.toString() ?? '',
      source: json['source']?.toString() ?? '',
    );
  }
}

class LocalStore {
  static const articlesKey = 'v2_articles_json';
  static const fieldNotesKey = 'v2_field_notes_json';
  static const galleryKey = 'v2_gallery_json';

  static Future<List<AppContent>> loadList(String key, List<AppContent> defaults) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.trim().isEmpty) return [...defaults];
    try {
      final decoded = jsonDecode(raw);
      final type = defaults.isEmpty ? ContentTypes.article : defaults.first.type;
      final list = decodeList(decoded, type);
      return list.isEmpty ? [...defaults] : list;
    } catch (_) {
      return [...defaults];
    }
  }

  static Future<void> saveList(String key, List<AppContent> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(items.map((item) => item.toJson()).toList()));
  }

  static List<AppContent> decodeList(dynamic decoded, String fallbackType) {
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((entry) => AppContent.fromJson(Map<String, dynamic>.from(entry), fallbackType))
        .toList();
  }
}

const defaultArticles = [
  AppContent(
    id: 'article_1',
    type: ContentTypes.article,
    title: 'Mağaralar, Hafıza ve Köken Anlatıları',
    category: 'Mitoloji',
    summary: 'Mağara mekânının eski anlatılardaki simgesel rolü.',
    body:
        'Mağara, birçok kadim anlatıda yalnızca saklanma yeri değildir. Karanlık, geçiş, yeniden doğuş, bilinmeyenle yüzleşme ve köken hafızası gibi anlamlar taşır. Kahramanın mağarada karşılaştığı varlık, çoğu zaman sıradan bir figür değil, soyun veya bilginin gizli tarafını temsil eden eşik varlığıdır.',
  ),
  AppContent(
    id: 'article_2',
    type: ContentTypes.article,
    title: 'Şahmeran: Yılan Bedenli Bilgelik Figürü',
    category: 'Anadolu Efsaneleri',
    summary: 'Şahmeran anlatısında bilgelik, sır ve beden sembolizmi.',
    body:
        'Şahmeran anlatısı; yarı insan yarı yılan formuyla hem korkuyu hem bilgeliği aynı bedende toplar. Bu ikili yapı, eski toplumların doğa, ölüm, şifa ve gizli bilgiyle kurduğu ilişkiyi okumak için güçlü bir kapı açar.',
  ),
  AppContent(
    id: 'article_3',
    type: ContentTypes.article,
    title: 'Draco Takımyıldızı ve Antik Gökyüzü Haritaları',
    category: 'Gökyüzü',
    summary: 'Ejderha/yılan sembolünün göksel karşılıkları.',
    body:
        'Draco takımyıldızı, gökyüzünde yılanımsı uzun formuyla tarih boyunca dikkat çekmiştir. Antik toplumların gökyüzünü yalnızca takvim için değil, mitolojik hafıza için de kullandığı düşünülür.',
  ),
  AppContent(
    id: 'article_4',
    type: ContentTypes.article,
    title: 'Göbekli Tepe ve Sembol Hafızası',
    category: 'Arkeoloji',
    summary: 'Taş sütunlar, hayvan kabartmaları ve ritüel alan fikri.',
    body:
        'Göbekli Tepe, sembollerin taş üzerine işlendiği güçlü bir hafıza alanı olarak görülebilir. Hayvan kabartmaları, ritüel düzen ve anıtsal mimari; insanlığın erken dönem inanç dünyasına dair büyük sorular doğurur.',
  ),
  AppContent(
    id: 'article_5',
    type: ContentTypes.article,
    title: 'Derinkuyu: Yeraltı, Koridor ve Saklı Yaşam',
    category: 'Yeraltı Şehirleri',
    summary: 'Kapalı mekân, geçitler ve savunma mimarisi.',
    body:
        'Derinkuyu gibi yeraltı şehirleri; dar koridorları, taş kapıları ve katmanlı yapısıyla yalnızca mimari değil, psikolojik bir atmosfer de oluşturur. Yeraltına iniş, eski anlatılardaki bilinmeyene geçiş temasını hatırlatır.',
  ),
];

const defaultFieldNotes = [
  AppContent(
    id: 'field_1',
    type: ContentTypes.field,
    title: 'Hattuşa Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Büyük Mabed, Yeşil Taş ve Hitit başkentinin izleri.',
    body:
        'Hattuşa gezisi, taş mimariyi ve kutsal alan düzenini yerinde görmek için güçlü bir saha noktasıdır. Büyük Mabed ve Yeşil Taş, araştırma arşivinde ayrıca incelenebilir.',
  ),
  AppContent(
    id: 'field_2',
    type: ContentTypes.field,
    title: 'Yazılıkaya Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Tanrı kabartmaları, geçit ve kaya tapınağı atmosferi.',
    body:
        'Yazılıkaya, açık hava kaya tapınağı atmosferiyle mitolojik figürleri taş üzerine taşıyan özel bir alandır. Kabartmalar, geçit ve kaya yüzeyi bir arada okunmalıdır.',
  ),
  AppContent(
    id: 'field_3',
    type: ContentTypes.field,
    title: 'Efes Saha Notu',
    category: 'İzmir / Selçuk',
    summary: 'Celsus, Yamaç Evleri ve antik şehir dokusu.',
    body:
        'Efes, Roma dönemi mimari hafızasını güçlü şekilde taşır. Yamaç Evleri, Celsus ve Herakles Kapısı gibi noktalar görsel arşiv için değerlidir.',
  ),
  AppContent(
    id: 'field_4',
    type: ContentTypes.field,
    title: 'Myra Saha Notu',
    category: 'Antalya / Demre',
    summary: 'Kaya mezarları, Medusa imgesi ve Likya dokusu.',
    body:
        'Myra, kaya mezarları ve antik tiyatrosuyla Likya dünyasının güçlü izlerini taşır. Medusa ve koruyucu sembol fikri burada ayrıca araştırılabilir.',
  ),
];

const defaultGalleryItems = [
  AppContent(
    id: 'gallery_1',
    type: ContentTypes.gallery,
    title: 'Göbekli Tepe',
    category: 'Galeri',
    summary: 'Gerçek/telifsiz görsel bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_2',
    type: ContentTypes.gallery,
    title: 'Hattuşa',
    category: 'Galeri',
    summary: 'Gerçek saha fotoğrafı için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_3',
    type: ContentTypes.gallery,
    title: 'Yazılıkaya',
    category: 'Galeri',
    summary: 'Açık lisanslı kaynak görsel için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_4',
    type: ContentTypes.gallery,
    title: 'Derinkuyu',
    category: 'Galeri',
    summary: 'Gerçek fotoğraf bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
];
