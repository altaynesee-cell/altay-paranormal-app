import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';

const appVersionLabel = 'SÜRÜM 14 • HATA DÜZELTME';

void main() {
  runApp(const AltayParanormalApp());
}

class AltayParanormalApp extends StatelessWidget {
  const AltayParanormalApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8A5A22);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gizem ve Paranormal Arşivim',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F1E6),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;
  bool loading = true;
  List<AppContent> articles = [];
  List<AppContent> fieldNotes = [];
  List<AppContent> galleryItems = [];
  List<AppContent> bookChapters = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedArticles = await LocalStore.loadList(LocalStore.articlesKey, defaultArticles);
    final loadedFieldNotes = await LocalStore.loadList(LocalStore.fieldNotesKey, defaultFieldNotes);
    final loadedGallery = await LocalStore.loadList(LocalStore.galleryKey, defaultGalleryItems);
    final loadedBook = await LocalStore.loadList(LocalStore.bookKey, defaultBookChapters);
    if (!mounted) return;
    setState(() {
      articles = loadedArticles;
      fieldNotes = loadedFieldNotes;
      galleryItems = loadedGallery;
      bookChapters = loadedBook;
      loading = false;
    });
  }

  Future<void> _saveAll() async {
    await LocalStore.saveList(LocalStore.articlesKey, articles);
    await LocalStore.saveList(LocalStore.fieldNotesKey, fieldNotes);
    await LocalStore.saveList(LocalStore.galleryKey, galleryItems);
    await LocalStore.saveList(LocalStore.bookKey, bookChapters);
  }

  List<AppContent> _listForType(String type) {
    switch (type) {
      case ContentTypes.article:
        return articles;
      case ContentTypes.field:
        return fieldNotes;
      case ContentTypes.gallery:
        return galleryItems;
      case ContentTypes.book:
        return bookChapters;
      default:
        return articles;
    }
  }

  Future<void> _replaceList(String type, List<AppContent> list) async {
    setState(() {
      if (type == ContentTypes.article) articles = list;
      if (type == ContentTypes.field) fieldNotes = list;
      if (type == ContentTypes.gallery) galleryItems = list;
      if (type == ContentTypes.book) bookChapters = list;
    });
    await _saveAll();
  }

  Future<void> _addItem(AppContent item) async {
    final list = [..._listForType(item.type), item];
    await _replaceList(item.type, list);
  }

  Future<void> _updateItem(AppContent item) async {
    final list = _listForType(item.type)
        .map((existing) => existing.id == item.id ? item : existing)
        .toList();
    await _replaceList(item.type, list);
  }

  Future<void> _deleteItem(AppContent item) async {
    final list = _listForType(item.type).where((existing) => existing.id != item.id).toList();
    await _replaceList(item.type, list);
  }

  Future<void> _resetData() async {
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
      bookChapters = [...defaultBookChapters];
    });
    await _saveAll();
  }

  String _exportData() {
    return const JsonEncoder.withIndent('  ').convert({
      'articles': articles.map((item) => item.toJson()).toList(),
      'fieldNotes': fieldNotes.map((item) => item.toJson()).toList(),
      'gallery': galleryItems.map((item) => item.toJson()).toList(),
      'book': bookChapters.map((item) => item.toJson()).toList(),
    });
  }

  Future<void> _importData(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Yedek metni geçerli değil.');
    }
    final newArticles = LocalStore.decodeList(decoded['articles'], ContentTypes.article);
    final newFieldNotes = LocalStore.decodeList(decoded['fieldNotes'], ContentTypes.field);
    final newGallery = LocalStore.decodeList(decoded['gallery'], ContentTypes.gallery);
    final newBook = LocalStore.decodeList(decoded['book'], ContentTypes.book);
    setState(() {
      articles = newArticles.isEmpty ? articles : newArticles;
      fieldNotes = newFieldNotes.isEmpty ? fieldNotes : newFieldNotes;
      galleryItems = newGallery.isEmpty ? galleryItems : newGallery;
      bookChapters = newBook.isEmpty ? bookChapters : newBook;
    });
    await _saveAll();
  }

  void _openAdmin({int initialTabIndex = 0}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AdminPage(
          initialTabIndex: initialTabIndex,
          articles: articles,
          fieldNotes: fieldNotes,
          galleryItems: galleryItems,
          bookChapters: bookChapters,
          onAdd: _addItem,
          onUpdate: _updateItem,
          onDelete: _deleteItem,
          onReset: _resetData,
          exportData: _exportData,
          importData: _importData,
        ),
      ),
    );
  }


  Future<void> _openQuickEditor(AppContent item) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: item.type, item: item),
    );
    if (result == null) return;
    await _updateItem(result);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Değişiklik kaydedildi.')));
  }

  void _openAbout() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutPage()));
  }

  void _openContact() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ContactPage()));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final pages = [
      HomePage(
        articlesCount: articles.length,
        fieldCount: fieldNotes.length,
        galleryCount: galleryItems.length,
        onOpenAdmin: () => _openAdmin(),
      ),
      ArticlesPage(items: articles, onEdit: _openQuickEditor),
      FieldNotesPage(items: fieldNotes, onEdit: _openQuickEditor),
      GalleryPage(items: galleryItems, onOpenGalleryAdmin: () => _openAdmin(initialTabIndex: 2), onEdit: _openQuickEditor),
      BookPage(items: bookChapters, onOpenBookAdmin: () => _openAdmin(initialTabIndex: 3), onEdit: _openQuickEditor),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gizem ve Paranormal Arşivim'),
        actions: [
          IconButton(
            tooltip: 'Yönetim',
            onPressed: () => _openAdmin(),
            icon: const Icon(Icons.admin_panel_settings_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'about') _openAbout();
              if (value == 'contact') _openContact();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'about', child: Text('Hakkımda')),
              PopupMenuItem(value: 'contact', child: Text('İletişim')),
            ],
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: pages[selectedIndex],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana'),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Yazılar'),
          NavigationDestination(icon: Icon(Icons.travel_explore_outlined), selectedIcon: Icon(Icons.travel_explore), label: 'Saha'),
          NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'Galeri'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Kitap'),
        ],
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int articlesCount;
  final int fieldCount;
  final int galleryCount;
  final VoidCallback onOpenAdmin;

  const HomePage({
    super.key,
    required this.articlesCount,
    required this.fieldCount,
    required this.galleryCount,
    required this.onOpenAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const HeroHeader(),
        const SizedBox(height: 12),
        const VersionBanner(),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: onOpenAdmin,
          icon: const Icon(Icons.edit_note),
          label: const Text('Yönetim paneli: yazı, saha notu ve galeri ekle'),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: CounterCard(title: 'Yazı', value: articlesCount.toString(), icon: Icons.article_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Saha', value: fieldCount.toString(), icon: Icons.travel_explore_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Galeri', value: galleryCount.toString(), icon: Icons.photo_library_outlined)),
          ],
        ),
        const SizedBox(height: 18),
        Text('Öne Çıkan Dosyalar', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: const [
            FeatureCard(icon: Icons.public, title: 'UFO Dosyaları', subtitle: 'Gözlem, rapor ve olay notları'),
            FeatureCard(icon: Icons.account_balance, title: 'Antik Medeniyetler', subtitle: 'Tapınaklar, semboller, mitler'),
            FeatureCard(icon: Icons.terrain, title: 'Saha Geçmişi', subtitle: 'Hattuşa, Yazılıkaya, Efes, Myra'),
            FeatureCard(icon: Icons.auto_stories, title: 'Kitap Projesi', subtitle: 'Antik Medeniyetlerde Reptilyanların İzinde'),
          ],
        ),
        const SizedBox(height: 18),
        const InfoPanel(
          title: 'Bu sürümde ne var?',
          text:
              'Bu 5. sürümde yazı ve galeri detayları artık yarım açılan pencere yerine tam sayfa açılır. Makale, saha notu ve galeri görseli ekleyebilir, düzenleyebilir ve silebilirsin. Kayıtlar telefonda saklanır. Yedek almayı unutma.',
        ),
      ],
    );
  }
}


class VersionBanner extends StatelessWidget {
  const VersionBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: scheme.tertiaryContainer,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        children: [
          Icon(Icons.verified_outlined, color: scheme.onTertiaryContainer),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '$appVersionLabel aktif. Yazılar artık tam sayfa açılır; galeri ekleme butonu görünür.',
              style: TextStyle(
                color: scheme.onTertiaryContainer,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CounterCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const CounterCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C))),
          ],
        ),
      ),
    );
  }
}

class HeroHeader extends StatelessWidget {
  const HeroHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [scheme.primaryContainer, scheme.secondaryContainer],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.explore, size: 44, color: scheme.onPrimaryContainer),
          const SizedBox(height: 18),
          Text(
            'Gizem, UFO ve Paranormal Araştırman\nAltay Aytın',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            'Anadolu sahalarından antik sembollere, mitolojik anlatılardan modern gizem dosyalarına uzanan bağımsız araştırma arşivi.',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const FeatureCard({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width > 700 ? 260 : double.infinity,
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(child: Icon(icon)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(subtitle),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ArticlesPage extends StatefulWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;

  const ArticlesPage({super.key, required this.items, required this.onEdit});

  @override
  State<ArticlesPage> createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  final controller = TextEditingController();
  String query = '';

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.items.where((item) {
      final q = query.toLowerCase().trim();
      if (q.isEmpty) return true;
      return item.title.toLowerCase().contains(q) ||
          item.summary.toLowerCase().contains(q) ||
          item.category.toLowerCase().contains(q) ||
          item.body.toLowerCase().contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Yazılar', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(
          controller: controller,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            labelText: 'Yazılarda ara',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) => setState(() => query = value),
        ),
        const SizedBox(height: 12),
        for (final article in filtered) ContentTile(item: article, onEdit: widget.onEdit),
        if (filtered.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('Bu aramada sonuç bulunamadı.')),
          ),
      ],
    );
  }
}

class ContentTile extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;

  const ContentTile({super.key, required this.item, this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(child: Icon(item.icon)),
        title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('${item.category} • ${item.summary}'),
        ),
        trailing: SizedBox(
          width: onEdit == null ? 40 : 88,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (onEdit != null)
                IconButton(
                  tooltip: 'Düzenle',
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => onEdit!(item),
                ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
        isThreeLine: true,
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ContentDetailPage(item: item, onEdit: onEdit)),
        ),
      ),
    );
  }
}

class ContentDetailPage extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;

  const ContentDetailPage({super.key, required this.item, this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_shortTitle(item.title)),
        actions: [
          if (onEdit != null)
            IconButton(
              tooltip: 'Bu kaydı düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => onEdit!(item),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            item.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              Chip(label: Text(item.category)),
              if (item.summary.trim().isNotEmpty) Chip(label: Text(item.summary)),
            ],
          ),
          const SizedBox(height: 18),
          SelectableText(
            item.body.trim().isEmpty ? 'Bu kayıt için henüz uzun metin eklenmemiş.' : item.body,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.55),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  static String _shortTitle(String value) {
    final clean = value.trim();
    if (clean.length <= 24) return clean;
    return '${clean.substring(0, 24)}...';
  }
}

class FieldNotesPage extends StatelessWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;

  const FieldNotesPage({super.key, required this.items, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Saha Gezileri', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        for (final note in items) ContentTile(item: note, onEdit: onEdit),
        if (items.isEmpty) const EmptyPanel(text: 'Henüz saha notu yok. Yönetim panelinden ekleyebilirsin.'),
      ],
    );
  }
}

class GalleryPage extends StatelessWidget {
  final List<AppContent> items;
  final VoidCallback onOpenGalleryAdmin;
  final void Function(AppContent item) onEdit;

  const GalleryPage({super.key, required this.items, required this.onOpenGalleryAdmin, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Galeri', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Gerçek, telifsiz, kamu malı veya izinli görseller için ayrıldı. Görsel eklemek için aşağıdaki butona bas.'),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: onOpenGalleryAdmin,
          icon: const Icon(Icons.add_photo_alternate_outlined),
          label: const Text('Galeriye görsel ekle / düzenle'),
        ),
        const SizedBox(height: 14),
        GridView.builder(
          itemCount: items.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.82,
          ),
          itemBuilder: (context, index) => GalleryCard(item: items[index], onEdit: onEdit),
        ),
        if (items.isEmpty) const EmptyPanel(text: 'Henüz galeri kaydı yok. Yönetim panelinden ekleyebilirsin.'),
      ],
    );
  }
}

class GalleryCard extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;

  const GalleryCard({super.key, required this.item, this.onEdit});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _openDetails(context),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: scheme.outlineVariant),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: GalleryImage(item: item, fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold))),
                      if (onEdit != null)
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'Düzenle',
                          onPressed: () => onEdit!(item),
                          icon: const Icon(Icons.edit_outlined, size: 18),
                        ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(item.summary, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openDetails(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GalleryDetailPage(item: item, onEdit: onEdit)),
    );
  }
}

class GalleryDetailPage extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;

  const GalleryDetailPage({super.key, required this.item, this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_shortTitle(item.title)),
        actions: [
          if (onEdit != null)
            IconButton(
              tooltip: 'Galeri kaydını düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => onEdit!(item),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (item.hasImage)
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                constraints: const BoxConstraints(minHeight: 260),
                child: GalleryImage(item: item, fit: BoxFit.contain),
              ),
            )
          else
            const EmptyPanel(text: 'Bu galeri kaydında henüz fotoğraf yok.'),
          const SizedBox(height: 18),
          Text(
            item.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          if (item.summary.trim().isNotEmpty)
            Text(item.summary, style: Theme.of(context).textTheme.bodyLarge),
          if (item.source.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            SelectableText('Kaynak: ${item.source}', style: Theme.of(context).textTheme.bodyMedium),
          ],
          if (item.body.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            SelectableText(item.body, style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.5)),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  static String _shortTitle(String value) {
    final clean = value.trim();
    if (clean.length <= 24) return clean;
    return '${clean.substring(0, 24)}...';
  }
}

class GalleryImage extends StatelessWidget {
  final AppContent item;
  final BoxFit fit;

  const GalleryImage({super.key, required this.item, required this.fit});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final localPath = item.imagePath.trim();
    if (localPath.isNotEmpty && !kIsWeb) {
      final file = File(localPath);
      if (file.existsSync()) {
        return Image.file(
          file,
          width: double.infinity,
          fit: fit,
          errorBuilder: (context, error, stackTrace) => Center(
            child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
          ),
        );
      }
    }

    final url = item.imageUrl.trim();
    if (url.isNotEmpty) {
      return Image.network(
        url,
        width: double.infinity,
        fit: fit,
        errorBuilder: (context, error, stackTrace) => Center(
          child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
        ),
      );
    }

    return Center(child: Icon(Icons.image_outlined, size: 46, color: scheme.primary));
  }
}


class BookPage extends StatelessWidget {
  final List<AppContent> items;
  final VoidCallback onOpenBookAdmin;
  final void Function(AppContent item) onEdit;

  const BookPage({super.key, required this.items, required this.onOpenBookAdmin, required this.onEdit});


  Future<void> _shareCreatedFile(BuildContext context, File file, String label) async {
    try {
      await Share.shareXFiles([XFile(file.path)], text: label);
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: file.path));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Dosya hazır. Yol panoya kopyalandı: ${file.path}')),
      );
    }
  }

  Future<void> _exportWord(BuildContext context) async {
    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce kitap bölümü ekle.')));
      return;
    }
    try {
      final file = await BookExporter.createDocx(items);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'Word kitap taslağı hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Word dosyası oluşturulamadı: $e')));
    }
  }

  Future<void> _exportPdf(BuildContext context) async {
    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce kitap bölümü ekle.')));
      return;
    }
    try {
      final file = await BookExporter.createPdf(items);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'PDF kitap taslağı hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF dosyası oluşturulamadı: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final stats = BookStats.from(items);
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
            child: Card(
              elevation: 0,
              color: const Color(0xFFF1E4CC),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Antik Medeniyetlerde Reptilyanların İzinde',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold, color: const Color(0xFF2B2117)),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${stats.chapterCount} bölüm • yaklaşık ${stats.estimatedPages} sayfa',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: const Color(0xFF5B452C)),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed: onOpenBookAdmin,
                          icon: const Icon(Icons.library_add_outlined),
                          label: const Text('Bölüm ekle / düzenle'),
                        ),
                        FilledButton.tonalIcon(
                          onPressed: () => _exportWord(context),
                          icon: const Icon(Icons.description_outlined),
                          label: const Text('Word'),
                        ),
                        FilledButton.tonalIcon(
                          onPressed: () => _exportPdf(context),
                          icon: const Icon(Icons.picture_as_pdf_outlined),
                          label: const Text('PDF'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Word: yayın evi/editör için düzenlenebilir dosya. PDF: kitabın son görünümünü göstermek için hazırlanır.',
                      style: TextStyle(color: Color(0xFF5B452C), height: 1.35),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.menu_book_outlined), text: 'Bölümler'),
              Tab(icon: Icon(Icons.analytics_outlined), text: 'Durum'),
              Tab(icon: Icon(Icons.checklist_outlined), text: 'Eksikler'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _BookChaptersTab(items: items, onEdit: onEdit),
                _BookStatusTab(stats: stats),
                _BookMissingTab(stats: stats),
              ],
            ),
          ),
        ],
      ),
    );
  }


class _BookChaptersTab extends StatelessWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;

  const _BookChaptersTab({required this.items, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    final stats = BookStats.from(items);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          elevation: 0,
          child: ListTile(
            leading: const Icon(Icons.auto_stories_outlined),
            title: const Text('Kitap okuyucu'),
            subtitle: Text('Toplam yaklaşık ${stats.estimatedPages} sayfa. Bölüme girince önceki/sonraki ile kitap gibi okunur.'),
          ),
        ),
        const SizedBox(height: 10),
        if (items.isEmpty)
          const EmptyPanel(text: 'Henüz kitap bölümü yok. Yönetim panelinden bölüm ekleyebilirsin.')
        else
          ...List.generate(items.length, (index) {
            final item = items[index];
            final chapterPages = BookStats.estimatedPagesFor(item.body);
            return Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: item.hasImage
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: SizedBox(width: 56, height: 72, child: GalleryImage(item: item, fit: BoxFit.cover)),
                      )
                    : CircleAvatar(radius: 28, child: Text('${index + 1}')),
                title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('Bölüm ${index + 1} • yaklaşık $chapterPages sayfa'),
                ),
                trailing: SizedBox(
                  width: 88,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'Bölümü düzenle',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () => onEdit(item),
                      ),
                      const Icon(Icons.menu_book_outlined),
                    ],
                  ),
                ),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BookReaderPage(items: items, initialIndex: index, onEdit: onEdit)),
                ),
              ),
            );
          }),
      ],
    );
  }
}

class _BookStatusTab extends StatelessWidget {
  final BookStats stats;

  const _BookStatusTab({required this.stats});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Kitap Durumu', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.3,
          children: [
            _StatCard(title: 'Bölüm', value: '${stats.chapterCount}', icon: Icons.view_list_outlined),
            _StatCard(title: 'Tahmini sayfa', value: '${stats.estimatedPages}', icon: Icons.menu_book_outlined),
            _StatCard(title: 'Kelime', value: '${stats.wordCount}', icon: Icons.text_fields),
            _StatCard(title: 'Görsel', value: '${stats.imageCount}', icon: Icons.image_outlined),
          ],
        ),
        const SizedBox(height: 14),
        InfoPanel(
          title: 'Standart kitap formatı hesabı',
          text:
              'Sayfa hesabı yaklaşık olarak yapılır: 1 standart kitap sayfası ortalama 250 kelime kabul edilmiştir. Bu ekranda kitabın toplam bölüm, kelime, görsel ve tahmini sayfa durumu takip edilir.',
        ),
        const SizedBox(height: 12),
        InfoPanel(
          title: 'Yayın evine çıktı hazırlama',
          text:
              'Word dosyası, editörün metin üzerinde düzenleme yapması için uygundur. PDF dosyası ise kitabın görsellerle birlikte nasıl görüneceğini göstermek için kullanılır. Yayın evine genelde önce Word dosyası gönderilir; PDF ise ön izleme gibi eklenir.',
        ),
        const SizedBox(height: 12),
        InfoPanel(
          title: 'Raf kitabı hissi',
          text:
              'Kitap sekmesindeki bölümlere bastığında tam sayfa okuyucu açılır. Her bölüm ayrı sayfa gibi görünür; önceki ve sonraki düğmeleriyle kitap okur gibi ilerlersin.',
        ),
      ],
    );
  }
}

class _BookMissingTab extends StatelessWidget {
  final BookStats stats;

  const _BookMissingTab({required this.stats});

  @override
  Widget build(BuildContext context) {
    final missing = stats.missingItems;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Eksik Kontrolü', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Text('Bu liste, kitabı standart kitap düzenine yaklaştırmak için kontrol amaçlıdır.'),
        const SizedBox(height: 12),
        if (missing.isEmpty)
          const InfoPanel(title: 'Durum iyi', text: 'Temel kitap düzeni için büyük eksik görünmüyor. Yine de kaynak ve görsel izinlerini kontrol etmeyi unutma.')
        else
          ...missing.map(
            (item) => Card(
              elevation: 0,
              child: ListTile(
                leading: const Icon(Icons.warning_amber_outlined),
                title: Text(item),
              ),
            ),
          ),
        const SizedBox(height: 12),
        const InfoPanel(
          title: 'Kitap tamamlanmadan önce bakılacaklar',
          text:
              'Önsöz/Giriş, bölüm sıralaması, sonuç bölümü, kaynakça, görsel kaynak bilgileri, kapak/arka kapak yazısı ve sayfa bütünlüğü kontrol edilmeli.',
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon),
            const SizedBox(height: 8),
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}


class BookExporter {
  static String _safeFileName(String value) {
    final cleaned = value
        .replaceAll(RegExp(r'[^\w\sığüşöçİĞÜŞÖÇ-]', unicode: true), '')
        .trim()
        .replaceAll(RegExp(r'\s+'), '_');
    return cleaned.isEmpty ? 'kitap_taslagi' : cleaned;
  }

  static String _xml(String value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&apos;');
  }

  static String _paragraph(String text, {bool bold = false, int size = 24}) {
    final safe = _xml(text);
    final boldTag = bold ? '<w:b/>' : '';
    return '<w:p><w:r><w:rPr>$boldTag<w:sz w:val="$size"/></w:rPr><w:t xml:space="preserve">$safe</w:t></w:r></w:p>';
  }

  static String _imageXml(String rId, int id, {String caption = ''}) {
    final cap = caption.trim().isEmpty ? '' : _paragraph(caption, size: 18);
    return '''
<w:p>
  <w:r>
    <w:drawing>
      <wp:inline distT="0" distB="0" distL="0" distR="0">
        <wp:extent cx="5200000" cy="3600000"/>
        <wp:docPr id="$id" name="Gorsel $id"/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr>
                <pic:cNvPr id="$id" name="image$id"/>
                <pic:cNvPicPr/>
              </pic:nvPicPr>
              <pic:blipFill>
                <a:blip r:embed="$rId"/>
                <a:stretch><a:fillRect/></a:stretch>
              </pic:blipFill>
              <pic:spPr>
                <a:xfrm><a:off x="0" y="0"/><a:ext cx="5200000" cy="3600000"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
              </pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing>
  </w:r>
</w:p>
$cap
''';
  }

  static Future<File> createDocx(List<AppContent> chapters) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) {
      await exportDir.create(recursive: true);
    }
    final file = File('${exportDir.path}/${_safeFileName('Altay Aytin Kitap Taslagi')}.docx');

    final archive = Archive();
    final rels = <String>[];
    final doc = StringBuffer();
    var imageId = 1;

    String addImage(String path, {String caption = ''}) {
      final clean = path.trim();
      if (clean.isEmpty) return '';
      final source = File(clean);
      if (!source.existsSync()) return _paragraph('Görsel bulunamadı: $clean', size: 18);
      final bytes = source.readAsBytesSync();
      final extensionRaw = source.path.split('.').last.toLowerCase();
      final extension = ['jpg', 'jpeg', 'png', 'webp'].contains(extensionRaw) ? extensionRaw : 'jpg';
      final mediaName = 'image$imageId.$extension';
      final rId = 'rId$imageId';
      archive.addFile(ArchiveFile('word/media/$mediaName', bytes.length, bytes));
      rels.add('<Relationship Id="$rId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/$mediaName"/>');
      final xml = _imageXml(rId, imageId, caption: caption);
      imageId++;
      return xml;
    }

    doc.writeln(_paragraph('ANTİK MEDENİYETLERDE REPTİLYANLARIN İZİNDE', bold: true, size: 38));
    doc.writeln(_paragraph('Gizem, UFO ve Paranormal Araştırmacı Altay Aytın', size: 24));
    doc.writeln(_paragraph('Kitap toplamı: yaklaşık ${BookStats.from(chapters).estimatedPages} sayfa', size: 22));
    doc.writeln('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');

    final marker = RegExp(r'^\s*\[(?:GÖRSEL|GORSEL)\s*(\d+)(?::\s*(.*))?\]\s*$', caseSensitive: false);

    for (var i = 0; i < chapters.length; i++) {
      final item = chapters[i];
      doc.writeln(_paragraph('${i + 1}. BÖLÜM', bold: true, size: 30));
      doc.writeln(_paragraph(item.title, bold: true, size: 34));
      if (item.imagePath.trim().isNotEmpty) {
        doc.writeln(addImage(item.imagePath, caption: 'Bölüm görseli'));
      }

      final used = <int>{};
      var autoImageIndex = 0;
      final paragraphLines = <String>[];

      int nextAutoImageIndex() {
        while (used.contains(autoImageIndex)) {
          autoImageIndex++;
        }
        return autoImageIndex++;
      }

      void flush() {
        final value = paragraphLines.join(' ').trim();
        if (value.isNotEmpty) doc.writeln(_paragraph(value, size: 24));
        paragraphLines.clear();
      }

      for (final line in item.body.split('\n')) {
        final match = marker.firstMatch(line);
        if (match != null) {
          flush();
          final rawNumber = (match.group(1) ?? '').trim();
          final explicitNumber = int.tryParse(rawNumber);
          final imageIndex = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
          final number = imageIndex + 1;
          final caption = (match.group(2) ?? '').trim();
          used.add(imageIndex);
          if (imageIndex >= 0 && imageIndex < item.inlineImagePaths.length) {
            doc.writeln(addImage(item.inlineImagePaths[imageIndex], caption: caption.isEmpty ? 'Görsel $number' : caption));
          } else {
            doc.writeln(_paragraph('Görsel $number seçilmemiş.', size: 18));
          }
        } else if (line.trim().isEmpty) {
          flush();
        } else {
          paragraphLines.add(line.trim());
        }
      }
      flush();

      for (var n = 0; n < item.inlineImagePaths.length; n++) {
        if (!used.contains(n) && item.inlineImagePaths[n].trim().isNotEmpty) {
          doc.writeln(addImage(item.inlineImagePaths[n], caption: 'Görsel ${n + 1}'));
        }
      }

      if (i != chapters.length - 1) {
        doc.writeln('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      }
    }

    final documentXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
 xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
 xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
 xmlns:v="urn:schemas-microsoft-com:vml"
 xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
 xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
 xmlns:w10="urn:schemas-microsoft-com:office:word"
 xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
 xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
 xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
 xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
 xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
 mc:Ignorable="w14 wp14">
 <w:body>
 ${doc.toString()}
 <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>
 </w:body>
</w:document>''';

    final relsXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${rels.join('\n')}
</Relationships>''';

    void addString(String name, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(name, bytes.length, bytes));
    }

    addString('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="jpg" ContentType="image/jpeg"/>
<Default Extension="jpeg" ContentType="image/jpeg"/>
<Default Extension="png" ContentType="image/png"/>
<Default Extension="webp" ContentType="image/webp"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>''');

    addString('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>''');

    addString('word/document.xml', documentXml);
    addString('word/_rels/document.xml.rels', relsXml);
    addString('docProps/core.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:dcterms="http://purl.org/dc/terms/"
 xmlns:dcmitype="http://purl.org/dc/dcmitype/"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>Antik Medeniyetlerde Reptilyanların İzinde</dc:title>
<dc:creator>Altay Aytın</dc:creator>
</cp:coreProperties>''');
    addString('docProps/app.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
 xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>Altay Paranormal Arşiv</Application>
</Properties>''');

    final bytes = ZipEncoder().encode(archive);
    if (bytes == null) throw Exception('DOCX zip oluşturulamadı.');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  static Future<File> createPdf(List<AppContent> chapters) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) {
      await exportDir.create(recursive: true);
    }
    final file = File('${exportDir.path}/${_safeFileName('Altay Aytin Kitap Taslagi')}.pdf');

    final doc = pw.Document();
    final stats = BookStats.from(chapters);

    Future<List<pw.Widget>> buildChapter(AppContent item, int index) async {
      final widgets = <pw.Widget>[];
      final textStyle = pw.TextStyle(fontSize: 12, height: 1.5);
      final marker = RegExp(r'^\s*\[(?:GÖRSEL|GORSEL)\s*(\d+)(?::\s*(.*))?\]\s*$', caseSensitive: false);
      final paragraphLines = <String>[];
      final used = <int>{};

      Future<void> addImage(String path, String caption) async {
        final clean = path.trim();
        if (clean.isEmpty) return;
        final source = File(clean);
        if (!source.existsSync()) return;
        try {
          final bytes = await source.readAsBytes();
          widgets.add(pw.SizedBox(height: 10));
          widgets.add(pw.Center(child: pw.Image(pw.MemoryImage(bytes), width: 430, fit: pw.BoxFit.contain)));
          if (caption.trim().isNotEmpty) {
            widgets.add(pw.SizedBox(height: 4));
            widgets.add(pw.Text(caption, style: pw.TextStyle(fontSize: 9)));
          }
          widgets.add(pw.SizedBox(height: 10));
        } catch (_) {}
      }

      void flush() {
        final value = paragraphLines.join(' ').trim();
        if (value.isNotEmpty) {
          widgets.add(pw.Paragraph(text: value, style: textStyle));
        }
        paragraphLines.clear();
      }

      widgets.add(pw.Header(level: 0, text: '${index + 1}. Bölüm'));
      widgets.add(pw.Text(item.title, style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)));
      widgets.add(pw.SizedBox(height: 8));
      if (item.imagePath.trim().isNotEmpty) {
        await addImage(item.imagePath, 'Bölüm görseli');
      }

      for (final line in item.body.split('\n')) {
        final match = marker.firstMatch(line);
        if (match != null) {
          flush();
          final rawNumber = (match.group(1) ?? '').trim();
          final explicitNumber = int.tryParse(rawNumber);
          final imageIndex = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
          final number = imageIndex + 1;
          final caption = (match.group(2) ?? '').trim();
          used.add(imageIndex);
          if (imageIndex >= 0 && imageIndex < item.inlineImagePaths.length) {
            await addImage(item.inlineImagePaths[imageIndex], caption.isEmpty ? 'Görsel $number' : caption);
          }
        } else if (line.trim().isEmpty) {
          flush();
        } else {
          paragraphLines.add(line.trim());
        }
      }
      flush();

      for (var n = 0; n < item.inlineImagePaths.length; n++) {
        if (!used.contains(n)) {
          await addImage(item.inlineImagePaths[n], 'Görsel ${n + 1}');
        }
      }
      return widgets;
    }

    final allWidgets = <pw.Widget>[
      pw.Text('ANTİK MEDENİYETLERDE REPTİLYANLARIN İZİNDE', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 8),
      pw.Text('Gizem, UFO ve Paranormal Araştırmacı Altay Aytın', style: pw.TextStyle(fontSize: 14)),
      pw.SizedBox(height: 8),
      pw.Text('Toplam: ${stats.chapterCount} bölüm • yaklaşık ${stats.estimatedPages} sayfa • ${stats.wordCount} kelime'),
      pw.SizedBox(height: 20),
      pw.Divider(),
      pw.NewPage(),
    ];

    for (var i = 0; i < chapters.length; i++) {
      allWidgets.addAll(await buildChapter(chapters[i], i));
      if (i != chapters.length - 1) allWidgets.add(pw.NewPage());
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(36),
        build: (context) => allWidgets,
      ),
    );

    await file.writeAsBytes(await doc.save(), flush: true);
    return file;
  }
}

class BookStats {
  static const int wordsPerPage = 250;
  final int chapterCount;
  final int wordCount;
  final int estimatedPages;
  final int imageCount;
  final int shortChapterCount;
  final bool hasIntro;
  final bool hasConclusion;
  final bool hasSources;

  const BookStats({
    required this.chapterCount,
    required this.wordCount,
    required this.estimatedPages,
    required this.imageCount,
    required this.shortChapterCount,
    required this.hasIntro,
    required this.hasConclusion,
    required this.hasSources,
  });

  factory BookStats.from(List<AppContent> items) {
    final words = items.fold<int>(0, (sum, item) => sum + countWords('${item.title} ${item.summary} ${item.body}'));
    final lowerTitles = items.map((item) => item.title.toLowerCase()).join(' ');
    final lowerAll = items.map((item) => '${item.title} ${item.body} ${item.source}'.toLowerCase()).join(' ');
    return BookStats(
      chapterCount: items.length,
      wordCount: words,
      estimatedPages: pagesFromWords(words),
      imageCount: items.fold<int>(0, (sum, item) => sum + item.imageCount),
      shortChapterCount: items.where((item) => countWords(item.body) < 120).length,
      hasIntro: lowerTitles.contains('giriş') || lowerTitles.contains('giris') || lowerTitles.contains('önsöz') || lowerTitles.contains('onsoz'),
      hasConclusion: lowerTitles.contains('sonuç') || lowerTitles.contains('sonuc') || lowerTitles.contains('kapanış') || lowerTitles.contains('kapanis'),
      hasSources: lowerAll.contains('kaynak') || items.any((item) => item.source.trim().isNotEmpty),
    );
  }

  static int countWords(String value) {
    final matches = RegExp(r'\S+').allMatches(value.trim());
    return matches.length;
  }

  static int pagesFromWords(int words) {
    if (words <= 0) return 0;
    return (words / wordsPerPage).ceil();
  }

  static int estimatedPagesFor(String text) => pagesFromWords(countWords(text));

  List<String> get missingItems {
    final list = <String>[];
    if (chapterCount == 0) list.add('Henüz kitap bölümü eklenmemiş.');
    if (!hasIntro) list.add('Giriş veya önsöz bölümü görünmüyor.');
    if (!hasConclusion) list.add('Sonuç / kapanış bölümü görünmüyor.');
    if (!hasSources) list.add('Kaynakça veya kaynak bilgisi görünmüyor.');
    if (imageCount < chapterCount) list.add('${chapterCount - imageCount} bölümde görsel yok.');
    if (shortChapterCount > 0) list.add('$shortChapterCount bölüm çok kısa görünüyor; metin geliştirilebilir.');
    if (estimatedPages < 80) list.add('Kitap hacmi şu an kısa görünüyor: yaklaşık $estimatedPages sayfa.');
    return list;
  }
}

class BookReaderPage extends StatefulWidget {
  final List<AppContent> items;
  final int initialIndex;
  final void Function(AppContent item)? onEdit;

  const BookReaderPage({super.key, required this.items, required this.initialIndex, this.onEdit});

  @override
  State<BookReaderPage> createState() => _BookReaderPageState();
}

class _BookReaderPageState extends State<BookReaderPage> {
  late final PageController controller;
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.initialIndex;
    controller = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _goTo(int index) {
    controller.animateToPage(index, duration: const Duration(milliseconds: 280), curve: Curves.easeOut);
  }

  List<Widget> _buildBookBody(BuildContext context, AppContent item) {
    const textColor = Color(0xFF2B2117);
    final textStyle = Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.85, color: textColor);
    final widgets = <Widget>[];
    final buffer = <String>[];
    final usedImageIndexes = <int>{};
    final marker = RegExp(r'^\s*\[(?:GÖRSEL|GORSEL)\s*(\d+)(?::\s*(.*))?\]\s*$', caseSensitive: false);

    void flushText() {
      final text = buffer.join('\n').trim();
      if (text.isNotEmpty) {
        widgets.add(SelectableText(text, style: textStyle));
        widgets.add(const SizedBox(height: 16));
      }
      buffer.clear();
    }

    final body = item.body.trim();
    if (body.isEmpty) {
      widgets.add(SelectableText('Bu bölüm için henüz metin eklenmemiş.', style: textStyle));
      return widgets;
    }

    for (final line in body.split('\n')) {
      final match = marker.firstMatch(line);
      if (match != null) {
        flushText();
        final rawNumber = (match.group(1) ?? '').trim();
        final explicitNumber = int.tryParse(rawNumber);
        final index = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
        final imageNumber = index + 1;
        final caption = (match.group(2) ?? '').trim();
        usedImageIndexes.add(index);
        widgets.add(BookInlineImage(path: index >= 0 && index < item.inlineImagePaths.length ? item.inlineImagePaths[index] : '', number: imageNumber, caption: caption));
        widgets.add(const SizedBox(height: 18));
      } else {
        buffer.add(line);
      }
    }
    flushText();

    for (var i = 0; i < item.inlineImagePaths.length; i++) {
      if (!usedImageIndexes.contains(i) && item.inlineImagePaths[i].trim().isNotEmpty) {
        widgets.add(BookInlineImage(path: item.inlineImagePaths[i], number: i + 1, caption: 'Metinde [GÖRSEL${i + 1}] işareti yoktu; görsel bölüm sonunda gösterildi.'));
        widgets.add(const SizedBox(height: 18));
      }
    }

    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    final pages = widget.items;
    final stats = BookStats.from(pages);
    return Scaffold(
      appBar: AppBar(
        title: Text('Kitap • Bölüm ${currentIndex + 1}/${pages.length}'),
        actions: [
          if (widget.onEdit != null && pages.isNotEmpty)
            IconButton(
              tooltip: 'Bu bölümü düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => widget.onEdit!(pages[currentIndex]),
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: LinearProgressIndicator(value: pages.isEmpty ? 0 : (currentIndex + 1) / pages.length),
          ),
          Expanded(
            child: PageView.builder(
              controller: controller,
              itemCount: pages.length,
              onPageChanged: (value) => setState(() => currentIndex = value),
              itemBuilder: (context, index) {
                final item = pages[index];
                final chapterPages = BookStats.estimatedPagesFor(item.body);
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7EFD9),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFD8C39A)),
                        boxShadow: const [
                          BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 4)),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(child: Text('Bölüm ${index + 1}', style: Theme.of(context).textTheme.labelLarge?.copyWith(color: const Color(0xFF5B452C)))),
                              Text('Yaklaşık $chapterPages sayfa', style: Theme.of(context).textTheme.labelMedium?.copyWith(color: const Color(0xFF5B452C))),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            item.title,
                            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, height: 1.15, color: const Color(0xFF2B2117)),
                          ),
                          if (item.summary.trim().isNotEmpty) ...[
                            const SizedBox(height: 10),
                            Text(item.summary, style: Theme.of(context).textTheme.titleMedium?.copyWith(color: const Color(0xFF4A3925))),
                          ],
                          const SizedBox(height: 8),
                          Text('Kitap toplamı: yaklaşık ${stats.estimatedPages} sayfa', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C))),
                          if (item.hasImage) ...[
                            const SizedBox(height: 18),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: AspectRatio(
                                aspectRatio: 4 / 3,
                                child: GalleryImage(item: item, fit: BoxFit.cover),
                              ),
                            ),
                          ],
                          const SizedBox(height: 18),
                          ..._buildBookBody(context, item),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: currentIndex > 0 ? () => _goTo(currentIndex - 1) : null,
                      icon: const Icon(Icons.chevron_left),
                      label: const Text('Önceki'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: currentIndex < pages.length - 1 ? () => _goTo(currentIndex + 1) : null,
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('Sonraki'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class BookInlineImage extends StatelessWidget {
  final String path;
  final int number;
  final String caption;

  const BookInlineImage({super.key, required this.path, required this.number, this.caption = ''});

  @override
  Widget build(BuildContext context) {
    const textColor = Color(0xFF2B2117);
    if (path.trim().isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF6E6),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFD8C39A)),
        ),
        child: Text('Görsel $number seçilmemiş. Yönetim panelinden Görsel $number seç.', style: const TextStyle(color: textColor)),
      );
    }

    final file = File(path);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: file.existsSync()
              ? Image.file(file, width: double.infinity, fit: BoxFit.contain)
              : Container(
                  height: 180,
                  alignment: Alignment.center,
                  color: const Color(0xFFFFF6E6),
                  child: Text('Görsel $number bulunamadı.', style: const TextStyle(color: textColor)),
                ),
        ),
        const SizedBox(height: 6),
        Text(caption.trim().isEmpty ? 'Görsel $number' : caption, style: const TextStyle(color: Color(0xFF5B452C), fontSize: 13)),
      ],
    );
  }
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hakkımda')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          InfoPanel(
            title: 'Altay Aytın',
            text:
                'Gizem, UFO ve paranormal alanlara ilgi duyan bağımsız araştırmacı. Anadolu’da saha gözlemleri, antik yapılar, mitolojik anlatılar ve semboller üzerine notlar tutar.',
          ),
          SizedBox(height: 12),
          InfoPanel(
            title: 'Araştırma yaklaşımı',
            text:
                'Akademik iddia yerine merak, gözlem, kaynak taraması ve sahada görme isteği ön plandadır. Uygulama da bu kişisel araştırma arşivini düzenli şekilde sunmak için hazırlanmıştır.',
          ),
        ],
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    const email = 'altaynesee@gmail.com';
    const handle = '@altaynesee';

    return Scaffold(
      appBar: AppBar(title: const Text('İletişim')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.email_outlined),
              title: const Text(email),
              subtitle: const Text('E-posta adresini kopyala'),
              onTap: () => copyText(context, email),
            ),
          ),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.alternate_email),
              title: const Text(handle),
              subtitle: const Text('Sosyal medya kullanıcı adını kopyala'),
              onTap: () => copyText(context, handle),
            ),
          ),
          const SizedBox(height: 12),
          const InfoPanel(
            title: 'Not',
            text:
                'Bu sürümde bağlantılar kopyalama şeklinde çalışır. Sonraki sürümde WhatsApp, Instagram, YouTube veya web sitesi bağlantıları doğrudan açılabilir.',
          ),
        ],
      ),
    );
  }

  static Future<void> copyText(BuildContext context, String value) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Kopyalandı: $value')));
  }
}

class AdminPage extends StatefulWidget {
  final int initialTabIndex;
  final List<AppContent> articles;
  final List<AppContent> fieldNotes;
  final List<AppContent> galleryItems;
  final List<AppContent> bookChapters;
  final Future<void> Function(AppContent item) onAdd;
  final Future<void> Function(AppContent item) onUpdate;
  final Future<void> Function(AppContent item) onDelete;
  final Future<void> Function() onReset;
  final String Function() exportData;
  final Future<void> Function(String raw) importData;

  const AdminPage({
    super.key,
    this.initialTabIndex = 0,
    required this.articles,
    required this.fieldNotes,
    required this.galleryItems,
    required this.bookChapters,
    required this.onAdd,
    required this.onUpdate,
    required this.onDelete,
    required this.onReset,
    required this.exportData,
    required this.importData,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late List<AppContent> articles;
  late List<AppContent> fieldNotes;
  late List<AppContent> galleryItems;
  late List<AppContent> bookChapters;

  @override
  void initState() {
    super.initState();
    articles = [...widget.articles];
    fieldNotes = [...widget.fieldNotes];
    galleryItems = [...widget.galleryItems];
    bookChapters = [...widget.bookChapters];
  }

  List<AppContent> _itemsForType(String type) {
    if (type == ContentTypes.article) return articles;
    if (type == ContentTypes.field) return fieldNotes;
    if (type == ContentTypes.gallery) return galleryItems;
    return bookChapters;
  }

  void _setItemsForType(String type, List<AppContent> items) {
    setState(() {
      if (type == ContentTypes.article) articles = items;
      if (type == ContentTypes.field) fieldNotes = items;
      if (type == ContentTypes.gallery) galleryItems = items;
      if (type == ContentTypes.book) bookChapters = items;
    });
  }

  Future<void> _openEditor(String type, {AppContent? item}) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: type, item: item),
    );
    if (result == null) return;

    final current = _itemsForType(type);
    if (item == null) {
      _setItemsForType(type, [...current, result]);
      await widget.onAdd(result);
    } else {
      final updated = current.map((existing) => existing.id == result.id ? result : existing).toList();
      _setItemsForType(type, updated);
      await widget.onUpdate(result);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kaydedildi.')));
  }

  Future<void> _delete(AppContent item) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    final updated = _itemsForType(item.type).where((existing) => existing.id != item.id).toList();
    _setItemsForType(item.type, updated);
    await widget.onDelete(item);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  Future<void> _reset() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Örnek içeriklere dönülsün mü?'),
        content: const Text('Eklediğin yerel içerikler silinir. Önce yedek alman iyi olur.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sıfırla')),
        ],
      ),
    );
    if (approved != true) return;
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
      bookChapters = [...defaultBookChapters];
    });
    await widget.onReset();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Örnek içerikler geri yüklendi.')));
  }

  Future<void> _copyBackup() async {
    final data = widget.exportData();
    await Clipboard.setData(ClipboardData(text: data));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek panoya kopyalandı. Notlara yapıştırıp saklayabilirsin.')));
  }

  Future<void> _importBackup() async {
    final controller = TextEditingController();
    final raw = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yedekten yükle'),
        content: TextField(
          controller: controller,
          minLines: 6,
          maxLines: 10,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'Yedek metnini buraya yapıştır',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Yükle')),
        ],
      ),
    );
    controller.dispose();
    if (raw == null || raw.trim().isEmpty) return;
    try {
      await widget.importData(raw);
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek yüklendi. Yönetimi tekrar açınca yeni liste görünür.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Yedek okunamadı: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      initialIndex: widget.initialTabIndex,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Yönetim Paneli'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Yazı'),
              Tab(text: 'Saha'),
              Tab(text: 'Galeri'),
              Tab(text: 'Kitap'),
            ],
          ),
          actions: [
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'backup') _copyBackup();
                if (value == 'import') _importBackup();
                if (value == 'reset') _reset();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'backup', child: Text('Yedek kopyala')),
                PopupMenuItem(value: 'import', child: Text('Yedekten yükle')),
                PopupMenuItem(value: 'reset', child: Text('Örnek içeriklere dön')),
              ],
            ),
          ],
        ),
        body: TabBarView(
          children: [
            AdminList(
              title: 'Makale / yazı ekle',
              buttonText: 'Yeni yazı ekle',
              type: ContentTypes.article,
              items: articles,
              onAdd: () => _openEditor(ContentTypes.article),
              onEdit: (item) => _openEditor(ContentTypes.article, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Saha notu ekle',
              buttonText: 'Yeni saha notu ekle',
              type: ContentTypes.field,
              items: fieldNotes,
              onAdd: () => _openEditor(ContentTypes.field),
              onEdit: (item) => _openEditor(ContentTypes.field, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Galeri kaydı ekle',
              buttonText: 'Yeni galeri kaydı ekle',
              type: ContentTypes.gallery,
              items: galleryItems,
              onAdd: () => _openEditor(ContentTypes.gallery),
              onEdit: (item) => _openEditor(ContentTypes.gallery, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Kitap bölümü ekle',
              buttonText: 'Yeni bölüm ekle',
              type: ContentTypes.book,
              items: bookChapters,
              onAdd: () => _openEditor(ContentTypes.book),
              onEdit: (item) => _openEditor(ContentTypes.book, item: item),
              onDelete: _delete,
            ),
          ],
        ),
      ),
    );
  }
}

class AdminList extends StatelessWidget {
  final String title;
  final String buttonText;
  final String type;
  final List<AppContent> items;
  final VoidCallback onAdd;
  final void Function(AppContent item) onEdit;
  final void Function(AppContent item) onDelete;

  const AdminList({
    super.key,
    required this.title,
    required this.buttonText,
    required this.type,
    required this.items,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(_helpText(type)),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: Text(buttonText)),
        const SizedBox(height: 16),
        for (final item in items)
          Card(
            elevation: 0,
            child: ListTile(
              leading: CircleAvatar(child: Icon(item.icon)),
              title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(item.summary),
              onTap: () => onEdit(item),
              trailing: Wrap(
                children: [
                  IconButton(onPressed: () => onEdit(item), icon: const Icon(Icons.edit_outlined)),
                  IconButton(onPressed: () => onDelete(item), icon: const Icon(Icons.delete_outline)),
                ],
              ),
            ),
          ),
      ],
    );
  }

  String _helpText(String type) {
    if (type == ContentTypes.gallery) {
      return 'Telefondan fotoğraf seçebilir veya gerçek/telifsiz görselin doğrudan URL bağlantısını ekleyebilirsin. Kaynak bilgisini de yaz.';
    }
    if (type == ContentTypes.book) {
      return 'Kitap bölümünü ekle. Satır arasına görsel koymak için metinde [GÖRSEL1], [GÖRSEL2] gibi işaret kullan; aşağıdan aynı numaradaki görselleri seç.';
    }
    return 'Başlık, kategori, kısa açıklama ve uzun metin gir. Kayıt telefonda saklanır.';
  }
}

class ContentEditor extends StatefulWidget {
  final String type;
  final AppContent? item;

  const ContentEditor({super.key, required this.type, this.item});

  @override
  State<ContentEditor> createState() => _ContentEditorState();
}

class _ContentEditorState extends State<ContentEditor> {
  late final TextEditingController titleController;
  late final TextEditingController categoryController;
  late final TextEditingController summaryController;
  late final TextEditingController bodyController;
  late final TextEditingController imageUrlController;
  late final TextEditingController sourceController;
  String localImagePath = '';
  List<String> inlineImagePaths = List.filled(maxInlineBookImages, '');
  bool pickingImage = false;

  static const int maxInlineBookImages = 10;

  bool get isGallery => widget.type == ContentTypes.gallery;
  bool get isBook => widget.type == ContentTypes.book;

  @override
  void initState() {
    super.initState();
    final item = widget.item;
    titleController = TextEditingController(text: item?.title ?? '');
    categoryController = TextEditingController(text: item?.category ?? (isGallery ? 'Galeri' : (isBook ? '1. Bölüm' : '')));
    summaryController = TextEditingController(text: item?.summary ?? '');
    bodyController = TextEditingController(text: item?.body ?? '');
    imageUrlController = TextEditingController(text: item?.imageUrl ?? '');
    sourceController = TextEditingController(text: item?.source ?? '');
    localImagePath = item?.imagePath ?? '';
    final existingInline = item?.inlineImagePaths ?? const <String>[];
    inlineImagePaths = List.generate(maxInlineBookImages, (index) => index < existingInline.length ? existingInline[index] : '');
  }

  @override
  void dispose() {
    titleController.dispose();
    categoryController.dispose();
    summaryController.dispose();
    bodyController.dispose();
    imageUrlController.dispose();
    sourceController.dispose();
    super.dispose();
  }

  void _save() {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Başlık boş olamaz.')));
      return;
    }
    final nowId = DateTime.now().microsecondsSinceEpoch.toString();
    Navigator.pop(
      context,
      AppContent(
        id: widget.item?.id ?? nowId,
        type: widget.type,
        title: title,
        category: categoryController.text.trim().isEmpty ? (isGallery ? 'Galeri' : (isBook ? 'Bölüm' : 'Genel')) : categoryController.text.trim(),
        summary: isBook ? '' : summaryController.text.trim(),
        body: bodyController.text.trim(),
        imageUrl: imageUrlController.text.trim(),
        imagePath: localImagePath.trim(),
        source: sourceController.text.trim(),
        inlineImagePaths: List<String>.from(inlineImagePaths),
      ),
    );
  }

  Future<void> _pickFromPhoneGallery({int? inlineIndex}) async {
    if ((!isGallery && !isBook) || pickingImage) return;
    setState(() => pickingImage = true);
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final galleryDir = Directory('${dir.path}/altay_gallery_images');
      if (!await galleryDir.exists()) {
        await galleryDir.create(recursive: true);
      }
      final extension = picked.path.split('.').last.toLowerCase();
      final safeExtension = ['jpg', 'jpeg', 'png', 'webp'].contains(extension) ? extension : 'jpg';
      final target = File('${galleryDir.path}/galeri_${DateTime.now().millisecondsSinceEpoch}.$safeExtension');
      final saved = await File(picked.path).copy(target.path);
      if (!mounted) return;
      setState(() {
        if (inlineIndex == null) {
          localImagePath = saved.path;
        } else {
          inlineImagePaths[inlineIndex] = saved.path;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fotoğraf seçilemedi: $e')));
    } finally {
      if (mounted) setState(() => pickingImage = false);
    }
  }

  void _clearLocalImage() {
    setState(() => localImagePath = '');
  }

  void _clearInlineImage(int index) {
    setState(() => inlineImagePaths[index] = '');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 6,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(widget.item == null ? 'Yeni kayıt' : 'Kaydı düzenle', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _field(titleController, isBook ? 'Bölüm başlığı' : 'Başlık', maxLines: isBook ? 10 : 3),
            const SizedBox(height: 10),
            _field(categoryController, isGallery ? 'Kategori / yer' : (isBook ? 'Bölüm etiketi' : 'Kategori')),
            if (!isBook) ...[
              const SizedBox(height: 10),
              _field(summaryController, 'Kısa açıklama', maxLines: 2),
            ],
            const SizedBox(height: 10),
            _field(bodyController, isGallery ? 'Not / açıklama' : (isBook ? 'Bölüm metni' : 'Uzun metin'), maxLines: isBook ? 14 : 10),
            if (isBook) ...[
              const SizedBox(height: 8),
              const Text(
                'Satır arasına görsel koymak için metinde görselin geleceği yere tek satır olarak [GÖRSEL1], [GÖRSEL2] gibi yaz. Aşağıdan aynı numaradaki görseli seç.',
              ),
            ],
            if (isGallery || isBook) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: pickingImage ? null : () => _pickFromPhoneGallery(),
                      icon: pickingImage
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.photo_library_outlined),
                      label: Text(isBook ? 'Bölüm kapak görseli seç' : 'Telefondan fotoğraf seç'),
                    ),
                  ),
                  if (localImagePath.trim().isNotEmpty) ...[
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: 'Seçilen fotoğrafı kaldır',
                      onPressed: _clearLocalImage,
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ],
              ),
              if (localImagePath.trim().isNotEmpty) ...[
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.file(
                    File(localImagePath),
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => const Text('Seçilen fotoğraf gösterilemedi.'),
                  ),
                ),
              ],
              const SizedBox(height: 10),
              _field(imageUrlController, 'İstersen görsel URL bağlantısı'),
              const SizedBox(height: 10),
              _field(sourceController, 'Kaynak / lisans bilgisi'),
              if (isBook) ...[
                const SizedBox(height: 16),
                Text('Satır arası görseller', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Örnek: Bölüm metninde [GÖRSEL1] yazan satırın yerine Görsel 1 gelir.'),
                const SizedBox(height: 10),
                for (int i = 0; i < maxInlineBookImages; i++)
                  Card(
                    elevation: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(child: Text('Görsel ${i + 1}  •  metinde [GÖRSEL${i + 1}] yaz', style: const TextStyle(fontWeight: FontWeight.bold))),
                              if (inlineImagePaths[i].trim().isNotEmpty)
                                IconButton(
                                  tooltip: 'Bu görseli kaldır',
                                  onPressed: () => _clearInlineImage(i),
                                  icon: const Icon(Icons.close),
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: pickingImage ? null : () => _pickFromPhoneGallery(inlineIndex: i),
                                  icon: const Icon(Icons.add_photo_alternate_outlined),
                                  label: Text(inlineImagePaths[i].trim().isEmpty ? 'Görsel ${i + 1} seç' : 'Görsel ${i + 1} değiştir'),
                                ),
                              ),
                            ],
                          ),
                          if (inlineImagePaths[i].trim().isNotEmpty) ...[
                            const SizedBox(height: 8),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.file(
                                File(inlineImagePaths[i]),
                                height: 120,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) => const Text('Bu görsel gösterilemedi.'),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
              ],
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Kaydet')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    );
  }
}

class InfoPanel extends StatelessWidget {
  final String title;
  final String text;

  const InfoPanel({super.key, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(text, style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}

class EmptyPanel extends StatelessWidget {
  final String text;

  const EmptyPanel({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(child: Text(text, textAlign: TextAlign.center)),
    );
  }
}

class ContentTypes {
  static const article = 'article';
  static const field = 'field';
  static const gallery = 'gallery';
  static const book = 'book';
}

class AppContent {
  final String id;
  final String type;
  final String title;
  final String category;
  final String summary;
  final String body;
  final String imageUrl;
  final String imagePath;
  final String source;
  final List<String> inlineImagePaths;

  const AppContent({
    required this.id,
    required this.type,
    required this.title,
    required this.category,
    required this.summary,
    required this.body,
    this.imageUrl = '',
    this.imagePath = '',
    this.source = '',
    this.inlineImagePaths = const [],
  });

  bool get hasImage => imagePath.trim().isNotEmpty || imageUrl.trim().isNotEmpty;
  List<String> get cleanInlineImagePaths => inlineImagePaths.where((value) => value.trim().isNotEmpty).toList();
  int get imageCount => (hasImage ? 1 : 0) + cleanInlineImagePaths.length;

  IconData get icon {
    if (type == ContentTypes.field) return Icons.location_on_outlined;
    if (type == ContentTypes.gallery) return Icons.photo_library_outlined;
    if (type == ContentTypes.book) return Icons.menu_book_outlined;
    final lower = category.toLowerCase();
    if (lower.contains('arkeoloji')) return Icons.account_balance_outlined;
    if (lower.contains('gökyüzü') || lower.contains('ufo')) return Icons.public;
    if (lower.contains('mitoloji')) return Icons.auto_awesome_outlined;
    return Icons.article_outlined;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'category': category,
        'summary': summary,
        'body': body,
        'imageUrl': imageUrl,
        'imagePath': imagePath,
        'source': source,
        'inlineImagePaths': inlineImagePaths,
      };

  factory AppContent.fromJson(Map<String, dynamic> json, String fallbackType) {
    return AppContent(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      type: json['type']?.toString() ?? fallbackType,
      title: json['title']?.toString() ?? 'Başlıksız',
      category: json['category']?.toString() ?? 'Genel',
      summary: json['summary']?.toString() ?? '',
      body: json['body']?.toString() ?? '',
      imageUrl: json['imageUrl']?.toString() ?? '',
      imagePath: json['imagePath']?.toString() ?? '',
      source: json['source']?.toString() ?? '',
      inlineImagePaths: json['inlineImagePaths'] is List
          ? (json['inlineImagePaths'] as List).map((value) => value.toString()).toList()
          : const [],
    );
  }
}

class LocalStore {
  static const articlesKey = 'v2_articles_json';
  static const fieldNotesKey = 'v2_field_notes_json';
  static const galleryKey = 'v2_gallery_json';
  static const bookKey = 'v2_book_json';

  static Future<List<AppContent>> loadList(String key, List<AppContent> defaults) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.trim().isEmpty) return [...defaults];
    try {
      final decoded = jsonDecode(raw);
      final type = defaults.isEmpty ? ContentTypes.article : defaults.first.type;
      final list = decodeList(decoded, type);
      return list.isEmpty ? [...defaults] : list;
    } catch (_) {
      return [...defaults];
    }
  }

  static Future<void> saveList(String key, List<AppContent> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(items.map((item) => item.toJson()).toList()));
  }

  static List<AppContent> decodeList(dynamic decoded, String fallbackType) {
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((entry) => AppContent.fromJson(Map<String, dynamic>.from(entry), fallbackType))
        .toList();
  }
}

const defaultArticles = [
  AppContent(
    id: 'article_1',
    type: ContentTypes.article,
    title: 'Mağaralar, Hafıza ve Köken Anlatıları',
    category: 'Mitoloji',
    summary: 'Mağara mekânının eski anlatılardaki simgesel rolü.',
    body:
        'Mağara, birçok kadim anlatıda yalnızca saklanma yeri değildir. Karanlık, geçiş, yeniden doğuş, bilinmeyenle yüzleşme ve köken hafızası gibi anlamlar taşır. Kahramanın mağarada karşılaştığı varlık, çoğu zaman sıradan bir figür değil, soyun veya bilginin gizli tarafını temsil eden eşik varlığıdır.',
  ),
  AppContent(
    id: 'article_2',
    type: ContentTypes.article,
    title: 'Şahmeran: Yılan Bedenli Bilgelik Figürü',
    category: 'Anadolu Efsaneleri',
    summary: 'Şahmeran anlatısında bilgelik, sır ve beden sembolizmi.',
    body:
        'Şahmeran anlatısı; yarı insan yarı yılan formuyla hem korkuyu hem bilgeliği aynı bedende toplar. Bu ikili yapı, eski toplumların doğa, ölüm, şifa ve gizli bilgiyle kurduğu ilişkiyi okumak için güçlü bir kapı açar.',
  ),
  AppContent(
    id: 'article_3',
    type: ContentTypes.article,
    title: 'Draco Takımyıldızı ve Antik Gökyüzü Haritaları',
    category: 'Gökyüzü',
    summary: 'Ejderha/yılan sembolünün göksel karşılıkları.',
    body:
        'Draco takımyıldızı, gökyüzünde yılanımsı uzun formuyla tarih boyunca dikkat çekmiştir. Antik toplumların gökyüzünü yalnızca takvim için değil, mitolojik hafıza için de kullandığı düşünülür.',
  ),
  AppContent(
    id: 'article_4',
    type: ContentTypes.article,
    title: 'Göbekli Tepe ve Sembol Hafızası',
    category: 'Arkeoloji',
    summary: 'Taş sütunlar, hayvan kabartmaları ve ritüel alan fikri.',
    body:
        'Göbekli Tepe, sembollerin taş üzerine işlendiği güçlü bir hafıza alanı olarak görülebilir. Hayvan kabartmaları, ritüel düzen ve anıtsal mimari; insanlığın erken dönem inanç dünyasına dair büyük sorular doğurur.',
  ),
  AppContent(
    id: 'article_5',
    type: ContentTypes.article,
    title: 'Derinkuyu: Yeraltı, Koridor ve Saklı Yaşam',
    category: 'Yeraltı Şehirleri',
    summary: 'Kapalı mekân, geçitler ve savunma mimarisi.',
    body:
        'Derinkuyu gibi yeraltı şehirleri; dar koridorları, taş kapıları ve katmanlı yapısıyla yalnızca mimari değil, psikolojik bir atmosfer de oluşturur. Yeraltına iniş, eski anlatılardaki bilinmeyene geçiş temasını hatırlatır.',
  ),
];

const defaultFieldNotes = [
  AppContent(
    id: 'field_1',
    type: ContentTypes.field,
    title: 'Hattuşa Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Büyük Mabed, Yeşil Taş ve Hitit başkentinin izleri.',
    body:
        'Hattuşa gezisi, taş mimariyi ve kutsal alan düzenini yerinde görmek için güçlü bir saha noktasıdır. Büyük Mabed ve Yeşil Taş, araştırma arşivinde ayrıca incelenebilir.',
  ),
  AppContent(
    id: 'field_2',
    type: ContentTypes.field,
    title: 'Yazılıkaya Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Tanrı kabartmaları, geçit ve kaya tapınağı atmosferi.',
    body:
        'Yazılıkaya, açık hava kaya tapınağı atmosferiyle mitolojik figürleri taş üzerine taşıyan özel bir alandır. Kabartmalar, geçit ve kaya yüzeyi bir arada okunmalıdır.',
  ),
  AppContent(
    id: 'field_3',
    type: ContentTypes.field,
    title: 'Efes Saha Notu',
    category: 'İzmir / Selçuk',
    summary: 'Celsus, Yamaç Evleri ve antik şehir dokusu.',
    body:
        'Efes, Roma dönemi mimari hafızasını güçlü şekilde taşır. Yamaç Evleri, Celsus ve Herakles Kapısı gibi noktalar görsel arşiv için değerlidir.',
  ),
  AppContent(
    id: 'field_4',
    type: ContentTypes.field,
    title: 'Myra Saha Notu',
    category: 'Antalya / Demre',
    summary: 'Kaya mezarları, Medusa imgesi ve Likya dokusu.',
    body:
        'Myra, kaya mezarları ve antik tiyatrosuyla Likya dünyasının güçlü izlerini taşır. Medusa ve koruyucu sembol fikri burada ayrıca araştırılabilir.',
  ),
];


const defaultBookChapters = [
  AppContent(
    id: 'book_1',
    type: ContentTypes.book,
    title: 'Giriş: Taşların Sessiz Dili',
    category: 'Giriş',
    summary: 'Araştırmanın çerçevesi ve kitabın amacı.',
    body:
        'Bu kitap, antik medeniyetler içinde yılan, ejderha ve reptilyan benzeri sembollerin izini süren bağımsız bir araştırma arşivi olarak düşünülmüştür. Amaç kesin hüküm vermek değil; mekânları, sembolleri, efsaneleri ve saha gözlemlerini yan yana getirerek okura düşünme alanı açmaktır.',
  ),
  AppContent(
    id: 'book_2',
    type: ContentTypes.book,
    title: 'Şahmeran ve Bilgeliğin Gizli Bedeni',
    category: 'Bölüm 1',
    summary: 'Anadolu anlatılarında yılan bedenli bilgelik figürü.',
    body:
        'Şahmeran figürü, yalnızca halk anlatısı olarak değil; aynı zamanda bilgi, şifa, sır ve bedensel dönüşüm sembolizmi olarak da okunabilir. Yarı insan yarı yılan formu, insanla doğa arasındaki eşiği beden üzerinde görünür kılar.',
  ),
  AppContent(
    id: 'book_3',
    type: ContentTypes.book,
    title: 'Göbekli Tepe, Sembol Hafızası ve Taşlardaki İzler',
    category: 'Bölüm 2',
    summary: 'Kabartmalar, ritüel alanlar ve kadim hafıza.',
    body:
        'Göbekli Tepe gibi merkezler, yalnızca arkeolojik alan değil; aynı zamanda sembol hafızasının taşa işlendiği anıtsal anlatı alanlarıdır. Yılan, kuş ve insan formları; kadim düşünce dünyasının çok katmanlı yapısını yansıtır.',
  ),
];

const defaultGalleryItems = [
  AppContent(
    id: 'gallery_1',
    type: ContentTypes.gallery,
    title: 'Göbekli Tepe',
    category: 'Galeri',
    summary: 'Gerçek/telifsiz görsel bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_2',
    type: ContentTypes.gallery,
    title: 'Hattuşa',
    category: 'Galeri',
    summary: 'Gerçek saha fotoğrafı için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_3',
    type: ContentTypes.gallery,
    title: 'Yazılıkaya',
    category: 'Galeri',
    summary: 'Açık lisanslı kaynak görsel için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_4',
    type: ContentTypes.gallery,
    title: 'Derinkuyu',
    category: 'Galeri',
    summary: 'Gerçek fotoğraf bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
];
