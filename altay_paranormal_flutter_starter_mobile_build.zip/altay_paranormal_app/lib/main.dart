import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';

const appVersionLabel = 'SÜRÜM 46 • GÖRSELLERİ GERİ GETİRİR';
const MethodChannel docxPickerChannel = MethodChannel('altay_paranormal/docx_picker');

void main() {
  runApp(const AltayParanormalApp());
}


String cleanBookChapterTitle(String value) {
  final clean = value.trim().replaceAll(RegExp(r'\s+'), ' ');
  if (clean.length <= 80) return clean;

  final markers = <String>[
    ' Modern dünyada',
    ' Modern bilim',
    ' David Icke',
    ' Icke’nin',
    " Icke'nin",
    ' Icke’ye',
    " Icke'ye",
    ' Ona göre',
    ' Bu görüş',
    ' Bu düşünce',
    ' Bu yaklaşım',
    ' Gerçeklik',
    ' İnsanlar',
    ' Antik mitolojiler',
  ];

  var splitIndex = -1;
  for (final marker in markers) {
    final index = clean.indexOf(marker);
    if (index > 25 && (splitIndex == -1 || index < splitIndex)) {
      splitIndex = index;
    }
  }

  if (splitIndex > 0) {
    return clean.substring(0, splitIndex).trim();
  }

  final letters = clean.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
  final upperLetters = letters.replaceAll(RegExp(r'[^A-ZÇĞİÖŞÜ]'), '');
  final mostlyUpper = letters.isNotEmpty && upperLetters.length / letters.length > 0.72;

  // Tamamen/çoğunlukla büyük harfli bölüm başlıklarını kesme.
  // Örn: DAVID ICKE VE REPTİLYAN TEORİSİ: HOLOGRAFİK EVREN...
  if (mostlyUpper) return clean;

  final words = clean.split(' ');
  if (words.length > 9) {
    for (var i = 5; i < words.length; i++) {
      final word = words[i];
      final hasLowercase = RegExp(r'[a-zçğıöşü]').hasMatch(word);
      if (hasLowercase) {
        return words.take(i).join(' ').trim();
      }
    }
    return words.take(9).join(' ').trim();
  }

  return clean;
}

String bookChapterTitleOverflow(String value) {
  final clean = value.trim().replaceAll(RegExp(r'\s+'), ' ');
  final title = cleanBookChapterTitle(value);
  if (title.isEmpty || title == clean || clean.length <= title.length) return '';
  return clean.substring(title.length).trim();
}


String _normalizeBookLabelText(String value) {
  return value
      .toLowerCase()
      .replaceAll('ı', 'i')
      .replaceAll('İ', 'i')
      .replaceAll('ö', 'o')
      .replaceAll('ü', 'u')
      .replaceAll('ş', 's')
      .replaceAll('ğ', 'g')
      .replaceAll('ç', 'c')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

bool isBookFrontMatter(String title, String category) {
  final value = _normalizeBookLabelText('$title $category');
  return value.contains('onsoz') ||
      value.contains('giris') ||
      value.contains('sunus') ||
      value.contains('baslarken') ||
      value.contains('okura not');
}

String bookChapterLabel(String title, String category, int index) {
  if (isBookFrontMatter(title, category)) {
    final clean = cleanBookChapterTitle(title).trim();
    final normalized = _normalizeBookLabelText(clean);
    if (normalized.contains('onsoz')) return 'Önsöz';
    if (normalized.contains('sunus')) return 'Sunuş';
    if (normalized.contains('giris')) return 'Giriş';
    if (normalized.contains('okura not')) return 'Okura Not';
    if (clean.isNotEmpty && clean.length <= 24) return clean;
    return 'Önsöz';
  }
  return '${index + 1}. Bölüm';
}

String bookExportChapterHeader(String title, String category, int index) {
  final label = bookChapterLabel(title, category, index);
  if (isBookFrontMatter(title, category)) return label.toUpperCase();
  return '${index + 1}. BÖLÜM';
}

int bookChapterNumberInList(List<AppContent> items, int index) {
  var number = 0;
  final safeIndex = index < items.length ? index : items.length - 1;
  for (var i = 0; i <= safeIndex; i++) {
    final item = items[i];
    if (!isBookFrontMatter(item.title, item.category)) {
      number++;
    }
  }
  return number < 1 ? 1 : number;
}

String bookChapterLabelFromList(List<AppContent> items, int index) {
  if (items.isEmpty || index < 0 || index >= items.length) return '';
  final item = items[index];
  if (isBookFrontMatter(item.title, item.category)) {
    return bookChapterLabel(item.title, item.category, index);
  }
  return '${bookChapterNumberInList(items, index)}. Bölüm';
}

String bookExportChapterHeaderFromList(List<AppContent> items, int index) {
  if (items.isEmpty || index < 0 || index >= items.length) return '';
  final item = items[index];
  if (isBookFrontMatter(item.title, item.category)) {
    return bookChapterLabel(item.title, item.category, index).toUpperCase();
  }
  return '${bookChapterNumberInList(items, index)}. BÖLÜM';
}

bool _sameBookHeading(String a, String b) {
  return _normalizeBookLabelText(a) == _normalizeBookLabelText(b);
}

class AltayParanormalApp extends StatelessWidget {
  const AltayParanormalApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8A5A22);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gizem ve Paranormal Arşivim',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F1E6),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;
  bool loading = true;
  List<AppContent> articles = [];
  List<AppContent> fieldNotes = [];
  List<AppContent> galleryItems = [];
  List<AppContent> bookChapters = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedArticles = await LocalStore.loadList(LocalStore.articlesKey, defaultArticles);
    final loadedFieldNotes = await LocalStore.loadList(LocalStore.fieldNotesKey, defaultFieldNotes);
    final loadedGallery = await LocalStore.loadList(LocalStore.galleryKey, defaultGalleryItems);
    final loadedBook = await LocalStore.loadList(LocalStore.bookKey, defaultBookChapters);
    if (!mounted) return;
    setState(() {
      articles = loadedArticles;
      fieldNotes = loadedFieldNotes;
      galleryItems = loadedGallery;
      bookChapters = loadedBook;
      loading = false;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _checkSharedWordFile();
    });
  }

  Future<void> _checkSharedWordFile() async {
    try {
      final bytes = await docxPickerChannel.invokeMethod<Uint8List>('getSharedDocx');
      if (bytes == null || bytes.isEmpty) return;

      final chapters = await BookImporter.fromDocx(bytes: bytes);
      if (!mounted) return;

      if (chapters.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Paylaşılan Word dosyasında bölüm bulunamadı.')),
        );
        return;
      }

      setState(() => selectedIndex = 3);

      final replace = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('${chapters.length} bölüm bulundu'),
          content: const Text('Paylaşılan Word dosyasını kitap bölümüne aktaralım mı? Mevcut kitabı silip bunu kullanabilir veya üstüne ekleyebilirsin.'),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(null), child: const Text('İptal')),
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Üstüne ekle')),
            FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Eskisini sil ve yükle')),
          ],
        ),
      );

      if (replace == null) return;
      if (replace) {
        await _replaceBookChapters(chapters);
      } else {
        await _appendBookChapters(chapters);
      }

      if (!mounted) return;
      setState(() => selectedIndex = 3);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Paylaşılan Word dosyası kitap bölümüne aktarıldı.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Paylaşılan Word dosyası alınamadı: $e')),
      );
    }
  }

  Future<void> _saveAll() async {
    await LocalStore.saveList(LocalStore.articlesKey, articles);
    await LocalStore.saveList(LocalStore.fieldNotesKey, fieldNotes);
    await LocalStore.saveList(LocalStore.galleryKey, galleryItems);
    await LocalStore.saveList(LocalStore.bookKey, bookChapters);
  }

  List<AppContent> _listForType(String type) {
    switch (type) {
      case ContentTypes.article:
        return articles;
      case ContentTypes.field:
        return fieldNotes;
      case ContentTypes.gallery:
        return galleryItems;
      case ContentTypes.book:
        return bookChapters;
      default:
        return articles;
    }
  }

  Future<void> _replaceList(String type, List<AppContent> list) async {
    setState(() {
      if (type == ContentTypes.article) articles = list;
      if (type == ContentTypes.field) fieldNotes = list;
      if (type == ContentTypes.gallery) galleryItems = list;
      if (type == ContentTypes.book) bookChapters = list;
    });
    await _saveAll();
  }

  Future<void> _addItem(AppContent item) async {
    final list = [..._listForType(item.type), item];
    await _replaceList(item.type, list);
  }

  Future<void> _updateItem(AppContent item) async {
    final list = _listForType(item.type)
        .map((existing) => existing.id == item.id ? item : existing)
        .toList();
    await _replaceList(item.type, list);
  }


  Future<void> _replaceBookChapters(List<AppContent> chapters) async {
    await _replaceList(ContentTypes.book, chapters);
  }

  Future<void> _appendBookChapters(List<AppContent> chapters) async {
    await _replaceList(ContentTypes.book, [...bookChapters, ...chapters]);
  }

  Future<void> _deleteItem(AppContent item) async {
    final list = _listForType(item.type).where((existing) => existing.id != item.id).toList();
    await _replaceList(item.type, list);
  }

  Future<void> _resetData() async {
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
      bookChapters = [...defaultBookChapters];
    });
    await _saveAll();
  }

  String _exportData() {
    return const JsonEncoder.withIndent('  ').convert({
      'articles': articles.map((item) => item.toJson()).toList(),
      'fieldNotes': fieldNotes.map((item) => item.toJson()).toList(),
      'gallery': galleryItems.map((item) => item.toJson()).toList(),
      'book': bookChapters.map((item) => item.toJson()).toList(),
    });
  }

  Future<void> _importData(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Yedek metni geçerli değil.');
    }
    final newArticles = LocalStore.decodeList(decoded['articles'], ContentTypes.article);
    final newFieldNotes = LocalStore.decodeList(decoded['fieldNotes'], ContentTypes.field);
    final newGallery = LocalStore.decodeList(decoded['gallery'], ContentTypes.gallery);
    final newBook = LocalStore.decodeList(decoded['book'], ContentTypes.book);
    setState(() {
      articles = newArticles.isEmpty ? articles : newArticles;
      fieldNotes = newFieldNotes.isEmpty ? fieldNotes : newFieldNotes;
      galleryItems = newGallery.isEmpty ? galleryItems : newGallery;
      bookChapters = newBook.isEmpty ? bookChapters : newBook;
    });
    await _saveAll();
  }

  void _openAdmin({int initialTabIndex = 0}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AdminPage(
          initialTabIndex: initialTabIndex,
          articles: articles,
          fieldNotes: fieldNotes,
          galleryItems: galleryItems,
          bookChapters: bookChapters,
          onAdd: _addItem,
          onUpdate: _updateItem,
          onDelete: _deleteItem,
          onReset: _resetData,
          exportData: _exportData,
          importData: _importData,
        ),
      ),
    );
  }


  Future<void> _openQuickEditor(AppContent item) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: item.type, item: item),
    );
    if (result == null) return;
    await _updateItem(result);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Değişiklik kaydedildi.')));
  }

  void _openAbout() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutPage()));
  }

  void _openContact() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ContactPage()));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final pages = [
      HomePage(
        articlesCount: articles.length,
        fieldCount: fieldNotes.length,
        galleryCount: galleryItems.length,
        onOpenAdmin: () => _openAdmin(),
      ),
      ArticlesPage(items: articles, onEdit: _openQuickEditor, onDelete: _deleteItem),
      FieldNotesPage(
        fieldItems: fieldNotes,
        galleryItems: galleryItems,
        onOpenFieldAdmin: () => _openAdmin(initialTabIndex: 1),
        onOpenGalleryAdmin: () => _openAdmin(initialTabIndex: 2),
        onEdit: _openQuickEditor,
        onDelete: _deleteItem,
      ),
      BookPage(items: bookChapters, onOpenBookAdmin: () => _openAdmin(initialTabIndex: 3), onEdit: _openQuickEditor, onDelete: _deleteItem, onReplaceBookChapters: _replaceBookChapters, onAppendBookChapters: _appendBookChapters),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gizem ve Paranormal Arşivim'),
        actions: [
          IconButton(
            tooltip: 'Yönetim',
            onPressed: () => _openAdmin(),
            icon: const Icon(Icons.admin_panel_settings_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'about') _openAbout();
              if (value == 'contact') _openContact();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'about', child: Text('Hakkımda')),
              PopupMenuItem(value: 'contact', child: Text('İletişim')),
            ],
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: pages[selectedIndex],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana'),
          NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Yazılar'),
          NavigationDestination(icon: Icon(Icons.travel_explore_outlined), selectedIcon: Icon(Icons.travel_explore), label: 'Saha'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Kitap'),
        ],
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int articlesCount;
  final int fieldCount;
  final int galleryCount;
  final VoidCallback onOpenAdmin;

  const HomePage({
    super.key,
    required this.articlesCount,
    required this.fieldCount,
    required this.galleryCount,
    required this.onOpenAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const HeroHeader(),
        const SizedBox(height: 12),
        const VersionBanner(),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: onOpenAdmin,
          icon: const Icon(Icons.edit_note),
          label: const Text('Yönetim paneli: yazı, saha notu ve galeri ekle'),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: CounterCard(title: 'Yazı', value: articlesCount.toString(), icon: Icons.article_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Saha', value: fieldCount.toString(), icon: Icons.travel_explore_outlined)),
            const SizedBox(width: 8),
            Expanded(child: CounterCard(title: 'Galeri', value: galleryCount.toString(), icon: Icons.photo_library_outlined)),
          ],
        ),
        const SizedBox(height: 18),
        Text('Öne Çıkan Dosyalar', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: const [
            FeatureCard(icon: Icons.public, title: 'UFO Dosyaları', subtitle: 'Gözlem, rapor ve olay notları'),
            FeatureCard(icon: Icons.account_balance, title: 'Antik Medeniyetler', subtitle: 'Tapınaklar, semboller, mitler'),
            FeatureCard(icon: Icons.terrain, title: 'Saha Geçmişi', subtitle: 'Hattuşa, Yazılıkaya, Efes, Myra'),
            FeatureCard(icon: Icons.auto_stories, title: 'Kitap Projesi', subtitle: 'Antik Medeniyetlerde Reptilyanların İzinde'),
          ],
        ),
        const SizedBox(height: 18),
        const InfoPanel(
          title: 'Bu sürümde ne var?',
          text:
              'Bu 5. sürümde yazı ve galeri detayları artık yarım açılan pencere yerine tam sayfa açılır. Makale, saha notu ve galeri görseli ekleyebilir, düzenleyebilir ve silebilirsin. Kayıtlar telefonda saklanır. Yedek almayı unutma.',
        ),
      ],
    );
  }
}


class VersionBanner extends StatelessWidget {
  const VersionBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: scheme.tertiaryContainer,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        children: [
          Icon(Icons.verified_outlined, color: scheme.onTertiaryContainer),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '$appVersionLabel aktif. Yazılar artık tam sayfa açılır; galeri ekleme butonu görünür.',
              style: TextStyle(
                color: scheme.onTertiaryContainer,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CounterCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const CounterCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C))),
          ],
        ),
      ),
    );
  }
}

class HeroHeader extends StatelessWidget {
  const HeroHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [scheme.primaryContainer, scheme.secondaryContainer],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.explore, size: 44, color: scheme.onPrimaryContainer),
          const SizedBox(height: 18),
          Text(
            'Gizem, UFO ve Paranormal Araştırman\nAltay Aytın',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            'Anadolu sahalarından antik sembollere, mitolojik anlatılardan modern gizem dosyalarına uzanan bağımsız araştırma arşivi.',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const FeatureCard({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width > 700 ? 260 : double.infinity,
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(child: Icon(icon)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(subtitle),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ArticlesPage extends StatefulWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const ArticlesPage({super.key, required this.items, required this.onEdit, this.onDelete});

  @override
  State<ArticlesPage> createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  final controller = TextEditingController();
  String query = '';

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.items.where((item) {
      final q = query.toLowerCase().trim();
      if (q.isEmpty) return true;
      return item.title.toLowerCase().contains(q) ||
          item.summary.toLowerCase().contains(q) ||
          item.category.toLowerCase().contains(q) ||
          item.body.toLowerCase().contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      children: [
        Text('Yazılar', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(
          controller: controller,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            labelText: 'Yazılarda ara',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) => setState(() => query = value),
        ),
        const SizedBox(height: 12),
        for (final article in filtered) ContentTile(item: article, onEdit: widget.onEdit, onDelete: widget.onDelete),
        if (filtered.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('Bu aramada sonuç bulunamadı.')),
          ),
      ],
    );
  }
}

class ContentTile extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const ContentTile({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kayıt silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    final subtitle = [
      if (item.category.trim().isNotEmpty) item.category.trim(),
      if (item.summary.trim().isNotEmpty) item.summary.trim(),
    ].join(' • ');

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ContentDetailPage(item: item, onEdit: onEdit, onDelete: onDelete)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(child: Icon(item.icon)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, height: 1.25),
                        ),
                        if (subtitle.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            subtitle,
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.35),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.chevron_right),
                ],
              ),
              if (onEdit != null || onDelete != null) ...[
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (onEdit != null)
                      TextButton.icon(
                        onPressed: () => onEdit!(item),
                        icon: const Icon(Icons.edit_outlined),
                        label: const Text('Düzenle'),
                      ),
                    if (onDelete != null) ...[
                      const SizedBox(width: 8),
                      TextButton.icon(
                        onPressed: () => _confirmDelete(context),
                        icon: const Icon(Icons.delete_outline),
                        label: const Text('Sil'),
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class ContentDetailPage extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const ContentDetailPage({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kayıt silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_shortTitle(item.title)),
        actions: [
          if (onEdit != null)
            IconButton(
              tooltip: 'Bu kaydı düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => onEdit!(item),
            ),
          if (onDelete != null)
            IconButton(
              tooltip: 'Bu kaydı sil',
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _confirmDelete(context),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            item.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (item.category.trim().isNotEmpty) Chip(label: Text(item.category)),
              if (item.summary.trim().isNotEmpty) Chip(label: Text(item.summary)),
            ],
          ),
          const SizedBox(height: 18),
          SelectableText(
            item.body.trim().isEmpty ? 'Bu kayıt için henüz uzun metin eklenmemiş.' : item.body,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.55),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  static String _shortTitle(String value) {
    final clean = value.trim();
    if (clean.length <= 24) return clean;
    return '${clean.substring(0, 24)}...';
  }
}

class FieldNotesPage extends StatelessWidget {
  final List<AppContent> fieldItems;
  final List<AppContent> galleryItems;
  final VoidCallback onOpenFieldAdmin;
  final VoidCallback onOpenGalleryAdmin;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const FieldNotesPage({
    super.key,
    required this.fieldItems,
    required this.galleryItems,
    required this.onOpenFieldAdmin,
    required this.onOpenGalleryAdmin,
    required this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      children: [
        Text(
          'Saha ve Galeri',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text('Saha notlarını ve gerçek/telifsiz görsellerini aynı bölümden yönet.'),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            FilledButton.icon(
              onPressed: onOpenFieldAdmin,
              icon: const Icon(Icons.edit_note_outlined),
              label: const Text('Saha notu ekle'),
            ),
            FilledButton.tonalIcon(
              onPressed: onOpenGalleryAdmin,
              icon: const Icon(Icons.add_photo_alternate_outlined),
              label: const Text('Görsel yükle'),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            const Icon(Icons.travel_explore_outlined),
            const SizedBox(width: 8),
            Text('Saha Notlarım', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 10),
        if (fieldItems.isEmpty)
          const EmptyPanel(text: 'Henüz saha notu yok. “Saha notu ekle” butonuyla ekleyebilirsin.')
        else
          for (final note in fieldItems) ContentTile(item: note, onEdit: onEdit, onDelete: onDelete),
        const SizedBox(height: 20),
        Row(
          children: [
            const Icon(Icons.photo_library_outlined),
            const SizedBox(width: 8),
            Text('Saha Görsellerim', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 8),
        const Text('Gerçek fotoğraf, açık lisanslı veya izinli görselleri burada tut.'),
        const SizedBox(height: 12),
        if (galleryItems.isEmpty)
          const EmptyPanel(text: 'Henüz görsel yok. “Görsel yükle” butonuyla ekleyebilirsin.')
        else
          GridView.builder(
            itemCount: galleryItems.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.74,
            ),
            itemBuilder: (context, index) => GalleryCard(item: galleryItems[index], onEdit: onEdit, onDelete: onDelete),
          ),
      ],
    );
  }
}

class GalleryPage extends StatelessWidget {
  final List<AppContent> items;
  final VoidCallback onOpenGalleryAdmin;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const GalleryPage({
    super.key,
    required this.items,
    required this.onOpenGalleryAdmin,
    required this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      children: [
        Text('Galeri', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Gerçek, telifsiz, kamu malı veya izinli görseller için ayrıldı. Görsel eklemek için aşağıdaki butona bas.'),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: onOpenGalleryAdmin,
          icon: const Icon(Icons.add_photo_alternate_outlined),
          label: const Text('Galeriye görsel ekle / düzenle'),
        ),
        const SizedBox(height: 14),
        GridView.builder(
          itemCount: items.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.74,
          ),
          itemBuilder: (context, index) => GalleryCard(item: items[index], onEdit: onEdit, onDelete: onDelete),
        ),
        if (items.isEmpty) const EmptyPanel(text: 'Henüz galeri kaydı yok. Yönetim panelinden ekleyebilirsin.'),
      ],
    );
  }
}

class GalleryCard extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const GalleryCard({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Galeri kaydı silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _openDetails(context),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: scheme.outlineVariant),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: GalleryImage(item: item, fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, height: 1.15),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    item.summary,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF5B452C), height: 1.2),
                  ),
                  const SizedBox(height: 1),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (onEdit != null)
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'Düzenle',
                          onPressed: () => onEdit!(item),
                          icon: const Icon(Icons.edit_outlined, size: 18),
                        ),
                      if (onDelete != null)
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'Sil',
                          onPressed: () => _confirmDelete(context),
                          icon: const Icon(Icons.delete_outline, size: 18),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openDetails(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GalleryDetailPage(item: item, onEdit: onEdit, onDelete: onDelete)),
    );
  }
}

class GalleryDetailPage extends StatelessWidget {
  final AppContent item;
  final void Function(AppContent item)? onEdit;
  final Future<void> Function(AppContent item)? onDelete;

  const GalleryDetailPage({super.key, required this.item, this.onEdit, this.onDelete});

  Future<void> _confirmDelete(BuildContext context) async {
    if (onDelete == null) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Galeri kaydı silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    await onDelete!(item);
    if (!context.mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_shortTitle(item.title)),
        actions: [
          if (onEdit != null)
            IconButton(
              tooltip: 'Galeri kaydını düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => onEdit!(item),
            ),
          if (onDelete != null)
            IconButton(
              tooltip: 'Galeri kaydını sil',
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _confirmDelete(context),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (item.hasImage)
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                constraints: const BoxConstraints(minHeight: 260),
                child: GalleryImage(item: item, fit: BoxFit.contain),
              ),
            )
          else
            const EmptyPanel(text: 'Bu galeri kaydında henüz fotoğraf yok.'),
          const SizedBox(height: 18),
          Text(
            item.title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          if (item.summary.trim().isNotEmpty)
            Text(item.summary, style: Theme.of(context).textTheme.bodyLarge),
          if (item.source.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            SelectableText('Kaynak: ${item.source}', style: Theme.of(context).textTheme.bodyMedium),
          ],
          if (item.body.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            SelectableText(item.body, style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.5)),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  static String _shortTitle(String value) {
    final clean = value.trim();
    if (clean.length <= 24) return clean;
    return '${clean.substring(0, 24)}...';
  }
}

class GalleryImage extends StatelessWidget {
  final AppContent item;
  final BoxFit fit;

  const GalleryImage({super.key, required this.item, required this.fit});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final localPath = item.imagePath.trim();
    if (localPath.isNotEmpty && !kIsWeb) {
      final file = File(localPath);
      if (file.existsSync()) {
        return Image.file(
          file,
          width: double.infinity,
          fit: fit,
          errorBuilder: (context, error, stackTrace) => Center(
            child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
          ),
        );
      }
    }

    final url = item.imageUrl.trim();
    if (url.isNotEmpty) {
      return Image.network(
        url,
        width: double.infinity,
        fit: fit,
        errorBuilder: (context, error, stackTrace) => Center(
          child: Icon(Icons.broken_image_outlined, size: 46, color: scheme.error),
        ),
      );
    }

    return Center(child: Icon(Icons.image_outlined, size: 46, color: scheme.primary));
  }
}


class BookPage extends StatefulWidget {
  final List<AppContent> items;
  final VoidCallback onOpenBookAdmin;
  final void Function(AppContent item) onEdit;
  final Future<void> Function(AppContent item) onDelete;
  final Future<void> Function(List<AppContent> chapters) onReplaceBookChapters;
  final Future<void> Function(List<AppContent> chapters) onAppendBookChapters;

  const BookPage({
    super.key,
    required this.items,
    required this.onOpenBookAdmin,
    required this.onEdit,
    required this.onDelete,
    required this.onReplaceBookChapters,
    required this.onAppendBookChapters,
  });

  @override
  State<BookPage> createState() => _BookPageState();
}

class _BookPageState extends State<BookPage> {
  String activeBookTab = 'bolumler';
  String operationStatus = 'Hazır. Word dosyası yükleyebilir veya bölümleri elle düzenleyebilirsin.';

  BookStats get stats => BookStats.from(widget.items);

  Future<void> _shareCreatedFile(BuildContext context, File file, String label) async {
    try {
      await Share.shareXFiles([XFile(file.path)], text: label);
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: file.path));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Dosya hazır. Yol panoya kopyalandı: ${file.path}')),
      );
    }
  }

  Future<void> _exportWord(BuildContext context) async {
    if (widget.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce kitap bölümü ekle.')));
      return;
    }
    try {
      final file = await BookExporter.createDocx(widget.items);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'Word kitap taslağı hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Word dosyası oluşturulamadı: $e')));
    }
  }

  Future<void> _exportPdf(BuildContext context) async {
    if (widget.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce kitap bölümü ekle.')));
      return;
    }
    try {
      final file = await BookExporter.createPdf(widget.items);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'PDF kitap taslağı hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF dosyası oluşturulamadı: $e')));
    }
  }

  final RegExp _writerVisualMarker = RegExp(
    r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*\d*\s*(?::\s*.*)?\]?)\s*$',
    caseSensitive: false,
  );

  String _visualLockToken(int number) => '[[GÖRSEL_KİLİT_$number]]';

  List<String> _extractVisualLocks(String body) {
    final locks = <String>[];
    for (final line in body.split('\n')) {
      final clean = line.trim();
      if (_writerVisualMarker.hasMatch(clean)) {
        // Eski sürümden kayıtlı [[GÖRSEL_KİLİT_1]] metni varsa bunu gerçek görsel işaretine çevir.
        locks.add(clean.startsWith('[[GÖRSEL_KİLİT_') ? 'görsel' : clean);
      }
    }
    return locks;
  }

  String _protectBodyVisualLocks(String body) {
    var number = 1;
    final lines = <String>[];
    for (final line in body.split('\n')) {
      final clean = line.trim();
      if (_writerVisualMarker.hasMatch(clean)) {
        lines.add(_visualLockToken(number));
        number++;
      } else {
        lines.add(line);
      }
    }
    return lines.join('\n').trim();
  }

  bool _generatedKeepsVisualLocks(String generated, int lockCount) {
    if (lockCount <= 0) return true;

    var lastIndex = -1;
    var tokenCount = 0;
    for (var i = 1; i <= lockCount; i++) {
      final token = _visualLockToken(i);
      final index = generated.indexOf(token);
      if (index <= lastIndex) {
        tokenCount = -1;
        break;
      }
      lastIndex = index;
      tokenCount++;
    }
    if (tokenCount == lockCount) return true;

    // ChatGPT kilitleri "görsel" diye geri verdiyse onu da kabul et.
    final normalVisualCount = generated
        .split('\n')
        .where((line) => _writerVisualMarker.hasMatch(line.trim()))
        .length;
    return normalVisualCount == lockCount;
  }

  String _restoreVisualLocks(String generated, List<String> locks) {
    final lines = <String>[];
    var normalMarkerIndex = 0;

    for (final rawLine in generated.trim().split('\n')) {
      var line = rawLine;
      for (var i = 0; i < locks.length; i++) {
        line = line.replaceAll(_visualLockToken(i + 1), locks[i]);
      }

      final clean = line.trim();
      if (_writerVisualMarker.hasMatch(clean)) {
        if (normalMarkerIndex < locks.length) {
          lines.add(locks[normalMarkerIndex]);
          normalMarkerIndex++;
        } else {
          lines.add('görsel');
        }
      } else {
        lines.add(line);
      }
    }

    var result = lines.join('\n').trim();

    // Kalan kilit token'ları asla okuyucuda yazı olarak kalmasın.
    result = result.replaceAll(RegExp(r'\[\[GÖRSEL_KİLİT_\d+\]\]'), 'görsel');

    return result.trim();
  }

  String _cleanWriterGeneratedText(String value) {
    final lines = <String>[];

    for (final line in value.split('\n')) {
      final tokens = line.split(RegExp(r'(\s+)'));
      final cleaned = <String>[];
      var previousWord = '';

      for (final token in tokens) {
        final normalized = token
            .toLowerCase()
            .replaceAll(RegExp(r'[^a-z0-9çğıöşüÇĞİÖŞÜ]'), '');

        if (normalized.isNotEmpty && normalized == previousWord) {
          continue;
        }

        cleaned.add(token);
        if (normalized.isNotEmpty) previousWord = normalized;
      }

      lines.add(cleaned.join());
    }

    return lines.join('\n').replaceAll(RegExp(r'\n{4,}'), '\n\n\n').trim();
  }

  String _chapterWriterRequest(AppContent item, int index, {int retry = 0}) {
    final title = cleanBookChapterTitle(item.title);
    final chapterLabel = bookChapterLabelFromList(widget.items, index);
    final originalBody = item.body.trim().isEmpty ? item.summary.trim() : item.body.trim();
    final protectedBody = _protectBodyVisualLocks(originalBody);
    final visualLocks = _extractVisualLocks(originalBody);
    final words = BookStats.countWords('${item.title} ${item.summary} ${item.body}');
    final pages = BookStats.estimatedPagesForItem(item);
    final targetPages = pages < 3 ? 5 : pages + 2;
    final versionNote = retry == 0 ? '' : '\nBu kez önceki cevaptan farklı bir anlatım kur. Aynı örnekleri kullanma; akışı yeniden kur.';
    final visualRule = visualLocks.isEmpty
        ? '- Bu bölümde görsel kilidi yok. Yeni görsel satırı ekleme.'
        : '''
Görsel kilidi:
- Bu bölümde ${visualLocks.length} görsel alanı var.
- [[GÖRSEL_KİLİT_1]] gibi satırlar görsel yeridir.
- Bu kilit satırlarını AYNEN yaz.
- Bu kilit satırlarını silme, taşıma, çoğaltma veya değiştirme.
- Word dosyasındaki görselleri geri üretmeye çalışma; sadece kilit satırlarını koru.
- Yeni "görsel" satırı ekleme.
- Kilitlerin üstündeki ve altındaki metni genişlet; görseller uygulamada aynı yerde kalsın.''';

    return '''
Sen profesyonel bir kitap editörü ve araştırma yazarı gibi çalış; ama anlatım akademik makale gibi kuru olmasın.

Kitap konusu:
Antik medeniyetlerde reptilyan izleri, antik mitolojiler, semboller, arkeoloji, gizem ve paranormal araştırma.

Yazar kimliği:
Metin bağımsız bir araştırmacının kaleminden çıkmış gibi olmalı. Okuyucuya dönük, merak uyandıran, ciddi ama anlaşılır bir kitap dili kullan. Kozmopolitik ve farklı bilgi seviyelerinden okurların rahat okuyacağı bir anlatım kur.

Görev:
Aşağıdaki bölümü analiz et ve yaklaşık $targetPages standart kitap sayfasına gelecek şekilde genişlet.

Bölüm: $chapterLabel
Bölüm başlığı: $title
Mevcut yaklaşık kelime: $words
Mevcut yaklaşık sayfa: $pages
$versionNote

Kesin kurallar:
- Sadece genişletilmiş bölüm metnini yaz; başlığı tekrar yazma.
- Bölümün mevcut anlatım dilinden şaşma; dışarıdan yazılmış akademik metin gibi durmasın.
- Aynı cümleleri, aynı örnekleri ve aynı fikirleri tekrar etme.
- "bazen bazen", "kiminde kiminde", "kimi zaman kimi zaman" gibi kelime/yapı tekrarlarını temizle.
- Gereksiz yere sürekli Mezopotamya, Anadolu, Mısır, Yunan, Hint, Uzak Doğu gibi uygarlık adlarını sıralama.
- Bu uygarlık adları gerekiyorsa kullan; ama her paragrafta tekrar etme ve liste gibi yığma yapma.
- Konudan sapma; yalnızca bu bölümün ana fikrine odaklan.
- Akıcı, ciddi, gizemli ama anlaşılır kitap dili kullan.
- Gerçek bilgi gerekiyorsa uydurma yapma. Emin olmadığın yerde "bu konuda kesin kanıt yoktur" diye belirt.
- Sahte kaynak, sahte müze bilgisi, sahte kazı raporu veya sahte akademik atıf üretme.
- Mitoloji, arkeolojik veri ve modern/paranormal yorum ayrımını net tut.
- Komplo iddiasını kesin tarihî gerçek gibi yazma.
$visualRule
- Metnin sonunda kısa toparlama paragrafı olsun.

Mevcut bölüm metni:
---
$protectedBody
---
''';
  }

  String _newChapterWriterRequest({int retry = 0}) {
    final titles = widget.items
        .map((item) => cleanBookChapterTitle(item.title))
        .where((title) => title.trim().isNotEmpty)
        .take(60)
        .join('\n- ');
    final versionNote = retry == 0 ? '' : '\nÖnceki öneriden farklı bir bölüm konusu ve farklı akış öner. Aynı uygarlık listesini tekrar etme.';

    return '''
Sen profesyonel bir kitap editörü ve araştırma yazarı gibi çalış; ama anlatım akademik makale gibi kuru olmasın.

Kitap konusu:
Antik medeniyetlerde reptilyan izleri, antik mitolojiler, semboller, arkeoloji, gizem ve paranormal araştırma.

Yazar kimliği:
Metin bağımsız bir araştırmacının kaleminden çıkmış gibi olmalı. Okuyucuya dönük, merak uyandıran, ciddi ama anlaşılır bir kitap dili kullan. Kozmopolitik ve farklı bilgi seviyelerinden okurların rahat okuyacağı bir anlatım kur.

Kitaptaki mevcut bölüm başlıkları:
- $titles

Görev:
Bu kitaba uygun yeni bir bölüm öner ve yaz.
$versionNote

Çıktı biçimi:
Başlık: <yeni bölüm başlığı>

<kitap bölümü metni>

Kurallar:
- Bölüm 5-8 standart kitap sayfası hedefinde olsun.
- Aynı fikirleri tekrar etme.
- "bazen bazen", "kiminde kiminde" gibi kelime/yapı tekrarlarından kaçın.
- Gereksiz yere sürekli Mezopotamya, Anadolu, Mısır, Yunan, Hint, Uzak Doğu gibi uygarlık adlarını sıralama.
- Bu uygarlık adları gerekiyorsa kullan; ama liste gibi yığma yapma.
- Gerçek bilgi gerekiyorsa uydurma yapma; kesin kanıt yoksa bunu açıkça belirt.
- Mitoloji, arkeoloji ve modern/paranormal yorum ayrımını net tut.
- Sahte kaynak ve sahte tarihî belge üretme.
- Gerektiğinde ayrı satır olarak "görsel" yaz.
- Bölüm sonunda kısa sonuç paragrafı olsun.
- Dil: bağımsız araştırmacı sesiyle, okuyucuya dönük, akıcı, ciddi, gizemli ama anlaşılır kitap dili.
''';
  }

  Future<void> _shareWriterTextAsWord(BuildContext context, String title, String body, String fileName) async {
    final cleanBody = body.trim();
    if (cleanBody.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Word için metin yok.')));
      return;
    }

    try {
      final file = await BookExporter.createDocx([
        AppContent(
          id: 'writer_${DateTime.now().microsecondsSinceEpoch}',
          type: ContentTypes.book,
          title: title,
          category: 'Yazar Modu',
          summary: '',
          body: cleanBody,
        ),
      ], fileName: fileName);

      if (!context.mounted) return;
      await _shareCreatedFile(context, file, 'Yazar modu Word dosyası hazır');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Word dosyası oluşturulamadı: $e')));
    }
  }

  Future<String?> _openApiFreeWriterSheet(
    BuildContext context, {
    required String title,
    required String requestText,
    required String acceptLabel,
    required String shareLabel,
    required bool visualLocked,
  }) async {
    final controller = TextEditingController();

    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.92,
          minChildSize: 0.55,
          maxChildSize: 0.97,
          builder: (context, scrollController) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.auto_fix_high_outlined),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  visualLocked
                      ? 'Gönderilecek metin aşağıda görünüyor. ChatGPT’ye gönder, cevabı yapıştır. Görsel yerleri kilitli kontrol edilecek; ChatGPT görsel üretmese de uygulama eski görselleri geri koyacak.'
                      : 'Gönderilecek metin aşağıda görünüyor. ChatGPT’ye gönder, cevabı yapıştır.',
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: () => Share.share(requestText, subject: title),
                      icon: const Icon(Icons.open_in_new_outlined),
                      label: Text(shareLabel),
                    ),
                    OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: requestText));
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gönderilecek metin kopyalandı.')));
                      },
                      icon: const Icon(Icons.copy_outlined),
                      label: const Text('Metni kopyala'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => _shareWriterTextAsWord(context, 'Yazar Modu İsteği', requestText, 'Yazar_Modu_Istegi'),
                      icon: const Icon(Icons.description_outlined),
                      label: const Text('İsteği Word yap'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: SingleChildScrollView(
                    controller: scrollController,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Gönderilecek metin', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(minHeight: 160, maxHeight: 260),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                          ),
                          child: SingleChildScrollView(
                            child: SelectableText(requestText),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text('ChatGPT cevabı', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: controller,
                          minLines: 10,
                          maxLines: 16,
                          textAlignVertical: TextAlignVertical.top,
                          decoration: const InputDecoration(
                            labelText: 'ChatGPT cevabını buraya yapıştır',
                            alignLabelWithHint: true,
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            OutlinedButton.icon(
                              onPressed: () async {
                                final value = controller.text.trim();
                                if (value.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce ChatGPT cevabını yapıştır.')));
                                  return;
                                }
                                await Clipboard.setData(ClipboardData(text: value));
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cevap kopyalandı.')));
                              },
                              icon: const Icon(Icons.copy_all_outlined),
                              label: const Text('Cevabı kopyala'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () {
                                final value = controller.text.trim();
                                if (value.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce ChatGPT cevabını yapıştır.')));
                                  return;
                                }
                                _shareWriterTextAsWord(context, 'Yazar Modu Cevabı', value, 'Yazar_Modu_Cevabi');
                              },
                              icon: const Icon(Icons.description_outlined),
                              label: const Text('Cevabı Word yap'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Share.share(requestText, subject: title),
                        icon: const Icon(Icons.refresh_outlined),
                        label: const Text('Tekrar gönder'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () {
                          final value = controller.text.trim();
                          if (value.isEmpty) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önce ChatGPT cevabını buraya yapıştır.')));
                            return;
                          }
                          Navigator.of(context).pop(value);
                        },
                        icon: const Icon(Icons.check_outlined),
                        label: Text(acceptLabel),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    controller.dispose();
    return result;
  }

  Future<void> _openChapterWriterMode(BuildContext context, AppContent item, int index) async {
    final originalBody = item.body.trim().isEmpty ? item.summary.trim() : item.body.trim();
    final visualLocks = _extractVisualLocks(originalBody);
    var retry = 0;

    while (context.mounted) {
      final request = _chapterWriterRequest(item, index, retry: retry);
      final pasted = await _openApiFreeWriterSheet(
        context,
        title: 'Yazar Modu: Bölüm uzatma',
        requestText: request,
        acceptLabel: 'Bölümü değiştir',
        shareLabel: retry == 0 ? 'ChatGPT’ye gönder' : 'Başka şekilde yazdır',
        visualLocked: visualLocks.isNotEmpty,
      );

      if (pasted == null || pasted.trim().isEmpty || !context.mounted) return;

      final cleanedPasted = _cleanWriterGeneratedText(pasted);
      if (!_generatedKeepsVisualLocks(cleanedPasted, visualLocks.length)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Görsel kilitleri korunmadı. Tekrar gönderip cevabı kilitlerle yapıştır.')),
        );
        retry++;
        continue;
      }

      final safeGenerated = _restoreVisualLocks(cleanedPasted, visualLocks);
      final updated = AppContent(
        id: item.id,
        type: item.type,
        title: item.title,
        category: item.category,
        summary: item.summary,
        body: safeGenerated.trim(),
        imageUrl: item.imageUrl,
        imagePath: item.imagePath,
        source: item.source,
        inlineImagePaths: item.inlineImagePaths,
      );

      final newList = [...widget.items];
      if (index >= 0 && index < newList.length) {
        newList[index] = updated;
        await widget.onReplaceBookChapters(newList);
        if (!mounted) return;
        setState(() => operationStatus = 'Uygulama içi yazar modu bölümü güncelledi: ${bookChapterLabelFromList(newList, index)}');
      }
      return;
    }
  }

  AppContent _chapterFromGeneratedText(String generated) {
    final cleanedGenerated = _cleanWriterGeneratedText(generated);
    final lines = cleanedGenerated.split('\n');
    var title = 'Yeni Bölüm';
    var startIndex = 0;

    for (var i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final lower = line.toLowerCase();
      if (lower.startsWith('başlık:') || lower.startsWith('baslik:')) {
        title = line.substring(line.indexOf(':') + 1).trim();
        startIndex = i + 1;
      } else if (line.length <= 120 && !line.endsWith('.')) {
        title = line.replaceAll(RegExp(r'^#+\s*'), '').trim();
        startIndex = i + 1;
      }
      break;
    }

    final body = lines.skip(startIndex).join('\n').trim();
    return AppContent(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      type: ContentTypes.book,
      title: title.trim().isEmpty ? 'Yeni Bölüm' : title.trim(),
      category: 'Bölüm',
      summary: '',
      body: body.isEmpty ? cleanedGenerated.trim() : body,
    );
  }

  Future<void> _openNewChapterWriterMode(BuildContext context) async {
    var retry = 0;
    while (context.mounted) {
      final request = _newChapterWriterRequest(retry: retry);
      final pasted = await _openApiFreeWriterSheet(
        context,
        title: 'Yazar Modu: Yeni bölüm',
        requestText: request,
        acceptLabel: 'Bölüm ekle',
        shareLabel: retry == 0 ? 'ChatGPT’ye gönder' : 'Başka bölüm yazdır',
        visualLocked: false,
      );

      if (pasted == null || pasted.trim().isEmpty || !context.mounted) return;

      final chapter = _chapterFromGeneratedText(pasted);
      await widget.onAppendBookChapters([chapter]);
      if (!mounted) return;
      setState(() {
        activeBookTab = 'bolumler';
        operationStatus = 'Uygulama içi yazar modu yeni bölüm ekledi.';
      });
      return;
    }
  }

  Future<void> _exportSingleChapter(BuildContext context, AppContent item, int index) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.description_outlined),
                title: const Text('Bu bölümü Word olarak aktar'),
                subtitle: Text(cleanBookChapterTitle(item.title)),
                onTap: () => Navigator.of(context).pop('word'),
              ),
              ListTile(
                leading: const Icon(Icons.picture_as_pdf_outlined),
                title: const Text('Bu bölümü PDF olarak aktar'),
                subtitle: Text(cleanBookChapterTitle(item.title)),
                onTap: () => Navigator.of(context).pop('pdf'),
              ),
            ],
          ),
        ),
      ),
    );

    if (choice == null) return;

    final label = bookChapterLabelFromList(widget.items, index).replaceAll('.', '').replaceAll(' ', '_');
    final title = cleanBookChapterTitle(item.title);
    final fileName = '${label}_${title.isEmpty ? 'Bolum' : title}';

    try {
      final file = choice == 'word'
          ? await BookExporter.createDocx([item], numberingChapters: widget.items, indexOffset: index, fileName: fileName)
          : await BookExporter.createPdf([item], numberingChapters: widget.items, indexOffset: index, fileName: fileName);
      if (!context.mounted) return;
      await _shareCreatedFile(context, file, choice == 'word' ? 'Bölüm Word dosyası hazır' : 'Bölüm PDF dosyası hazır');
      setState(() => operationStatus = 'Tek bölüm dışa aktarıldı: ${bookChapterLabelFromList(widget.items, index)}');
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bölüm dışa aktarılamadı: $e')));
    }
  }

  Future<void> _handleImportedChapters(BuildContext context, List<AppContent> chapters) async {
    if (chapters.isEmpty) {
      setState(() => operationStatus = 'Word dosyası okundu ama bölüm bulunamadı.');
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bölüm bulunamadı.')));
      return;
    }

    final replace = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${chapters.length} bölüm bulundu'),
        content: const Text('Mevcut kitabı silip bunu mu kullanayım, yoksa mevcut bölümlerin üstüne mi ekleyeyim?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(null), child: const Text('İptal')),
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Üstüne ekle')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Eskisini sil ve yükle')),
        ],
      ),
    );

    if (replace == null) return;
    if (replace) {
      await widget.onReplaceBookChapters(chapters);
    } else {
      await widget.onAppendBookChapters(chapters);
    }

    if (!mounted || !context.mounted) return;
    setState(() {
      activeBookTab = 'bolumler';
      operationStatus = 'Word dosyası başarıyla yüklendi. Bölümler kitap formatına çevrildi.';
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Word dosyası başarıyla yüklendi. Bölümler kitap formatına çevrildi.')),
    );
  }

  Future<void> _importWordFile(BuildContext context) async {
    try {
      setState(() => operationStatus = 'Word dosyası seçiliyor...');
      final bytes = await docxPickerChannel.invokeMethod<Uint8List>('pickDocx');
      if (bytes == null || bytes.isEmpty) {
        setState(() => operationStatus = 'Word dosyası seçilmedi.');
        return;
      }

      setState(() => operationStatus = 'Word dosyası okunuyor ve kitap formatına çevriliyor...');
      final chapters = await BookImporter.fromDocx(bytes: bytes);
      if (!context.mounted) return;
      await _handleImportedChapters(context, chapters);
    } catch (e) {
      if (!context.mounted) return;
      setState(() => operationStatus = 'Word dosyası içe aktarılamadı: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Word dosyası içe aktarılamadı: $e')),
      );
    }
  }

  Future<void> _pasteWholeBook(BuildContext context) async {
    final chapters = await Navigator.of(context).push<List<AppContent>>(
      MaterialPageRoute(builder: (_) => const BulkBookPastePage()),
    );
    if (chapters == null) return;
    if (!context.mounted) return;
    await _handleImportedChapters(context, chapters);
  }

  Widget _tabButton(String id, IconData icon, String label) {
    final selected = activeBookTab == id;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Material(
          color: selected ? const Color(0xFF5B3B18) : const Color(0xFFFFF4DD),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => setState(() => activeBookTab = id),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: selected ? const Color(0xFFFFBE78) : const Color(0xFFD8C39A),
                  width: selected ? 2 : 1,
                ),
              ),
              padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 3),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 18, color: selected ? const Color(0xFFFFBE78) : const Color(0xFF5B452C)),
                  const SizedBox(height: 4),
                  Text(
                    label,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 11,
                      color: selected ? const Color(0xFFFFE8C6) : const Color(0xFF2B2117),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _deleteChapter(AppContent item) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bölüm silinsin mi?'),
        content: Text('“${item.title}” bölümü kitaptan silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Sil')),
        ],
      ),
    );

    if (approved != true) return;
    await widget.onDelete(item);
    if (!mounted) return;
    setState(() {
      operationStatus = 'Bölüm silindi.';
      activeBookTab = 'bolumler';
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bölüm silindi.')));
  }

  Widget _activeTabBody() {
    switch (activeBookTab) {
      case 'durum':
        return _BookStatusTab(stats: stats, operationStatus: operationStatus);
      case 'eksikler':
        return _BookMissingTab(stats: stats, items: widget.items);
      case 'bolumler':
      default:
        return _BookChaptersTab(items: widget.items, onEdit: widget.onEdit, onDelete: _deleteChapter, onExport: _exportSingleChapter, onWriter: _openChapterWriterMode, onNewChapter: _openNewChapterWriterMode);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentStats = stats;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
          child: Card(
            elevation: 0,
            color: const Color(0xFFF1E4CC),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Antik Medeniyetlerde Reptilyanların İzinde',
                    softWrap: true,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold, color: const Color(0xFF2B2117), height: 1.15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${currentStats.chapterCount} bölüm • yaklaşık ${currentStats.estimatedPages} sayfa',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: const Color(0xFF5B452C)),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: widget.onOpenBookAdmin,
                        icon: const Icon(Icons.library_add_outlined),
                        label: const Text('Bölüm ekle / düzenle'),
                      ),
                      FilledButton.tonalIcon(
                        onPressed: () => _importWordFile(context),
                        icon: const Icon(Icons.upload_file_outlined),
                        label: const Text('Word dosyası yükle'),
                      ),
                      FilledButton.tonalIcon(
                        onPressed: () => _exportWord(context),
                        icon: const Icon(Icons.description_outlined),
                        label: const Text('Word'),
                      ),
                      FilledButton.tonalIcon(
                        onPressed: () => _exportPdf(context),
                        icon: const Icon(Icons.picture_as_pdf_outlined),
                        label: const Text('PDF'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    operationStatus,
                    style: const TextStyle(color: Color(0xFF5B452C), height: 1.35),
                  ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Material(
            elevation: 10,
            color: Colors.transparent,
            child: Row(
              children: [
                _tabButton('bolumler', Icons.menu_book_outlined, 'Bölümler'),
                _tabButton('durum', Icons.analytics_outlined, 'Durum'),
                _tabButton('eksikler', Icons.checklist_outlined, 'Eksikler'),
              ],
            ),
          ),
        ),
        Expanded(child: _activeTabBody()),
      ],
    );
  }
}

class _BookChaptersTab extends StatelessWidget {
  final List<AppContent> items;
  final void Function(AppContent item) onEdit;
  final void Function(AppContent item) onDelete;
  final void Function(BuildContext context, AppContent item, int index) onExport;
  final void Function(BuildContext context, AppContent item, int index) onWriter;
  final void Function(BuildContext context) onNewChapter;

  const _BookChaptersTab({
    required this.items,
    required this.onEdit,
    required this.onDelete,
    required this.onExport,
    required this.onWriter,
    required this.onNewChapter,
  });

  @override
  Widget build(BuildContext context) {
    final stats = BookStats.from(items);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      children: [
        Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.auto_stories_outlined),
                  title: const Text('Yüklenen Word’den çıkarılan bölüm listesi'),
                  subtitle: Text('Toplam yaklaşık ${stats.estimatedPages} sayfa. Bölüme girince önceki/sonraki ile kitap gibi okunur.'),
                ),
                const SizedBox(height: 8),
                FilledButton.tonalIcon(
                  onPressed: () => onNewChapter(context),
                  icon: const Icon(Icons.auto_fix_high_outlined),
                  label: const Text('Yazar Modu: Yeni bölüm yaz'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (items.isEmpty)
          const EmptyPanel(text: 'Henüz kitap bölümü yok. Word dosyası yükleyebilir veya yönetim panelinden bölüm ekleyebilirsin.')
        else
          ...List.generate(items.length, (index) {
            final item = items[index];
            final chapterPages = BookStats.estimatedPagesForItem(item);
            return Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: item.hasImage
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: SizedBox(width: 56, height: 72, child: GalleryImage(item: item, fit: BoxFit.cover)),
                      )
                    : CircleAvatar(radius: 28, child: Text(isBookFrontMatter(item.title, item.category) ? 'Ö' : '${index + 1}')),
                title: Text(cleanBookChapterTitle(item.title), maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, height: 1.2)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('${bookChapterLabelFromList(items, index)} • yaklaşık $chapterPages sayfa'),
                ),
                trailing: SizedBox(
                  width: 176,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'Bölümü düzenle',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () => onEdit(item),
                      ),
                      IconButton(
                        tooltip: 'Bölümü sil',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => onDelete(item),
                      ),
                      IconButton(
                        tooltip: 'Uygulama içi yazar modu',
                        icon: const Icon(Icons.auto_fix_high_outlined),
                        onPressed: () => onWriter(context, item, index),
                      ),
                      IconButton(
                        tooltip: 'Bölümü Word/PDF aktar',
                        icon: const Icon(Icons.ios_share_outlined),
                        onPressed: () => onExport(context, item, index),
                      ),
                    ],
                  ),
                ),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BookReaderPage(items: items, initialIndex: index, onEdit: onEdit)),
                ),
              ),
            );
          }),
      ],
    );
  }
}

class _BookStatusTab extends StatelessWidget {
  final BookStats stats;
  final String operationStatus;

  const _BookStatusTab({required this.stats, required this.operationStatus});

  @override
  Widget build(BuildContext context) {
    final missingImageCount = stats.chapterCount - stats.imageCount;
    final safeMissingImages = missingImageCount < 0 ? 0 : missingImageCount;
    final extraVisualPages = stats.imageAwarePages - stats.textOnlyPages;
    final safeExtraVisualPages = extraVisualPages < 0 ? 0 : extraVisualPages;

    Widget row(IconData icon, String title, String value, String note) {
      return Card(
        elevation: 0,
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          leading: Icon(icon, size: 30),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(note),
          trailing: Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 150),
      children: [
        Text('Kitap Durumu', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Sayfa hesabı artık sadece kelimeye göre değil; görsellerin kitapta kapladığı alan da hesaba katılır.'),
        const SizedBox(height: 14),
        row(Icons.auto_stories_outlined, 'Görselli kitap tahmini', '${stats.imageAwarePages}', 'Yazı + görseller + bölüm başlangıç payı birlikte hesaplanır.'),
        row(Icons.text_fields_outlined, 'Sadece metin hesabı', '${stats.textOnlyPages}', 'Görseller hiç yokmuş gibi yalnızca kelimeye göre tahmin.'),
        row(Icons.add_photo_alternate_outlined, 'Görsellerin sayfa etkisi', '+$safeExtraVisualPages', 'Görsellerin ve dizgi boşluklarının tahmini eklediği sayfa.'),
        row(Icons.image_outlined, 'Toplam görsel', '${stats.imageCount}', 'Ana görseller ve metin içi görseller birlikte sayılır.'),
        row(Icons.broken_image_outlined, 'Eksik görsel', '$safeMissingImages', 'Görseli olmayan bölüm sayısı.'),
        row(Icons.view_list_outlined, 'Toplam bölüm', '${stats.chapterCount}', 'Word’den veya elle eklenen bölüm sayısı.'),
        row(Icons.notes_outlined, 'Kelime sayısı', '${stats.wordCount}', 'Yaklaşık toplam kelime sayısı.'),
        row(Icons.auto_fix_high_outlined, 'Yazar Modu', 'Açık', 'Görsel kilitlerini gerçek görsele çevirir; Word çıkarır, tekrarları temizler.'),
        const SizedBox(height: 8),
        InfoPanel(
          title: 'Hesaplama mantığı',
          text: BookStats.imageCalculationNote(),
        ),
        const SizedBox(height: 8),
        InfoPanel(title: 'Son işlem', text: operationStatus),
      ],
    );
  }
}

class _BookMissingTab extends StatelessWidget {
  final BookStats stats;
  final List<AppContent> items;

  const _BookMissingTab({required this.stats, required this.items});

  bool _hasXmlNoise(AppContent item) {
    final value = '${item.title}\n${item.category}\n${item.body}';
    return RegExp(r'<\/?(?:w|xml|r|a|wp|pic|mc|v):|w:ascii|rFonts|document\.xml', caseSensitive: false).hasMatch(value);
  }

  @override
  Widget build(BuildContext context) {
    final missing = <String>[...stats.missingItems];
    final missingTitles = items.where((item) => item.title.trim().isEmpty).length;
    final missingImages = items.where((item) => item.imageCount == 0).length;
    final badXml = items.where(_hasXmlNoise).length;

    if (missingTitles > 0) missing.add('$missingTitles bölümde başlık eksik.');
    if (missingImages > 0) missing.add('$missingImages bölümde görsel eksik.');
    if (badXml > 0) missing.add('$badXml bölümde Word/XML kalıntısı görünüyor; Word dosyasını yeniden yükle.');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 150),
      children: [
        Text('Eksik Kontrolü', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Yayın evine vermeden önce buradaki uyarılara bak.'),
        const SizedBox(height: 14),
        if (missing.isEmpty)
          const InfoPanel(
            title: 'Durum iyi',
            text: 'Temel kitap düzeni için büyük eksik görünmüyor. Yine de kaynakça ve görsel izinlerini ayrıca kontrol et.',
          )
        else
          ...missing.map(
            (item) => Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.warning_amber_outlined),
                title: Text(item, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Düzeltmek için Bölümler sekmesinden ilgili bölümü düzenleyebilirsin.'),
              ),
            ),
          ),
        const SizedBox(height: 12),
        const InfoPanel(
          title: 'Son kontrol listesi',
          text: 'Önsöz/Giriş, bölüm sıralaması, sonuç bölümü, kaynakça, görsel kaynak bilgileri, kapak ve arka kapak yazısı kontrol edilmeli.',
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon),
            const SizedBox(height: 8),
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            Text(title, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}



class BulkBookPastePage extends StatefulWidget {
  const BulkBookPastePage({super.key});

  @override
  State<BulkBookPastePage> createState() => _BulkBookPastePageState();
}

class _BulkBookPastePageState extends State<BulkBookPastePage> {
  final controller = TextEditingController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _createBook() {
    final chapters = BookImporter.fromPlainText(controller.text);
    if (chapters.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Metinde bölüm bulunamadı.')));
      return;
    }
    Navigator.of(context).pop(chapters);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kitabı toplu yapıştır'),
        actions: [
          TextButton(onPressed: _createBook, child: const Text('Kitaba çevir')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const InfoPanel(
            title: 'Nasıl çalışır?',
            text:
                'Word metnini buraya komple yapıştır. Uygulama “1. Bölüm”, “Bölüm 1” gibi satırları bölüm başı kabul eder. Hemen sonraki satırı bölüm adı yapar. Kopyala-yapıştırda görseller genelde gelmez; görsellerin otomatik gelmesi için DOCX dosyasını Word içe aktar butonuyla seç.',
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            minLines: 18,
            maxLines: null,
            textInputAction: TextInputAction.newline,
            decoration: const InputDecoration(
              labelText: 'Komple kitap metni',
              hintText: '1. Bölüm\nBölüm adı\n\nMetin...\n\n2. Bölüm\nBölüm adı...',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _createBook,
            icon: const Icon(Icons.auto_fix_high_outlined),
            label: const Text('Otomatik kitap formatına çevir'),
          ),
        ],
      ),
    );
  }
}

class BookImporter {

  static Future<List<AppContent>> fromDocx({String? path, Uint8List? bytes}) async {
    final docxBytes = bytes ?? (path == null ? null : await File(path).readAsBytes());
    if (docxBytes == null || docxBytes.isEmpty) {
      throw Exception('DOCX dosyası okunamadı.');
    }

    final archive = ZipDecoder().decodeBytes(docxBytes);
    final documentFile = archive.findFile('word/document.xml');
    if (documentFile == null) {
      throw Exception('Bu dosya DOCX gibi görünmüyor.');
    }

    final documentXml = utf8.decode(documentFile.content as List<int>);
    final relMap = _readRelationships(archive);
    final importDir = await _prepareImportDir();

    final lines = <String>[];
    final imagePaths = <String>[];

    final paragraphs = RegExp(r'<w:p(?:\s[^>]*)?>[\s\S]*?</w:p>').allMatches(documentXml);
    for (final paragraphMatch in paragraphs) {
      final paragraphXml = paragraphMatch.group(0) ?? '';
      final paragraphText = _cleanImportedText(_paragraphText(paragraphXml));

      final isHeadingStyle = RegExp(r'<w:pStyle[^>]+w:val="(?:Heading1|Heading2|Title|Baslik|Baslık|Balk|Bölüm|Bolum|Heading)[^"]*"', caseSensitive: false)
          .hasMatch(paragraphXml);

      if (paragraphText.isNotEmpty && !_looksLikeXmlNoise(paragraphText)) {
        if (isHeadingStyle && !_isChapterHeading(paragraphText) && _looksLikeHeadingTitle(paragraphText)) {
          lines.add('Bölüm ${lines.where(_isChapterHeading).length + 1}: $paragraphText');
        } else {
          lines.add(paragraphText);
        }
      }

      final embeds = RegExp(r'r:embed="([^"]+)"').allMatches(paragraphXml);
      for (final embed in embeds) {
        final rId = embed.group(1) ?? '';
        final target = relMap[rId];
        if (target == null) continue;

        final savedPath = await _saveImageFromArchive(archive, target, importDir);
        if (savedPath.isNotEmpty) {
          imagePaths.add(savedPath);
          lines.add('görsel');
        }
      }
    }

    return _buildChaptersFromLines(lines, imagePathsByMarker: imagePaths);
  }

  static Future<Directory> _prepareImportDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final importDir = Directory('${dir.path}/word_imports');
    if (!await importDir.exists()) {
      await importDir.create(recursive: true);
    }
    return importDir;
  }

  static Map<String, String> _readRelationships(Archive archive) {
    final relFile = archive.findFile('word/_rels/document.xml.rels');
    if (relFile == null) return {};
    final xml = utf8.decode(relFile.content as List<int>);
    final map = <String, String>{};
    final rels = RegExp(r'<Relationship[^>]+Id="([^"]+)"[^>]+Target="([^"]+)"[^>]*/?>').allMatches(xml);

    for (final rel in rels) {
      final id = rel.group(1) ?? '';
      final targetRaw = _decodeXml(rel.group(2) ?? '');
      if (id.isEmpty || targetRaw.isEmpty || targetRaw.startsWith('http')) continue;

      var target = targetRaw;
      if (!target.startsWith('word/')) {
        target = 'word/$target';
      }
      target = target.replaceAll('word/../', '');
      map[id] = target;
    }
    return map;
  }

  static Future<String> _saveImageFromArchive(Archive archive, String target, Directory importDir) async {
    final candidates = <String>[
      target,
      target.replaceFirst('word/', ''),
      'word/$target',
    ];

    ArchiveFile? imageFile;
    for (final candidate in candidates) {
      imageFile = archive.findFile(candidate);
      if (imageFile != null) break;
    }
    if (imageFile == null) return '';

    final extensionRaw = target.split('.').last.toLowerCase();
    final extension = ['jpg', 'jpeg', 'png', 'webp'].contains(extensionRaw) ? extensionRaw : 'jpg';
    final out = File('${importDir.path}/word_${DateTime.now().microsecondsSinceEpoch}_${imageFile.name.hashCode}.$extension');
    await out.writeAsBytes(imageFile.content as List<int>, flush: true);
    return out.path;
  }

  static String _paragraphText(String xml) {
    final buffer = StringBuffer();
    final texts = RegExp(r'<w:t(?:\s[^>]*)?>([\s\S]*?)</w:t>').allMatches(xml);
    for (final t in texts) {
      buffer.write(_decodeXml(t.group(1) ?? ''));
    }
    return buffer.toString();
  }

  static String _decodeXml(String value) {
    return value
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&');
  }

  static String _cleanImportedText(String value) {
    var cleaned = _fixMojibake(_decodeXml(value));
    cleaned = cleaned.replaceAll(RegExp(r'<[^>]+>'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'\b(?:w|r|xml|a|wp|pic|mc|v):[A-Za-z0-9_-]+\b'), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'\b(?:rFonts|eastAsia|ascii|hAnsi|cs)\b', caseSensitive: false), ' ');
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ').trim();
    return cleaned;
  }

  static String _fixMojibake(String value) {
    return value
        .replaceAll('Ä±', 'ı')
        .replaceAll('Ä°', 'İ')
        .replaceAll('ÅŸ', 'ş')
        .replaceAll('Åž', 'Ş')
        .replaceAll('ÄŸ', 'ğ')
        .replaceAll('Äž', 'Ğ')
        .replaceAll('Ã¼', 'ü')
        .replaceAll('Ãœ', 'Ü')
        .replaceAll('Ã¶', 'ö')
        .replaceAll('Ã–', 'Ö')
        .replaceAll('Ã§', 'ç')
        .replaceAll('Ã‡', 'Ç')
        .replaceAll('â€™', '’')
        .replaceAll('â€œ', '“')
        .replaceAll('â€', '”')
        .replaceAll('â€“', '–')
        .replaceAll('â€”', '—');
  }

  static bool _looksLikeXmlNoise(String value) {
    final lowered = value.toLowerCase();
    return lowered.contains('<w:') ||
        lowered.contains('</w:') ||
        lowered.contains('rfonts') ||
        lowered.contains('w:ascii') ||
        lowered.contains('w:eastasia') ||
        lowered.contains('document.xml') ||
        lowered.contains('word/fonttable') ||
        RegExp(r'<\/?[a-z]+:[^>]+>').hasMatch(lowered);
  }

  static bool _looksLikeHeadingTitle(String line) {
    if (line.length > 180) return false;
    if (_looksLikeXmlNoise(line)) return false;
    final lower = line.toLowerCase();
    if (lower.endsWith('.') && line.length > 80) return false;
    return true;
  }

  static List<AppContent> fromPlainText(String rawText) {
    final lines = rawText.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n');
    return _buildChaptersFromLines(lines, imagePathsByMarker: const []);
  }






  static List<AppContent> _buildChaptersFromLines(List<String> rawLines, {required List<String> imagePathsByMarker}) {
    final drafts = <_BookDraft>[];
    _BookDraft? current;
    var imageCursor = 0;

    void startChapter(String label) {
      if (current != null && current!.hasContent) {
        drafts.add(current!);
      }
      current = _BookDraft(category: _cleanChapterLabel(label));
    }

    void ensureChapter() {
      current ??= _BookDraft(category: 'Giriş');
    }

    void addImageMarker() {
      ensureChapter();
      if (imageCursor < imagePathsByMarker.length) {
        current!.inlineImagePaths.add(imagePathsByMarker[imageCursor]);
        imageCursor++;
      }
      current!.bodyLines.add('görsel');
    }

    for (final rawLine in rawLines) {
      final line = _cleanImportedText(rawLine).trim();
      if (line.isEmpty || _looksLikeXmlNoise(line)) {
        current?.bodyLines.add('');
        continue;
      }

      if (_isImageMarker(line)) {
        addImageMarker();
        continue;
      }

      if (_isChapterHeading(line)) {
        startChapter(line);
        final title = _titleFromChapterHeading(line);
        if (title.trim().isNotEmpty) {
          current!.title = title.trim();
        }
        continue;
      }

      ensureChapter();
      if (current!.title.trim().isEmpty && !_looksLikeParagraph(line)) {
        current!.title = line;
      } else if (_shouldMergeIntoTitle(current!.title, line, current!.bodyLines)) {
        current!.title = '${current!.title.trim()} ${line.trim()}'.trim();
      } else {
        current!.bodyLines.add(line);
      }
    }

    if (current != null && current!.hasContent) {
      drafts.add(current!);
    }

    for (var i = 0; i < drafts.length; i++) {
      if (drafts[i].title.trim().isEmpty) {
        drafts[i].title = drafts[i].category.trim().isEmpty ? '${i + 1}. Bölüm' : drafts[i].category;
      }
      if (drafts[i].category.trim().isEmpty || drafts[i].category == 'Giriş') {
        drafts[i].category = i == 0 ? 'Giriş' : '${i + 1}. Bölüm';
      }
    }

    return List.generate(drafts.length, (index) {
      final draft = drafts[index];
      return AppContent(
        id: 'book_import_${DateTime.now().microsecondsSinceEpoch}_$index',
        type: ContentTypes.book,
        title: cleanBookChapterTitle(draft.title.trim()),
        category: draft.category.trim(),
        summary: '',
        body: [
          if (bookChapterTitleOverflow(draft.title).isNotEmpty) bookChapterTitleOverflow(draft.title),
          draft.bodyLines.join('\n').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim(),
        ].where((part) => part.trim().isNotEmpty).join('\n\n'),
        inlineImagePaths: draft.inlineImagePaths,
      );
    });
  }

  static bool _isImageMarker(String line) {
    final normalized = line.toLowerCase().replaceAll('[', '').replaceAll(']', '').trim();
    return normalized == 'görsel' || normalized == 'gorsel' || normalized.startsWith('görsel ') || normalized.startsWith('gorsel ');
  }

  static bool _isChapterHeading(String line) {
    final upper = line.toUpperCase()
        .replaceAll('İ', 'I')
        .replaceAll('Ş', 'S')
        .replaceAll('Ğ', 'G')
        .replaceAll('Ü', 'U')
        .replaceAll('Ö', 'O')
        .replaceAll('Ç', 'C');
    return RegExp(r'^\d+[\.\-]?\s*BOLUM\b').hasMatch(upper) ||
        RegExp(r'^BOLUM\s*\d+').hasMatch(upper) ||
        RegExp(r'^\d+[\.\-]\s+').hasMatch(upper) && upper.contains('BOLUM');
  }

  static String _cleanChapterLabel(String line) {
    final match = RegExp(r'^(\d+[\.\-]?\s*(?:Bölüm|BOLUM)|(?:Bölüm|BOLUM)\s*\d+)', caseSensitive: false).firstMatch(line);
    if (match == null) return line;
    return match.group(1) ?? line;
  }

  static String _titleFromChapterHeading(String line) {
    final trimmed = line.trim();

    // Örn: "2. Bölüm ANUNNAKİLER:" satırında "ANUNNAKİLER:" kısmını başlık olarak koru.
    final withoutChapterPrefix = trimmed
        .replaceFirst(
          RegExp(r'^\s*(?:\d+[\.\-]?\s*(?:Bölüm|BOLUM)|(?:Bölüm|BOLUM)\s*\d+)\s*[:\-–—]?\s*', caseSensitive: false),
          '',
        )
        .trim();

    if (withoutChapterPrefix.isNotEmpty && withoutChapterPrefix != trimmed) {
      return withoutChapterPrefix;
    }

    final colonIndex = trimmed.indexOf(':');
    if (colonIndex >= 0 && colonIndex < trimmed.length - 1) {
      return trimmed.substring(colonIndex + 1).trim();
    }
    return '';
  }

  static bool _isMostlyUpperTitleLine(String line) {
    final letters = line.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
    if (letters.isEmpty) return false;
    final upperLetters = letters.replaceAll(RegExp(r'[^A-ZÇĞİÖŞÜ]'), '');
    return upperLetters.length / letters.length > 0.70;
  }

  static bool _shouldMergeIntoTitle(String currentTitle, String nextLine, List<String> bodyLines) {
    if (currentTitle.trim().isEmpty || nextLine.trim().isEmpty) return false;
    if (bodyLines.any((line) => line.trim().isNotEmpty)) return false;
    if (nextLine.length > 140) return false;

    final currentUpper = _isMostlyUpperTitleLine(currentTitle);
    final nextUpper = _isMostlyUpperTitleLine(nextLine);

    // Başlık iki satıra bölündüyse birleştir:
    // "ANUNNAKİLER:" + "GÖKTEN İNENLER..." gibi.
    if (currentTitle.trim().endsWith(':') && nextUpper) return true;
    if (currentUpper && nextUpper) return true;

    return false;
  }

  static bool _looksLikeParagraph(String line) {
    if (line.length > 95) return true;
    if (RegExp(r'[.!?…:]\s*$').hasMatch(line) && line.length > 45) return true;
    final letters = line.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
    final upperLetters = letters.replaceAll(RegExp(r'[^A-ZÇĞİÖŞÜ]'), '');
    if (letters.isNotEmpty && upperLetters.length / letters.length > 0.75 && line.length < 95) {
      return false;
    }
    final lower = line.toLowerCase();
    final sentenceHints = ['dır', 'dir', 'olarak', 'çünkü', 'ancak', 'ile ', ' ve ', ' bu ', ' göre ', 'dolayısıyla', 'gerçeklik', 'insanlar'];
    return sentenceHints.any(lower.contains);
  }
}

class _BookDraft {
  String title;
  String category;
  final List<String> bodyLines;
  final List<String> inlineImagePaths;

  _BookDraft({
    this.title = '',
    required this.category,
    List<String>? bodyLines,
    List<String>? inlineImagePaths,
  })  : bodyLines = bodyLines ?? [],
        inlineImagePaths = inlineImagePaths ?? [];

  bool get hasContent => title.trim().isNotEmpty || bodyLines.any((line) => line.trim().isNotEmpty) || inlineImagePaths.isNotEmpty;
}

class BookExporter {
  static String _safeFileName(String value) {
    final cleaned = value
        .replaceAll(RegExp(r'[^\w\sığüşöçİĞÜŞÖÇ-]', unicode: true), '')
        .trim()
        .replaceAll(RegExp(r'\s+'), '_');
    return cleaned.isEmpty ? 'kitap_taslagi' : cleaned;
  }


  static Future<pw.ThemeData?> _loadPdfTheme() async {
    Future<pw.Font?> loadFont(List<String> paths) async {
      for (final path in paths) {
        try {
          final file = File(path);
          if (await file.exists()) {
            final bytes = await file.readAsBytes();
            final data = ByteData.view(bytes.buffer, bytes.offsetInBytes, bytes.lengthInBytes);
            return pw.Font.ttf(data);
          }
        } catch (_) {}
      }
      return null;
    }

    final regular = await loadFont(const [
      '/system/fonts/Roboto-Regular.ttf',
      '/system/fonts/NotoSans-Regular.ttf',
      '/system/fonts/DroidSans.ttf',
    ]);
    final bold = await loadFont(const [
      '/system/fonts/Roboto-Bold.ttf',
      '/system/fonts/NotoSans-Bold.ttf',
      '/system/fonts/DroidSans-Bold.ttf',
    ]);

    if (regular == null) return null;
    return pw.ThemeData.withFont(base: regular, bold: bold ?? regular);
  }

  static String _xml(String value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&apos;');
  }

  static String _paragraph(String text, {bool bold = false, int size = 24}) {
    final safe = _xml(text);
    final boldTag = bold ? '<w:b/>' : '';
    return '<w:p><w:r><w:rPr>$boldTag<w:sz w:val="$size"/></w:rPr><w:t xml:space="preserve">$safe</w:t></w:r></w:p>';
  }

  static String _imageXml(String rId, int id, {String caption = '', required int cx, required int cy}) {
    final cap = caption.trim().isEmpty ? '' : _paragraph(caption, size: 18);
    return '''
<w:p>
  <w:pPr><w:jc w:val="center"/></w:pPr>
  <w:r>
    <w:drawing>
      <wp:inline distT="0" distB="0" distL="0" distR="0">
        <wp:extent cx="$cx" cy="$cy"/>
        <wp:docPr id="$id" name="image$id"/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr>
                <pic:cNvPr id="$id" name="image$id"/>
                <pic:cNvPicPr/>
              </pic:nvPicPr>
              <pic:blipFill>
                <a:blip r:embed="$rId"/>
                <a:stretch><a:fillRect/></a:stretch>
              </pic:blipFill>
              <pic:spPr>
                <a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
              </pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing>
  </w:r>
</w:p>
$cap
''';
  }

  static List<int>? _imagePixelSize(Uint8List bytes) {
    if (bytes.length >= 24 &&
        bytes[0] == 0x89 &&
        bytes[1] == 0x50 &&
        bytes[2] == 0x4E &&
        bytes[3] == 0x47) {
      final data = ByteData.view(bytes.buffer, bytes.offsetInBytes, bytes.lengthInBytes);
      return [data.getUint32(16), data.getUint32(20)];
    }

    if (bytes.length >= 4 && bytes[0] == 0xFF && bytes[1] == 0xD8) {
      var offset = 2;
      while (offset + 9 < bytes.length) {
        if (bytes[offset] != 0xFF) {
          offset++;
          continue;
        }
        final marker = bytes[offset + 1];
        if (marker == 0xD9 || marker == 0xDA) break;
        if (offset + 4 >= bytes.length) break;
        final length = (bytes[offset + 2] << 8) + bytes[offset + 3];
        if (length < 2 || offset + 2 + length > bytes.length) break;
        final isSof = (marker >= 0xC0 && marker <= 0xC3) ||
            (marker >= 0xC5 && marker <= 0xC7) ||
            (marker >= 0xC9 && marker <= 0xCB) ||
            (marker >= 0xCD && marker <= 0xCF);
        if (isSof && offset + 8 < bytes.length) {
          final height = (bytes[offset + 5] << 8) + bytes[offset + 6];
          final width = (bytes[offset + 7] << 8) + bytes[offset + 8];
          if (width > 0 && height > 0) return [width, height];
        }
        offset += 2 + length;
      }
    }

    if (bytes.length >= 30 &&
        String.fromCharCodes(bytes.sublist(0, 4)) == 'RIFF' &&
        String.fromCharCodes(bytes.sublist(8, 12)) == 'WEBP') {
      final chunk = String.fromCharCodes(bytes.sublist(12, 16));
      if (chunk == 'VP8X' && bytes.length >= 30) {
        final width = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16);
        final height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16);
        if (width > 0 && height > 0) return [width, height];
      }
      if (chunk == 'VP8L' && bytes.length >= 25 && bytes[20] == 0x2F) {
        final b0 = bytes[21];
        final b1 = bytes[22];
        final b2 = bytes[23];
        final b3 = bytes[24];
        final width = 1 + (((b1 & 0x3F) << 8) | b0);
        final height = 1 + (((b3 & 0x0F) << 10) | (b2 << 2) | ((b1 & 0xC0) >> 6));
        if (width > 0 && height > 0) return [width, height];
      }
    }

    return null;
  }

  static List<int> _docxImageEmuSize(Uint8List bytes) {
    const maxCx = 4200000;
    const maxCy = 4700000;
    final size = _imagePixelSize(bytes);
    if (size == null) {
      return [3900000, 2600000];
    }

    final width = size[0].toDouble();
    final height = size[1].toDouble();
    if (width <= 0 || height <= 0) {
      return [3900000, 2600000];
    }

    var cx = maxCx.toDouble();
    var cy = cx * height / width;

    if (cy > maxCy) {
      cy = maxCy.toDouble();
      cx = cy * width / height;
    }

    return [cx.round(), cy.round()];
  }

  static Future<File> createDocx(List<AppContent> chapters, {List<AppContent>? numberingChapters, int indexOffset = 0, String? fileName}) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) {
      await exportDir.create(recursive: true);
    }
    final file = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay Aytin Kitap Taslagi')}.docx');

    final archive = Archive();
    final rels = <String>[];
    final doc = StringBuffer();
    var imageId = 1;
    final numberingSource = numberingChapters ?? chapters;

    String addImage(String path, {String caption = ''}) {
      final clean = path.trim();
      if (clean.isEmpty) return '';
      final source = File(clean);
      if (!source.existsSync()) return _paragraph('Görsel bulunamadı: $clean', size: 18);
      final bytes = source.readAsBytesSync();
      final extensionRaw = source.path.split('.').last.toLowerCase();
      final extension = ['jpg', 'jpeg', 'png', 'webp'].contains(extensionRaw) ? extensionRaw : 'jpg';
      final mediaName = 'image$imageId.$extension';
      final rId = 'rId$imageId';
      archive.addFile(ArchiveFile('word/media/$mediaName', bytes.length, bytes));
      rels.add('<Relationship Id="$rId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/$mediaName"/>');
      final imageSize = _docxImageEmuSize(bytes);
      final xml = _imageXml(rId, imageId, caption: caption, cx: imageSize[0], cy: imageSize[1]);
      imageId++;
      return xml;
    }

    doc.writeln(_paragraph('ANTİK MEDENİYETLERDE REPTİLYANLARIN İZİNDE', bold: true, size: 32));
    doc.writeln(_paragraph('Gizem, UFO ve Paranormal Araştırmacı Altay Aytın', size: 22));
    doc.writeln('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');

    final marker = RegExp(r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*(\d*)\s*(?::\s*(.*))?\s*\]?)\s*$', caseSensitive: false);

    for (var i = 0; i < chapters.length; i++) {
      final item = chapters[i];
      final chapterHeader = bookExportChapterHeaderFromList(numberingSource, indexOffset + i);
      final chapterTitle = cleanBookChapterTitle(item.title);
      doc.writeln(_paragraph(chapterHeader, bold: true, size: 26));
      if (!_sameBookHeading(chapterHeader, chapterTitle)) {
        doc.writeln(_paragraph(chapterTitle, bold: true, size: 24));
      }
      if (item.imagePath.trim().isNotEmpty) {
        doc.writeln(addImage(item.imagePath, caption: ''));
      }

      final used = <int>{};
      var autoImageIndex = 0;
      final paragraphLines = <String>[];

      int nextAutoImageIndex() {
        while (used.contains(autoImageIndex)) {
          autoImageIndex++;
        }
        return autoImageIndex++;
      }

      void flush() {
        final value = paragraphLines.join(' ').trim();
        if (value.isNotEmpty) doc.writeln(_paragraph(value, size: 23));
        paragraphLines.clear();
      }

      final titleOverflow = bookChapterTitleOverflow(item.title);
      final exportBody = [
        if (titleOverflow.isNotEmpty) titleOverflow,
        if (item.body.trim().isNotEmpty) item.body.trim(),
      ].join('\n\n');

      for (final line in exportBody.split('\n')) {
        final match = marker.firstMatch(line);
        if (match != null) {
          flush();
          final rawNumber = ((match.group(1) ?? '').trim().isNotEmpty ? match.group(1) : match.group(2))?.trim() ?? '';
          final explicitNumber = int.tryParse(rawNumber);
          final imageIndex = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
          final number = imageIndex + 1;
          final caption = (match.group(3) ?? '').trim();
          used.add(imageIndex);
          if (imageIndex >= 0 && imageIndex < item.inlineImagePaths.length) {
            doc.writeln(addImage(item.inlineImagePaths[imageIndex], caption: caption));
          } else {
            doc.writeln(_paragraph('Seçilmemiş görsel alanı.', size: 16));
          }
        } else if (line.trim().isEmpty) {
          flush();
        } else {
          paragraphLines.add(line.trim());
        }
      }
      flush();

      for (var n = 0; n < item.inlineImagePaths.length; n++) {
        if (!used.contains(n) && item.inlineImagePaths[n].trim().isNotEmpty) {
          doc.writeln(addImage(item.inlineImagePaths[n], caption: ''));
        }
      }

      if (i != chapters.length - 1) {
        doc.writeln('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      }
    }

    final documentXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
 xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
 xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
 xmlns:v="urn:schemas-microsoft-com:vml"
 xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
 xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
 xmlns:w10="urn:schemas-microsoft-com:office:word"
 xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
 xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
 xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
 xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
 xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
 mc:Ignorable="w14 wp14">
 <w:body>
 ${doc.toString()}
 <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>
 </w:body>
</w:document>''';

    final relsXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${rels.join('\n')}
</Relationships>''';

    void addString(String name, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(name, bytes.length, bytes));
    }

    addString('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="jpg" ContentType="image/jpeg"/>
<Default Extension="jpeg" ContentType="image/jpeg"/>
<Default Extension="png" ContentType="image/png"/>
<Default Extension="webp" ContentType="image/webp"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>''');

    addString('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>''');

    addString('word/document.xml', documentXml);
    addString('word/_rels/document.xml.rels', relsXml);
    addString('docProps/core.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:dcterms="http://purl.org/dc/terms/"
 xmlns:dcmitype="http://purl.org/dc/dcmitype/"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>Antik Medeniyetlerde Reptilyanların İzinde</dc:title>
<dc:creator>Altay Aytın</dc:creator>
</cp:coreProperties>''');
    addString('docProps/app.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
 xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>Altay Paranormal Arşiv</Application>
</Properties>''');

    final bytes = ZipEncoder().encode(archive);
    if (bytes == null) throw Exception('DOCX zip oluşturulamadı.');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  static Future<File> createPdf(List<AppContent> chapters, {List<AppContent>? numberingChapters, int indexOffset = 0, String? fileName}) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory('${dir.path}/exports');
    if (!await exportDir.exists()) {
      await exportDir.create(recursive: true);
    }
    final file = File('${exportDir.path}/${_safeFileName(fileName ?? 'Altay Aytin Kitap Taslagi')}.pdf');

    final doc = pw.Document();
    final stats = BookStats.from(chapters);
    final numberingSource = numberingChapters ?? chapters;
    final pdfTheme = await _loadPdfTheme();

    Future<List<pw.Widget>> buildChapter(AppContent item, int index) async {
      final widgets = <pw.Widget>[];
      final textStyle = pw.TextStyle(fontSize: 14, height: 1.45);
      final marker = RegExp(r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*(\d*)\s*(?::\s*(.*))?\s*\]?)\s*$', caseSensitive: false);
      final paragraphLines = <String>[];
      final used = <int>{};
      var autoImageIndex = 0;

      int nextAutoImageIndex() {
        while (used.contains(autoImageIndex)) {
          autoImageIndex++;
        }
        return autoImageIndex++;
      }

      Future<void> addImage(String path, String caption) async {
        final clean = path.trim();
        if (clean.isEmpty) return;
        final source = File(clean);
        if (!source.existsSync()) return;
        try {
          final bytes = await source.readAsBytes();
          widgets.add(pw.SizedBox(height: 10));
          widgets.add(pw.Center(child: pw.Image(pw.MemoryImage(bytes), width: 395, fit: pw.BoxFit.contain)));
          if (caption.trim().isNotEmpty) {
            widgets.add(pw.SizedBox(height: 4));
            widgets.add(pw.Text(caption, style: pw.TextStyle(fontSize: 9)));
          }
          widgets.add(pw.SizedBox(height: 10));
        } catch (_) {}
      }

      void flush() {
        final value = paragraphLines.join(' ').trim();
        if (value.isNotEmpty) {
          widgets.add(pw.Paragraph(text: value, style: textStyle));
        }
        paragraphLines.clear();
      }

      final chapterHeader = bookExportChapterHeaderFromList(numberingSource, indexOffset + index);
      final chapterTitle = cleanBookChapterTitle(item.title);
      widgets.add(pw.Header(level: 0, text: chapterHeader));
      if (!_sameBookHeading(chapterHeader, chapterTitle)) {
        widgets.add(pw.Text(chapterTitle, style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold)));
      }
      widgets.add(pw.SizedBox(height: 8));
      if (item.imagePath.trim().isNotEmpty) {
        await addImage(item.imagePath, '');
      }

      final titleOverflow = bookChapterTitleOverflow(item.title);
      final exportBody = [
        if (titleOverflow.isNotEmpty) titleOverflow,
        if (item.body.trim().isNotEmpty) item.body.trim(),
      ].join('\n\n');

      for (final line in exportBody.split('\n')) {
        final match = marker.firstMatch(line);
        if (match != null) {
          flush();
          final rawNumber = ((match.group(1) ?? '').trim().isNotEmpty ? match.group(1) : match.group(2))?.trim() ?? '';
          final explicitNumber = int.tryParse(rawNumber);
          final imageIndex = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
          final number = imageIndex + 1;
          final caption = (match.group(3) ?? '').trim();
          used.add(imageIndex);
          if (imageIndex >= 0 && imageIndex < item.inlineImagePaths.length) {
            await addImage(item.inlineImagePaths[imageIndex], caption);
          }
        } else if (line.trim().isEmpty) {
          flush();
        } else {
          paragraphLines.add(line.trim());
        }
      }
      flush();

      for (var n = 0; n < item.inlineImagePaths.length; n++) {
        if (!used.contains(n)) {
          await addImage(item.inlineImagePaths[n], '');
        }
      }
      return widgets;
    }

    final allWidgets = <pw.Widget>[
      pw.Text('ANTİK MEDENİYETLERDE REPTİLYANLARIN İZİNDE', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 8),
      pw.Text('Gizem, UFO ve Paranormal Araştırmacı Altay Aytın', style: pw.TextStyle(fontSize: 14)),
      pw.SizedBox(height: 8),
      pw.SizedBox(height: 20),
      pw.Divider(),
      pw.NewPage(),
    ];

    for (var i = 0; i < chapters.length; i++) {
      allWidgets.addAll(await buildChapter(chapters[i], i));
      if (i != chapters.length - 1) allWidgets.add(pw.NewPage());
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(36),
        theme: pdfTheme,
        build: (context) => allWidgets,
      ),
    );

    await file.writeAsBytes(await doc.save(), flush: true);
    return file;
  }
}

class BookStats {
  static const int wordsPerPage = 240;
  static const double mainImagePageShare = 0.45;
  static const double inlineImagePageShare = 0.58;
  static const double chapterLayoutShare = 0.08;

  final int chapterCount;
  final int wordCount;
  final int estimatedPages;
  final int textOnlyPages;
  final int imageAwarePages;
  final int layoutBufferPages;
  final double imagePageEstimate;
  final int imageCount;
  final int shortChapterCount;
  final bool hasIntro;
  final bool hasConclusion;
  final bool hasSources;

  const BookStats({
    required this.chapterCount,
    required this.wordCount,
    required this.estimatedPages,
    required this.textOnlyPages,
    required this.imageAwarePages,
    required this.layoutBufferPages,
    required this.imagePageEstimate,
    required this.imageCount,
    required this.shortChapterCount,
    required this.hasIntro,
    required this.hasConclusion,
    required this.hasSources,
  });

  factory BookStats.from(List<AppContent> items) {
    final words = items.fold<int>(0, (sum, item) => sum + countWords('${item.title} ${item.summary} ${item.body}'));
    final textOnly = pagesFromWords(words);
    final images = items.fold<int>(0, (sum, item) => sum + item.imageCount);
    final imagePages = items.fold<double>(0, (sum, item) => sum + imagePageEstimateFor(item));
    final layoutPages = items.isEmpty ? 0 : (items.length * chapterLayoutShare).ceil();
    final imageAware = (words / wordsPerPage + imagePages + layoutPages).ceil();

    final lowerTitles = items.map((item) => item.title.toLowerCase()).join(' ');
    final lowerAll = items.map((item) => '${item.title} ${item.body} ${item.source}'.toLowerCase()).join(' ');

    return BookStats(
      chapterCount: items.length,
      wordCount: words,
      estimatedPages: imageAware,
      textOnlyPages: textOnly,
      imageAwarePages: imageAware,
      layoutBufferPages: layoutPages,
      imagePageEstimate: imagePages,
      imageCount: images,
      shortChapterCount: items.where((item) => countWords(item.body) < 120).length,
      hasIntro: lowerTitles.contains('giriş') || lowerTitles.contains('giris') || lowerTitles.contains('önsöz') || lowerTitles.contains('onsoz'),
      hasConclusion: lowerTitles.contains('sonuç') || lowerTitles.contains('sonuc') || lowerTitles.contains('kapanış') || lowerTitles.contains('kapanis'),
      hasSources: lowerAll.contains('kaynak') || items.any((item) => item.source.trim().isNotEmpty),
    );
  }

  static int countWords(String value) {
    final matches = RegExp(r'\S+').allMatches(value.trim());
    return matches.length;
  }

  static int pagesFromWords(int words) {
    if (words <= 0) return 0;
    return (words / wordsPerPage).ceil();
  }

  static double imagePageEstimateFor(AppContent item) {
    var total = 0.0;
    if (item.hasImage) total += mainImagePageShare;
    total += item.cleanInlineImagePaths.length * inlineImagePageShare;

    // Görsel kaynak/caption satırları da kitapta boşluk yer.
    if (item.imageCount > 0 && item.source.trim().isNotEmpty) {
      total += 0.06;
    }

    return total;
  }

  static int estimatedPagesFor(String text) => pagesFromWords(countWords(text));

  static int estimatedPagesForItem(AppContent item) {
    final words = countWords('${item.title} ${item.summary} ${item.body}');
    final visual = words / wordsPerPage + imagePageEstimateFor(item) + chapterLayoutShare;
    return visual <= 0 ? 0 : visual.ceil();
  }

  static String imageCalculationNote() {
    return 'Standart kitap tahmini: yaklaşık $wordsPerPage kelime/sayfa, ana görsel ≈ yarım sayfa, metin içi görsel ≈ yarım sayfadan biraz fazla, bölüm başlangıcı için küçük dizgi payı.';
  }

  List<String> get missingItems {
    final list = <String>[];
    if (chapterCount == 0) list.add('Henüz kitap bölümü eklenmemiş.');
    if (!hasIntro) list.add('Giriş veya önsöz bölümü görünmüyor.');
    if (!hasConclusion) list.add('Sonuç / kapanış bölümü görünmüyor.');
    if (!hasSources) list.add('Kaynakça veya kaynak bilgisi görünmüyor.');
    if (imageCount < chapterCount) list.add('${chapterCount - imageCount} bölümde görsel yok.');
    if (shortChapterCount > 0) list.add('$shortChapterCount bölüm çok kısa görünüyor; metin geliştirilebilir.');
    if (estimatedPages < 80) list.add('Kitap hacmi şu an kısa görünüyor: görseller dahil yaklaşık $estimatedPages sayfa.');
    return list;
  }
}

class BookReaderPage extends StatefulWidget {
  final List<AppContent> items;
  final int initialIndex;
  final void Function(AppContent item)? onEdit;

  const BookReaderPage({super.key, required this.items, required this.initialIndex, this.onEdit});

  @override
  State<BookReaderPage> createState() => _BookReaderPageState();
}

class _BookReaderPageState extends State<BookReaderPage> {
  late final PageController controller;
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.initialIndex;
    controller = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _goTo(int index) {
    controller.animateToPage(index, duration: const Duration(milliseconds: 280), curve: Curves.easeOut);
  }

  List<Widget> _buildBookBody(BuildContext context, AppContent item) {
    const textColor = Color(0xFF2B2117);
    const textStyle = TextStyle(fontSize: 20, height: 1.65, color: textColor, fontWeight: FontWeight.w400);
    final widgets = <Widget>[];
    final buffer = <String>[];
    final usedImageIndexes = <int>{};
    var autoImageIndex = 0;

    int nextAutoImageIndex() {
      while (usedImageIndexes.contains(autoImageIndex)) {
        autoImageIndex++;
      }
      return autoImageIndex++;
    }

    final marker = RegExp(r'^\s*(?:\[\[GÖRSEL_KİLİT_(\d+)\]\]|\[?\s*(?:GÖRSEL|GORSEL)\s*(\d*)\s*(?::\s*(.*))?\s*\]?)\s*$', caseSensitive: false);

    void flushText() {
      final text = buffer.join('\n').trim();
      if (text.isNotEmpty) {
        widgets.add(SelectableText(text, style: textStyle));
        widgets.add(const SizedBox(height: 16));
      }
      buffer.clear();
    }

    final titleOverflow = bookChapterTitleOverflow(item.title);
    final body = [
      if (titleOverflow.isNotEmpty) titleOverflow,
      if (item.body.trim().isNotEmpty) item.body.trim(),
    ].join('\n\n').trim();
    if (body.isEmpty) {
      widgets.add(SelectableText('Bu bölüm için henüz metin eklenmemiş.', style: textStyle));
      return widgets;
    }

    for (final line in body.split('\n')) {
      final match = marker.firstMatch(line);
      if (match != null) {
        flushText();
        final rawNumber = ((match.group(1) ?? '').trim().isNotEmpty ? match.group(1) : match.group(2))?.trim() ?? '';
        final explicitNumber = int.tryParse(rawNumber);
        final index = explicitNumber == null ? nextAutoImageIndex() : explicitNumber - 1;
        final imageNumber = index + 1;
        final caption = (match.group(3) ?? '').trim();
        usedImageIndexes.add(index);
        widgets.add(BookInlineImage(path: index >= 0 && index < item.inlineImagePaths.length ? item.inlineImagePaths[index] : '', number: imageNumber, caption: caption));
        widgets.add(const SizedBox(height: 18));
      } else {
        buffer.add(line);
      }
    }
    flushText();

    for (var i = 0; i < item.inlineImagePaths.length; i++) {
      if (!usedImageIndexes.contains(i) && item.inlineImagePaths[i].trim().isNotEmpty) {
        widgets.add(BookInlineImage(path: item.inlineImagePaths[i], number: i + 1, caption: ''));
        widgets.add(const SizedBox(height: 18));
      }
    }

    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    final pages = widget.items;
    final stats = BookStats.from(pages);
    return Scaffold(
      appBar: AppBar(
        title: Text(pages.isEmpty ? 'Kitap' : 'Kitap • ${currentIndex + 1}/${pages.length}'),
        actions: [
          if (widget.onEdit != null && pages.isNotEmpty)
            IconButton(
              tooltip: 'Bu bölümü düzenle',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => widget.onEdit!(pages[currentIndex]),
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: LinearProgressIndicator(value: pages.isEmpty ? 0 : (currentIndex + 1) / pages.length),
          ),
          Expanded(
            child: PageView.builder(
              controller: controller,
              itemCount: pages.length,
              onPageChanged: (value) => setState(() => currentIndex = value),
              itemBuilder: (context, index) {
                final item = pages[index];
                final chapterPages = BookStats.estimatedPagesForItem(item);
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7EFD9),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFD8C39A)),
                        boxShadow: const [
                          BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 4)),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              'Yaklaşık $chapterPages sayfa',
                              style: Theme.of(context).textTheme.labelMedium?.copyWith(color: const Color(0xFF5B452C)),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            cleanBookChapterTitle(item.title),
                            softWrap: true,
                            style: const TextStyle(
                              fontSize: 15,
                              height: 1.16,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF2B2117),
                            ),
                          ),
                          if (item.summary.trim().isNotEmpty) ...[
                            const SizedBox(height: 10),
                            Text(item.summary, style: const TextStyle(fontSize: 17, height: 1.35, color: Color(0xFF4A3925))),
                          ],
                          if (item.hasImage) ...[
                            const SizedBox(height: 18),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: AspectRatio(
                                aspectRatio: 4 / 3,
                                child: GalleryImage(item: item, fit: BoxFit.cover),
                              ),
                            ),
                          ],
                          const SizedBox(height: 10),
                          ..._buildBookBody(context, item),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: currentIndex > 0 ? () => _goTo(currentIndex - 1) : null,
                      icon: const Icon(Icons.chevron_left),
                      label: const Text('Önceki'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: currentIndex < pages.length - 1 ? () => _goTo(currentIndex + 1) : null,
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('Sonraki'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class BookInlineImage extends StatelessWidget {
  final String path;
  final int number;
  final String caption;

  const BookInlineImage({super.key, required this.path, required this.number, this.caption = ''});

  @override
  Widget build(BuildContext context) {
    const textColor = Color(0xFF2B2117);
    if (path.trim().isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF6E6),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFD8C39A)),
        ),
        child: Text('Görsel $number seçilmemiş. Yönetim panelinden Görsel $number seç.', style: const TextStyle(color: textColor)),
      );
    }

    final file = File(path);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: file.existsSync()
              ? Image.file(file, width: double.infinity, fit: BoxFit.contain)
              : Container(
                  height: 180,
                  alignment: Alignment.center,
                  color: const Color(0xFFFFF6E6),
                  child: Text('Görsel $number bulunamadı.', style: const TextStyle(color: textColor)),
                ),
        ),
        if (caption.trim().isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(caption, style: const TextStyle(color: Color(0xFF5B452C), fontSize: 13)),
        ],
      ],
    );
  }
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hakkımda')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          InfoPanel(
            title: 'Altay Aytın',
            text:
                'Gizem, UFO ve paranormal alanlara ilgi duyan bağımsız araştırmacı. Anadolu’da saha gözlemleri, antik yapılar, mitolojik anlatılar ve semboller üzerine notlar tutar.',
          ),
          SizedBox(height: 12),
          InfoPanel(
            title: 'Araştırma yaklaşımı',
            text:
                'Akademik iddia yerine merak, gözlem, kaynak taraması ve sahada görme isteği ön plandadır. Uygulama da bu kişisel araştırma arşivini düzenli şekilde sunmak için hazırlanmıştır.',
          ),
        ],
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    const email = 'altaynesee@gmail.com';
    const handle = '@altaynesee';

    return Scaffold(
      appBar: AppBar(title: const Text('İletişim')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.email_outlined),
              title: const Text(email),
              subtitle: const Text('E-posta adresini kopyala'),
              onTap: () => copyText(context, email),
            ),
          ),
          Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.alternate_email),
              title: const Text(handle),
              subtitle: const Text('Sosyal medya kullanıcı adını kopyala'),
              onTap: () => copyText(context, handle),
            ),
          ),
          const SizedBox(height: 12),
          const InfoPanel(
            title: 'Not',
            text:
                'Bu sürümde bağlantılar kopyalama şeklinde çalışır. Sonraki sürümde WhatsApp, Instagram, YouTube veya web sitesi bağlantıları doğrudan açılabilir.',
          ),
        ],
      ),
    );
  }

  static Future<void> copyText(BuildContext context, String value) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Kopyalandı: $value')));
  }
}

class AdminPage extends StatefulWidget {
  final int initialTabIndex;
  final List<AppContent> articles;
  final List<AppContent> fieldNotes;
  final List<AppContent> galleryItems;
  final List<AppContent> bookChapters;
  final Future<void> Function(AppContent item) onAdd;
  final Future<void> Function(AppContent item) onUpdate;
  final Future<void> Function(AppContent item) onDelete;
  final Future<void> Function() onReset;
  final String Function() exportData;
  final Future<void> Function(String raw) importData;

  const AdminPage({
    super.key,
    this.initialTabIndex = 0,
    required this.articles,
    required this.fieldNotes,
    required this.galleryItems,
    required this.bookChapters,
    required this.onAdd,
    required this.onUpdate,
    required this.onDelete,
    required this.onReset,
    required this.exportData,
    required this.importData,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late List<AppContent> articles;
  late List<AppContent> fieldNotes;
  late List<AppContent> galleryItems;
  late List<AppContent> bookChapters;

  @override
  void initState() {
    super.initState();
    articles = [...widget.articles];
    fieldNotes = [...widget.fieldNotes];
    galleryItems = [...widget.galleryItems];
    bookChapters = [...widget.bookChapters];
  }

  List<AppContent> _itemsForType(String type) {
    if (type == ContentTypes.article) return articles;
    if (type == ContentTypes.field) return fieldNotes;
    if (type == ContentTypes.gallery) return galleryItems;
    return bookChapters;
  }

  void _setItemsForType(String type, List<AppContent> items) {
    setState(() {
      if (type == ContentTypes.article) articles = items;
      if (type == ContentTypes.field) fieldNotes = items;
      if (type == ContentTypes.gallery) galleryItems = items;
      if (type == ContentTypes.book) bookChapters = items;
    });
  }

  Future<void> _openEditor(String type, {AppContent? item}) async {
    final result = await showModalBottomSheet<AppContent>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => ContentEditor(type: type, item: item),
    );
    if (result == null) return;

    final current = _itemsForType(type);
    if (item == null) {
      _setItemsForType(type, [...current, result]);
      await widget.onAdd(result);
    } else {
      final updated = current.map((existing) => existing.id == result.id ? result : existing).toList();
      _setItemsForType(type, updated);
      await widget.onUpdate(result);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kaydedildi.')));
  }

  Future<void> _delete(AppContent item) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Silinsin mi?'),
        content: Text('“${item.title}” kaydı silinecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil')),
        ],
      ),
    );
    if (approved != true) return;
    final updated = _itemsForType(item.type).where((existing) => existing.id != item.id).toList();
    _setItemsForType(item.type, updated);
    await widget.onDelete(item);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Silindi.')));
  }

  Future<void> _reset() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Örnek içeriklere dönülsün mü?'),
        content: const Text('Eklediğin yerel içerikler silinir. Önce yedek alman iyi olur.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sıfırla')),
        ],
      ),
    );
    if (approved != true) return;
    setState(() {
      articles = [...defaultArticles];
      fieldNotes = [...defaultFieldNotes];
      galleryItems = [...defaultGalleryItems];
      bookChapters = [...defaultBookChapters];
    });
    await widget.onReset();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Örnek içerikler geri yüklendi.')));
  }

  Future<void> _copyBackup() async {
    final data = widget.exportData();
    await Clipboard.setData(ClipboardData(text: data));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek panoya kopyalandı. Notlara yapıştırıp saklayabilirsin.')));
  }

  Future<void> _importBackup() async {
    final controller = TextEditingController();
    final raw = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yedekten yükle'),
        content: TextField(
          controller: controller,
          minLines: 6,
          maxLines: 10,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'Yedek metnini buraya yapıştır',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Yükle')),
        ],
      ),
    );
    controller.dispose();
    if (raw == null || raw.trim().isEmpty) return;
    try {
      await widget.importData(raw);
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek yüklendi. Yönetimi tekrar açınca yeni liste görünür.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Yedek okunamadı: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      initialIndex: widget.initialTabIndex,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Yönetim Paneli'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Yazı'),
              Tab(text: 'Saha'),
              Tab(text: 'Galeri'),
              Tab(text: 'Kitap'),
            ],
          ),
          actions: [
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'backup') _copyBackup();
                if (value == 'import') _importBackup();
                if (value == 'reset') _reset();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'backup', child: Text('Yedek kopyala')),
                PopupMenuItem(value: 'import', child: Text('Yedekten yükle')),
                PopupMenuItem(value: 'reset', child: Text('Örnek içeriklere dön')),
              ],
            ),
          ],
        ),
        body: TabBarView(
          children: [
            AdminList(
              title: 'Makale / yazı ekle',
              buttonText: 'Yeni yazı ekle',
              type: ContentTypes.article,
              items: articles,
              onAdd: () => _openEditor(ContentTypes.article),
              onEdit: (item) => _openEditor(ContentTypes.article, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Saha notu ekle',
              buttonText: 'Yeni saha notu ekle',
              type: ContentTypes.field,
              items: fieldNotes,
              onAdd: () => _openEditor(ContentTypes.field),
              onEdit: (item) => _openEditor(ContentTypes.field, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Galeri kaydı ekle',
              buttonText: 'Yeni galeri kaydı ekle',
              type: ContentTypes.gallery,
              items: galleryItems,
              onAdd: () => _openEditor(ContentTypes.gallery),
              onEdit: (item) => _openEditor(ContentTypes.gallery, item: item),
              onDelete: _delete,
            ),
            AdminList(
              title: 'Kitap bölümü ekle',
              buttonText: 'Yeni bölüm ekle',
              type: ContentTypes.book,
              items: bookChapters,
              onAdd: () => _openEditor(ContentTypes.book),
              onEdit: (item) => _openEditor(ContentTypes.book, item: item),
              onDelete: _delete,
            ),
          ],
        ),
      ),
    );
  }
}

class AdminList extends StatelessWidget {
  final String title;
  final String buttonText;
  final String type;
  final List<AppContent> items;
  final VoidCallback onAdd;
  final void Function(AppContent item) onEdit;
  final void Function(AppContent item) onDelete;

  const AdminList({
    super.key,
    required this.title,
    required this.buttonText,
    required this.type,
    required this.items,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(_helpText(type)),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: Text(buttonText)),
        const SizedBox(height: 16),
        for (final item in items)
          Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 12),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => onEdit(item),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(child: Icon(item.icon)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, height: 1.25),
                              ),
                              const SizedBox(height: 6),
                              if (item.summary.trim().isNotEmpty)
                                Text(
                                  item.summary,
                                  maxLines: 4,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                              if (item.summary.trim().isEmpty && item.category.trim().isNotEmpty)
                                Text(
                                  item.category,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton.icon(
                          onPressed: () => onEdit(item),
                          icon: const Icon(Icons.edit_outlined),
                          label: const Text('Düzenle'),
                        ),
                        const SizedBox(width: 8),
                        TextButton.icon(
                          onPressed: () => onDelete(item),
                          icon: const Icon(Icons.delete_outline),
                          label: const Text('Sil'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  String _helpText(String type) {
    if (type == ContentTypes.gallery) {
      return 'Telefondan fotoğraf seçebilir veya gerçek/telifsiz görselin doğrudan URL bağlantısını ekleyebilirsin. Kaynak bilgisini de yaz.';
    }
    if (type == ContentTypes.book) {
      return 'Kitap bölümünü ekle. Satır arasına görsel koymak için metinde tek satır olarak “görsel” yaz; seçtiğin görseller sırayla o yerlere yerleşir.';
    }
    return 'Başlık, kategori, kısa açıklama ve uzun metin gir. Kayıt telefonda saklanır.';
  }
}

class ContentEditor extends StatefulWidget {
  final String type;
  final AppContent? item;

  const ContentEditor({super.key, required this.type, this.item});

  @override
  State<ContentEditor> createState() => _ContentEditorState();
}

class _ContentEditorState extends State<ContentEditor> {
  late final TextEditingController titleController;
  late final TextEditingController categoryController;
  late final TextEditingController summaryController;
  late final TextEditingController bodyController;
  late final TextEditingController imageUrlController;
  late final TextEditingController sourceController;
  String localImagePath = '';
  List<String> inlineImagePaths = List.filled(maxInlineBookImages, '');
  bool pickingImage = false;

  static const int maxInlineBookImages = 10;

  bool get isGallery => widget.type == ContentTypes.gallery;
  bool get isBook => widget.type == ContentTypes.book;

  @override
  void initState() {
    super.initState();
    final item = widget.item;
    titleController = TextEditingController(text: item?.title ?? '');
    categoryController = TextEditingController(text: item?.category ?? (isGallery ? 'Galeri' : (isBook ? '1. Bölüm' : '')));
    summaryController = TextEditingController(text: item?.summary ?? '');
    bodyController = TextEditingController(text: item?.body ?? '');
    imageUrlController = TextEditingController(text: item?.imageUrl ?? '');
    sourceController = TextEditingController(text: item?.source ?? '');
    localImagePath = item?.imagePath ?? '';
    final existingInline = item?.inlineImagePaths ?? const <String>[];
    inlineImagePaths = List.generate(maxInlineBookImages, (index) => index < existingInline.length ? existingInline[index] : '');
  }

  @override
  void dispose() {
    titleController.dispose();
    categoryController.dispose();
    summaryController.dispose();
    bodyController.dispose();
    imageUrlController.dispose();
    sourceController.dispose();
    super.dispose();
  }

  void _save() {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Başlık boş olamaz.')));
      return;
    }
    final nowId = DateTime.now().microsecondsSinceEpoch.toString();
    Navigator.pop(
      context,
      AppContent(
        id: widget.item?.id ?? nowId,
        type: widget.type,
        title: title,
        category: categoryController.text.trim().isEmpty ? (isGallery ? 'Galeri' : (isBook ? 'Bölüm' : 'Genel')) : categoryController.text.trim(),
        summary: isBook ? '' : summaryController.text.trim(),
        body: bodyController.text.trim(),
        imageUrl: imageUrlController.text.trim(),
        imagePath: localImagePath.trim(),
        source: sourceController.text.trim(),
        inlineImagePaths: List<String>.from(inlineImagePaths),
      ),
    );
  }

  Future<void> _pickFromPhoneGallery({int? inlineIndex}) async {
    if ((!isGallery && !isBook) || pickingImage) return;
    setState(() => pickingImage = true);
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final galleryDir = Directory('${dir.path}/altay_gallery_images');
      if (!await galleryDir.exists()) {
        await galleryDir.create(recursive: true);
      }
      final extension = picked.path.split('.').last.toLowerCase();
      final safeExtension = ['jpg', 'jpeg', 'png', 'webp'].contains(extension) ? extension : 'jpg';
      final target = File('${galleryDir.path}/galeri_${DateTime.now().millisecondsSinceEpoch}.$safeExtension');
      final saved = await File(picked.path).copy(target.path);
      if (!mounted) return;
      setState(() {
        if (inlineIndex == null) {
          localImagePath = saved.path;
        } else {
          inlineImagePaths[inlineIndex] = saved.path;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fotoğraf seçilemedi: $e')));
    } finally {
      if (mounted) setState(() => pickingImage = false);
    }
  }

  void _clearLocalImage() {
    setState(() => localImagePath = '');
  }

  void _clearInlineImage(int index) {
    setState(() => inlineImagePaths[index] = '');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 6,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(widget.item == null ? 'Yeni kayıt' : 'Kaydı düzenle', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _field(titleController, isBook ? 'Bölüm başlığı' : 'Başlık', maxLines: isBook ? 10 : 3),
            const SizedBox(height: 10),
            _field(categoryController, isGallery ? 'Kategori / yer' : (isBook ? 'Bölüm etiketi' : 'Kategori')),
            if (!isBook) ...[
              const SizedBox(height: 10),
              _field(summaryController, 'Kısa açıklama', maxLines: 2),
            ],
            const SizedBox(height: 10),
            _field(bodyController, isGallery ? 'Not / açıklama' : (isBook ? 'Bölüm metni' : 'Uzun metin'), maxLines: isBook ? 14 : 10),
            if (isBook) ...[
              const SizedBox(height: 8),
              const Text(
                'Satır arasına görsel koymak için metinde görselin geleceği yere tek satır olarak görsel yaz. Uygulama sıradaki görseli oraya koyar.',
              ),
            ],
            if (isGallery || isBook) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: pickingImage ? null : () => _pickFromPhoneGallery(),
                      icon: pickingImage
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.photo_library_outlined),
                      label: Text(isBook ? 'Bölüm kapak görseli seç' : 'Telefondan fotoğraf seç'),
                    ),
                  ),
                  if (localImagePath.trim().isNotEmpty) ...[
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: 'Seçilen fotoğrafı kaldır',
                      onPressed: _clearLocalImage,
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ],
              ),
              if (localImagePath.trim().isNotEmpty) ...[
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.file(
                    File(localImagePath),
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => const Text('Seçilen fotoğraf gösterilemedi.'),
                  ),
                ),
              ],
              const SizedBox(height: 10),
              _field(imageUrlController, 'İstersen görsel URL bağlantısı'),
              const SizedBox(height: 10),
              _field(sourceController, 'Kaynak / lisans bilgisi'),
              if (isBook) ...[
                const SizedBox(height: 16),
                Text('Satır arası görseller', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Örnek: Bölüm metninde tek satır görsel yazan yerin yerine sıradaki görsel gelir.'),
                const SizedBox(height: 10),
                for (int i = 0; i < maxInlineBookImages; i++)
                  Card(
                    elevation: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(child: Text('Görsel ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold))),
                              if (inlineImagePaths[i].trim().isNotEmpty)
                                IconButton(
                                  tooltip: 'Bu görseli kaldır',
                                  onPressed: () => _clearInlineImage(i),
                                  icon: const Icon(Icons.close),
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: pickingImage ? null : () => _pickFromPhoneGallery(inlineIndex: i),
                                  icon: const Icon(Icons.add_photo_alternate_outlined),
                                  label: Text(inlineImagePaths[i].trim().isEmpty ? 'Görsel ${i + 1} seç' : 'Görsel ${i + 1} değiştir'),
                                ),
                              ),
                            ],
                          ),
                          if (inlineImagePaths[i].trim().isNotEmpty) ...[
                            const SizedBox(height: 8),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.file(
                                File(inlineImagePaths[i]),
                                height: 120,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) => const Text('Bu görsel gösterilemedi.'),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
              ],
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Kaydet')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    );
  }
}

class InfoPanel extends StatelessWidget {
  final String title;
  final String text;

  const InfoPanel({super.key, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(text, style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}

class EmptyPanel extends StatelessWidget {
  final String text;

  const EmptyPanel({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(child: Text(text, textAlign: TextAlign.center)),
    );
  }
}

class ContentTypes {
  static const article = 'article';
  static const field = 'field';
  static const gallery = 'gallery';
  static const book = 'book';
}

class AppContent {
  final String id;
  final String type;
  final String title;
  final String category;
  final String summary;
  final String body;
  final String imageUrl;
  final String imagePath;
  final String source;
  final List<String> inlineImagePaths;

  const AppContent({
    required this.id,
    required this.type,
    required this.title,
    required this.category,
    required this.summary,
    required this.body,
    this.imageUrl = '',
    this.imagePath = '',
    this.source = '',
    this.inlineImagePaths = const [],
  });

  bool get hasImage => imagePath.trim().isNotEmpty || imageUrl.trim().isNotEmpty;
  List<String> get cleanInlineImagePaths => inlineImagePaths.where((value) => value.trim().isNotEmpty).toList();
  int get imageCount => (hasImage ? 1 : 0) + cleanInlineImagePaths.length;

  IconData get icon {
    if (type == ContentTypes.field) return Icons.location_on_outlined;
    if (type == ContentTypes.gallery) return Icons.photo_library_outlined;
    if (type == ContentTypes.book) return Icons.menu_book_outlined;
    final lower = category.toLowerCase();
    if (lower.contains('arkeoloji')) return Icons.account_balance_outlined;
    if (lower.contains('gökyüzü') || lower.contains('ufo')) return Icons.public;
    if (lower.contains('mitoloji')) return Icons.auto_awesome_outlined;
    return Icons.article_outlined;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'category': category,
        'summary': summary,
        'body': body,
        'imageUrl': imageUrl,
        'imagePath': imagePath,
        'source': source,
        'inlineImagePaths': inlineImagePaths,
      };

  factory AppContent.fromJson(Map<String, dynamic> json, String fallbackType) {
    return AppContent(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      type: json['type']?.toString() ?? fallbackType,
      title: json['title']?.toString() ?? 'Başlıksız',
      category: json['category']?.toString() ?? 'Genel',
      summary: json['summary']?.toString() ?? '',
      body: json['body']?.toString() ?? '',
      imageUrl: json['imageUrl']?.toString() ?? '',
      imagePath: json['imagePath']?.toString() ?? '',
      source: json['source']?.toString() ?? '',
      inlineImagePaths: json['inlineImagePaths'] is List
          ? (json['inlineImagePaths'] as List).map((value) => value.toString()).toList()
          : const [],
    );
  }
}

class LocalStore {
  static const articlesKey = 'v2_articles_json';
  static const fieldNotesKey = 'v2_field_notes_json';
  static const galleryKey = 'v2_gallery_json';
  static const bookKey = 'v2_book_json';

  static Future<List<AppContent>> loadList(String key, List<AppContent> defaults) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.trim().isEmpty) return [...defaults];
    try {
      final decoded = jsonDecode(raw);
      final type = defaults.isEmpty ? ContentTypes.article : defaults.first.type;
      final list = decodeList(decoded, type);
      return list.isEmpty ? [...defaults] : list;
    } catch (_) {
      return [...defaults];
    }
  }

  static Future<void> saveList(String key, List<AppContent> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(items.map((item) => item.toJson()).toList()));
  }

  static List<AppContent> decodeList(dynamic decoded, String fallbackType) {
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((entry) => AppContent.fromJson(Map<String, dynamic>.from(entry), fallbackType))
        .toList();
  }
}

const defaultArticles = [
  AppContent(
    id: 'article_1',
    type: ContentTypes.article,
    title: 'Mağaralar, Hafıza ve Köken Anlatıları',
    category: 'Mitoloji',
    summary: 'Mağara mekânının eski anlatılardaki simgesel rolü.',
    body:
        'Mağara, birçok kadim anlatıda yalnızca saklanma yeri değildir. Karanlık, geçiş, yeniden doğuş, bilinmeyenle yüzleşme ve köken hafızası gibi anlamlar taşır. Kahramanın mağarada karşılaştığı varlık, çoğu zaman sıradan bir figür değil, soyun veya bilginin gizli tarafını temsil eden eşik varlığıdır.',
  ),
  AppContent(
    id: 'article_2',
    type: ContentTypes.article,
    title: 'Şahmeran: Yılan Bedenli Bilgelik Figürü',
    category: 'Anadolu Efsaneleri',
    summary: 'Şahmeran anlatısında bilgelik, sır ve beden sembolizmi.',
    body:
        'Şahmeran anlatısı; yarı insan yarı yılan formuyla hem korkuyu hem bilgeliği aynı bedende toplar. Bu ikili yapı, eski toplumların doğa, ölüm, şifa ve gizli bilgiyle kurduğu ilişkiyi okumak için güçlü bir kapı açar.',
  ),
  AppContent(
    id: 'article_3',
    type: ContentTypes.article,
    title: 'Draco Takımyıldızı ve Antik Gökyüzü Haritaları',
    category: 'Gökyüzü',
    summary: 'Ejderha/yılan sembolünün göksel karşılıkları.',
    body:
        'Draco takımyıldızı, gökyüzünde yılanımsı uzun formuyla tarih boyunca dikkat çekmiştir. Antik toplumların gökyüzünü yalnızca takvim için değil, mitolojik hafıza için de kullandığı düşünülür.',
  ),
  AppContent(
    id: 'article_4',
    type: ContentTypes.article,
    title: 'Göbekli Tepe ve Sembol Hafızası',
    category: 'Arkeoloji',
    summary: 'Taş sütunlar, hayvan kabartmaları ve ritüel alan fikri.',
    body:
        'Göbekli Tepe, sembollerin taş üzerine işlendiği güçlü bir hafıza alanı olarak görülebilir. Hayvan kabartmaları, ritüel düzen ve anıtsal mimari; insanlığın erken dönem inanç dünyasına dair büyük sorular doğurur.',
  ),
  AppContent(
    id: 'article_5',
    type: ContentTypes.article,
    title: 'Derinkuyu: Yeraltı, Koridor ve Saklı Yaşam',
    category: 'Yeraltı Şehirleri',
    summary: 'Kapalı mekân, geçitler ve savunma mimarisi.',
    body:
        'Derinkuyu gibi yeraltı şehirleri; dar koridorları, taş kapıları ve katmanlı yapısıyla yalnızca mimari değil, psikolojik bir atmosfer de oluşturur. Yeraltına iniş, eski anlatılardaki bilinmeyene geçiş temasını hatırlatır.',
  ),
];

const defaultFieldNotes = [
  AppContent(
    id: 'field_1',
    type: ContentTypes.field,
    title: 'Hattuşa Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Büyük Mabed, Yeşil Taş ve Hitit başkentinin izleri.',
    body:
        'Hattuşa gezisi, taş mimariyi ve kutsal alan düzenini yerinde görmek için güçlü bir saha noktasıdır. Büyük Mabed ve Yeşil Taş, araştırma arşivinde ayrıca incelenebilir.',
  ),
  AppContent(
    id: 'field_2',
    type: ContentTypes.field,
    title: 'Yazılıkaya Saha Notu',
    category: 'Çorum / Boğazkale',
    summary: 'Tanrı kabartmaları, geçit ve kaya tapınağı atmosferi.',
    body:
        'Yazılıkaya, açık hava kaya tapınağı atmosferiyle mitolojik figürleri taş üzerine taşıyan özel bir alandır. Kabartmalar, geçit ve kaya yüzeyi bir arada okunmalıdır.',
  ),
  AppContent(
    id: 'field_3',
    type: ContentTypes.field,
    title: 'Efes Saha Notu',
    category: 'İzmir / Selçuk',
    summary: 'Celsus, Yamaç Evleri ve antik şehir dokusu.',
    body:
        'Efes, Roma dönemi mimari hafızasını güçlü şekilde taşır. Yamaç Evleri, Celsus ve Herakles Kapısı gibi noktalar görsel arşiv için değerlidir.',
  ),
  AppContent(
    id: 'field_4',
    type: ContentTypes.field,
    title: 'Myra Saha Notu',
    category: 'Antalya / Demre',
    summary: 'Kaya mezarları, Medusa imgesi ve Likya dokusu.',
    body:
        'Myra, kaya mezarları ve antik tiyatrosuyla Likya dünyasının güçlü izlerini taşır. Medusa ve koruyucu sembol fikri burada ayrıca araştırılabilir.',
  ),
];


const defaultBookChapters = [
  AppContent(
    id: 'book_1',
    type: ContentTypes.book,
    title: 'Giriş: Taşların Sessiz Dili',
    category: 'Giriş',
    summary: 'Araştırmanın çerçevesi ve kitabın amacı.',
    body:
        'Bu kitap, antik medeniyetler içinde yılan, ejderha ve reptilyan benzeri sembollerin izini süren bağımsız bir araştırma arşivi olarak düşünülmüştür. Amaç kesin hüküm vermek değil; mekânları, sembolleri, efsaneleri ve saha gözlemlerini yan yana getirerek okura düşünme alanı açmaktır.',
  ),
  AppContent(
    id: 'book_2',
    type: ContentTypes.book,
    title: 'Şahmeran ve Bilgeliğin Gizli Bedeni',
    category: 'Bölüm 1',
    summary: 'Anadolu anlatılarında yılan bedenli bilgelik figürü.',
    body:
        'Şahmeran figürü, yalnızca halk anlatısı olarak değil; aynı zamanda bilgi, şifa, sır ve bedensel dönüşüm sembolizmi olarak da okunabilir. Yarı insan yarı yılan formu, insanla doğa arasındaki eşiği beden üzerinde görünür kılar.',
  ),
  AppContent(
    id: 'book_3',
    type: ContentTypes.book,
    title: 'Göbekli Tepe, Sembol Hafızası ve Taşlardaki İzler',
    category: 'Bölüm 2',
    summary: 'Kabartmalar, ritüel alanlar ve kadim hafıza.',
    body:
        'Göbekli Tepe gibi merkezler, yalnızca arkeolojik alan değil; aynı zamanda sembol hafızasının taşa işlendiği anıtsal anlatı alanlarıdır. Yılan, kuş ve insan formları; kadim düşünce dünyasının çok katmanlı yapısını yansıtır.',
  ),
];

const defaultGalleryItems = [
  AppContent(
    id: 'gallery_1',
    type: ContentTypes.gallery,
    title: 'Göbekli Tepe',
    category: 'Galeri',
    summary: 'Gerçek/telifsiz görsel bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_2',
    type: ContentTypes.gallery,
    title: 'Hattuşa',
    category: 'Galeri',
    summary: 'Gerçek saha fotoğrafı için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_3',
    type: ContentTypes.gallery,
    title: 'Yazılıkaya',
    category: 'Galeri',
    summary: 'Açık lisanslı kaynak görsel için yer ayrıldı.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
  AppContent(
    id: 'gallery_4',
    type: ContentTypes.gallery,
    title: 'Derinkuyu',
    category: 'Galeri',
    summary: 'Gerçek fotoğraf bağlantısı eklenebilir.',
    body: 'Yönetim panelinden görsel URL ve kaynak bilgisi gir.',
  ),
];
