# İçerik Düzenleme Rehberi — 2. Sürüm

Artık temel içerikleri koddan değil, uygulamanın içinden ekleyebilirsin.

## Uygulamada içerik ekleme

1. Uygulamayı aç.
2. Sağ üstteki yönetim simgesine bas.
3. Yönetim Paneli içinde şu sekmelerden birini seç:
   - Yazı
   - Saha
   - Galeri
4. Yeni kayıt ekle butonuna bas.
5. Başlık, kategori, kısa açıklama ve metin alanlarını doldur.
6. Galeri için görsel URL ve kaynak/lisans bilgisini gir.
7. Kaydet.

## Yedek alma

Yönetim Paneli sağ üst menüsünden **Yedek kopyala** seç. Metni Notlar uygulamasına yapıştırıp sakla.

## Yedekten yükleme

Yönetim Paneli sağ üst menüsünden **Yedekten yükle** seç. Daha önce kopyaladığın yedek metnini yapıştır.

## Sınırlama

Bu sürüm internet üzerinden herkese otomatik güncelleme yapmaz. İçerikler telefonda saklanır. Herkeste aynı içeriğin görünmesi için ileride Firebase/online panel kurulabilir.
