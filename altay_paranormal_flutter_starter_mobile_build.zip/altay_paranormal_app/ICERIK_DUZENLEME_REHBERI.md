# İçerik Düzenleme Rehberi

## Uygulama adını değiştirmek

`lib/main.dart` içinde şu alanları arayın:

- `Gizem ve Paranormal Araştırman`
- `Altay Aytın`
- `Altay Aytın Araştırma Uygulaması`

## Yeni makale eklemek

`sampleArticles` listesine şu yapıda yeni kayıt ekleyin:

```dart
ContentItem(
  title: 'Makale başlığı',
  category: 'Kategori',
  summary: 'Kısa açıklama',
  body: 'Uzun makale metni buraya gelecek.',
  icon: Icons.article_outlined,
),
```

## Yeni saha notu eklemek

`fieldNotes` listesine aynı yapıda yeni kayıt ekleyin.

## Galeriye gerçek görsel eklemek

1. Projede `assets/images/` klasörü oluşturun.
2. Telifsiz/izinli gerçek görseli bu klasöre koyun.
3. `pubspec.yaml` içindeki assets satırlarını aktif edin:

```yaml
flutter:
  uses-material-design: true
  assets:
    - assets/images/
```

4. `GalleryPlaceholder` alanlarını `Image.asset('assets/images/dosya_adi.jpg')` ile değiştirin.
