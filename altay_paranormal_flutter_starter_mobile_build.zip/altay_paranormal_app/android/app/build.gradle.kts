plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.altayaytin.altay_paranormal_app"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.altayaytin.altay_paranormal_app"
        minSdk = maxOf(flutter.minSdkVersion, 21)
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            // GitHub'dan üretilen APK'nın önceki deneme sürümlerinin üzerine
            // kurulabilmesi için mevcut debug imzası korunur.
            signingConfig = signingConfigs.getByName("debug")
            // PDFBox'un isteğe bağlı JPEG2000 sınıfları R8 tarafından zorunlu
            // sanılmasın; kitap dışa aktarımında kararlı derleme önceliklidir.
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
