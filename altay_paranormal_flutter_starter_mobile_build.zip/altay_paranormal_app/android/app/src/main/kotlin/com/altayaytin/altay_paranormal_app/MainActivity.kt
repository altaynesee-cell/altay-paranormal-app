package com.altayaytin.altay_paranormal_app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : FlutterActivity() {
    private val channelName = "altay_paranormal/docx_picker"
    private val requestCodeDocuments = 43210
    private val requestCodeBackup = 43211
    private var pendingResult: MethodChannel.Result? = null
    private val pendingSharedFiles = mutableListOf<HashMap<String, Any>>()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        readSharedFilesFromIntent(intent)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDocuments" -> openDocumentPicker(result, allowMultiple = true)
                "pickDocx" -> openLegacyDocxPicker(result)
                "pickBackup" -> openBackupPicker(result)
                "getSharedFiles" -> {
                    val files = pendingSharedFiles.map { HashMap(it) }
                    pendingSharedFiles.clear()
                    result.success(files)
                }
                // Önceki Flutter sürümleriyle uyumluluk.
                "getSharedDocxFiles" -> {
                    val files = pendingSharedFiles.mapNotNull { entry ->
                        runCatching { File(entry["path"].toString()).readBytes() }.getOrNull()
                    }
                    pendingSharedFiles.clear()
                    result.success(files)
                }
                "getSharedDocx" -> {
                    val first = pendingSharedFiles.firstOrNull()
                    pendingSharedFiles.clear()
                    val bytes = first?.let { runCatching { File(it["path"].toString()).readBytes() }.getOrNull() }
                    result.success(bytes)
                }
                "renderPdfPages" -> {
                    val path = call.argument<String>("path")
                    if (path.isNullOrBlank()) {
                        result.error("missing_path", "PDF dosya yolu bulunamadı.", null)
                    } else {
                        renderPdfPages(path, result)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedFilesFromIntent(intent)
    }

    private fun readSharedFilesFromIntent(incoming: Intent?) {
        if (incoming == null) return

        val uris = linkedSetOf<Uri>()
        when (incoming.action) {
            Intent.ACTION_SEND -> getSingleStreamUri(incoming)?.let(uris::add)
            Intent.ACTION_SEND_MULTIPLE -> uris.addAll(getMultipleStreamUris(incoming))
            Intent.ACTION_VIEW -> incoming.data?.let(uris::add)
        }

        incoming.clipData?.let { clipData ->
            for (index in 0 until clipData.itemCount) {
                clipData.getItemAt(index).uri?.let(uris::add)
            }
        }

        if (uris.isEmpty()) return

        val receivedMime = incoming.type.orEmpty()
        val loaded = uris.mapNotNull { uri -> copyIncomingUri(uri, receivedMime) }
        if (loaded.isNotEmpty()) {
            pendingSharedFiles.clear()
            pendingSharedFiles.addAll(loaded)
            // Aynı paylaşım intent'i normal açılışta yeniden işlenmesin.
            setIntent(Intent(this, MainActivity::class.java))
        }
    }

    private fun copyIncomingUri(uri: Uri, fallbackMime: String = ""): HashMap<String, Any>? {
        return try {
            val displayName = queryDisplayName(uri).ifBlank { "belge_${System.currentTimeMillis()}" }
            val safeName = sanitizeFileName(displayName)
            val mimeType = contentResolver.getType(uri).orEmpty().ifBlank { fallbackMime }.ifBlank { guessMimeType(safeName) }
            val folder = File(cacheDir, "shared_document_imports").apply { mkdirs() }
            val output = File(folder, "${System.nanoTime()}_$safeName")

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(output).use { stream -> input.copyTo(stream) }
            } ?: return null

            if (!output.exists() || output.length() == 0L) return null
            hashMapOf(
                "path" to output.absolutePath,
                "name" to safeName,
                "mimeType" to mimeType,
                "size" to output.length()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment.orEmpty()
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun sanitizeFileName(value: String): String {
        val cleaned = value.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim()
        return cleaned.ifBlank { "belge_${System.currentTimeMillis()}" }
    }

    private fun guessMimeType(name: String): String {
        return when (name.lowercase(Locale.ROOT).substringAfterLast('.', "")) {
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "doc" -> "application/msword"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    @Suppress("DEPRECATION")
    private fun getSingleStreamUri(intent: Intent): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
    }

    @Suppress("DEPRECATION")
    private fun getMultipleStreamUris(intent: Intent): List<Uri> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
        } else {
            intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
        }
    }

    private fun openDocumentPicker(result: MethodChannel.Result, allowMultiple: Boolean) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }
        pendingResult = result
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple)
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/msword",
                    "application/pdf",
                    "text/plain",
                    "application/octet-stream"
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(picker, "Word, PDF veya TXT dosyalarını seç"), requestCodeDocuments)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    private fun openLegacyDocxPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }
        pendingResult = result
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/msword",
                    "application/octet-stream"
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(picker, "Word dosyası seç"), requestCodeDocuments)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    private fun openBackupPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }
        pendingResult = result
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "application/zip", "text/plain", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(picker, "Yedek dosyası seç"), requestCodeBackup)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCodeDocuments && requestCode != requestCodeBackup) return

        val result = pendingResult
        pendingResult = null
        if (result == null) return
        if (resultCode != Activity.RESULT_OK || data == null) {
            result.success(null)
            return
        }

        if (requestCode == requestCodeBackup) {
            val uri = data.data
            if (uri == null) {
                result.success(null)
                return
            }
            try {
                result.success(contentResolver.openInputStream(uri)?.use { it.readBytes() })
            } catch (e: Exception) {
                result.error("read_error", e.message, null)
            }
            return
        }

        val uris = linkedSetOf<Uri>()
        data.data?.let(uris::add)
        data.clipData?.let { clipData ->
            for (index in 0 until clipData.itemCount) {
                clipData.getItemAt(index).uri?.let(uris::add)
            }
        }
        val files = uris.mapNotNull { copyIncomingUri(it, data.type.orEmpty()) }
        result.success(files)
    }

    private fun renderPdfPages(path: String, result: MethodChannel.Result) {
        val source = File(path)
        if (!source.exists()) {
            result.error("pdf_missing", "PDF dosyası bulunamadı.", null)
            return
        }

        try {
            val outputDir = File(filesDir, "imported_pdf_pages/${source.nameWithoutExtension}_${source.lastModified()}").apply { mkdirs() }
            val descriptor = ParcelFileDescriptor.open(source, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(descriptor)
            val outputPaths = mutableListOf<String>()

            for (index in 0 until renderer.pageCount) {
                val page = renderer.openPage(index)
                val scale = minOf(2.0f, 2200f / page.width.toFloat())
                val width = maxOf(1, (page.width * scale).toInt())
                val height = maxOf(1, (page.height * scale).toInt())
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                Canvas(bitmap).drawColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                val output = File(outputDir, "sayfa_${(index + 1).toString().padStart(3, '0')}.png")
                FileOutputStream(output).use { bitmap.compress(Bitmap.CompressFormat.PNG, 95, it) }
                bitmap.recycle()
                page.close()
                outputPaths.add(output.absolutePath)
            }

            renderer.close()
            descriptor.close()
            result.success(outputPaths)
        } catch (e: Exception) {
            result.error("pdf_render_failed", e.message ?: "PDF sayfaları okunamadı.", null)
        }
    }
}
