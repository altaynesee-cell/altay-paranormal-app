package com.altayaytin.altay_paranormal_app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "altay_paranormal/docx_picker"
    private val requestCodeDocx = 43210
    private var pendingResult: MethodChannel.Result? = null
    private var pendingSharedBytes: ByteArray? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        readSharedFileFromIntent(intent)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDocx" -> openDocxPicker(result)
                "getSharedDocx" -> {
                    val bytes = pendingSharedBytes
                    pendingSharedBytes = null
                    result.success(bytes)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedFileFromIntent(intent)
    }

    private fun readSharedFileFromIntent(incoming: Intent?) {
        if (incoming == null) return

        val uri: Uri? = when (incoming.action) {
            Intent.ACTION_SEND -> incoming.getParcelableExtra(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> incoming.data
            else -> null
        }

        if (uri == null) return

        try {
            pendingSharedBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (_: Exception) {
            pendingSharedBytes = null
        }
    }

    private fun openDocxPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }

        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/msword",
                "application/octet-stream",
                "application/zip"
            ))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        try {
            startActivityForResult(Intent.createChooser(intent, "Word dosyası seç"), requestCodeDocx)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != requestCodeDocx) return

        val result = pendingResult
        pendingResult = null
        if (result == null) return

        if (resultCode != Activity.RESULT_OK) {
            result.success(null)
            return
        }

        val uri = data?.data
        if (uri == null) {
            result.success(null)
            return
        }

        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) {
                result.error("read_failed", "Word dosyası okunamadı.", null)
            } else {
                result.success(bytes)
            }
        } catch (e: Exception) {
            result.error("read_error", e.message, null)
        }
    }
}
