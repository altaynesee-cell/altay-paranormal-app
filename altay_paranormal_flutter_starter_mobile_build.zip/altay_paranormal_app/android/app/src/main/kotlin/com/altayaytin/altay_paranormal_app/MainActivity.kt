package com.altayaytin.altay_paranormal_app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.view.WindowManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : FlutterActivity() {
    private val channelName = "altay_paranormal/docx_picker"
    private val requestCodeDocuments = 43210
    private val requestCodeBackup = 43211
    private val requestCodeSaveExport = 43212
    private var pendingResult: MethodChannel.Result? = null
    private var pendingSaveResult: MethodChannel.Result? = null
    private var pendingSaveSourcePath: String? = null
    private val pendingSharedFiles = mutableListOf<HashMap<String, Any>>()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        PDFBoxResourceLoader.init(applicationContext)
        readSharedFilesFromIntent(intent)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDocuments" -> openDocumentPicker(result, allowMultiple = true)
                "pickDocx" -> openLegacyDocxPicker(result)
                "pickBackup" -> openBackupPicker(result)
                "getSharedFiles" -> {
                    val files = pendingSharedFiles.map { HashMap(it) }
                    pendingSharedFiles.clear()
                    result.success(files)
                }
                // Önceki Flutter sürümleriyle uyumluluk.
                "getSharedDocxFiles" -> {
                    val files = pendingSharedFiles.mapNotNull { entry ->
                        runCatching { File(entry["path"].toString()).readBytes() }.getOrNull()
                    }
                    pendingSharedFiles.clear()
                    result.success(files)
                }
                "getSharedDocx" -> {
                    val first = pendingSharedFiles.firstOrNull()
                    pendingSharedFiles.clear()
                    val bytes = first?.let { runCatching { File(it["path"].toString()).readBytes() }.getOrNull() }
                    result.success(bytes)
                }
                "prepareExportImage" -> {
                    val path = call.argument<String>("path")
                    val maxDimension = call.argument<Int>("maxDimension") ?: 1600
                    if (path.isNullOrBlank()) result.error("missing_image_path", "Görsel yolu bulunamadı.", null)
                    else prepareExportImage(path, maxDimension, result)
                }
                "getExportFreeSpace" -> result.success(filesDir.usableSpace)
                "getExportCapabilities" -> result.success(
                    hashMapOf<String, Any>(
                        "mergePdfFiles" to true,
                        "prepareExportImage" to true,
                        "keepScreenOn" to true,
                        "saveExportToDownloads" to true,
                        "zipDirectory" to true
                    )
                )
                "setExportActive" -> {
                    val active = call.argument<Boolean>("active") ?: false
                    if (active) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    result.success(null)
                }
                "zipDirectory" -> {
                    val sourceDirectory = call.argument<String>("sourceDirectory")
                    val outputPath = call.argument<String>("outputPath")
                    if (sourceDirectory.isNullOrBlank() || outputPath.isNullOrBlank()) {
                        result.error("missing_zip_paths", "ZIP klasörü veya çıktı yolu bulunamadı.", null)
                    } else {
                        zipDirectory(sourceDirectory, outputPath, result)
                    }
                }
                "saveExportToDownloads" -> {
                    val sourcePath = call.argument<String>("path")
                    val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                    val suggestedName = call.argument<String>("suggestedName")
                    if (sourcePath.isNullOrBlank()) {
                        result.error("missing_export_path", "Kaydedilecek dosya yolu bulunamadı.", null)
                    } else {
                        saveExportToDownloads(sourcePath, mimeType, suggestedName, result)
                    }
                }
                "saveExportFile" -> {
                    val sourcePath = call.argument<String>("path")
                    val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                    val suggestedName = call.argument<String>("suggestedName")
                    if (sourcePath.isNullOrBlank()) {
                        result.error("missing_export_path", "Kaydedilecek dosya yolu bulunamadı.", null)
                    } else {
                        openExportSaveDialog(sourcePath, mimeType, suggestedName, result)
                    }
                }
                "mergePdfFiles" -> {
                    val paths = call.argument<List<String>>("paths") ?: emptyList()
                    val outputPath = call.argument<String>("outputPath")
                    if (paths.isEmpty() || outputPath.isNullOrBlank()) result.error("missing_pdf_paths", "Birleştirilecek PDF yolları bulunamadı.", null)
                    else mergePdfFiles(paths, outputPath, result)
                }
                "renderPdfPages" -> {
                    val path = call.argument<String>("path")
                    if (path.isNullOrBlank()) {
                        result.error("missing_path", "PDF dosya yolu bulunamadı.", null)
                    } else {
                        renderPdfPages(path, result)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedFilesFromIntent(intent)
    }

    private fun readSharedFilesFromIntent(incoming: Intent?) {
        if (incoming == null) return

        val uris = linkedSetOf<Uri>()
        when (incoming.action) {
            Intent.ACTION_SEND -> getSingleStreamUri(incoming)?.let(uris::add)
            Intent.ACTION_SEND_MULTIPLE -> uris.addAll(getMultipleStreamUris(incoming))
            Intent.ACTION_VIEW -> incoming.data?.let(uris::add)
        }

        incoming.clipData?.let { clipData ->
            for (index in 0 until clipData.itemCount) {
                clipData.getItemAt(index).uri?.let(uris::add)
            }
        }

        if (uris.isEmpty()) return

        val receivedMime = incoming.type.orEmpty()
        val loaded = uris.mapNotNull { uri -> copyIncomingUri(uri, receivedMime) }
        if (loaded.isNotEmpty()) {
            pendingSharedFiles.clear()
            pendingSharedFiles.addAll(loaded)
            // Aynı paylaşım intent'i normal açılışta yeniden işlenmesin.
            setIntent(Intent(this, MainActivity::class.java))
        }
    }

    private fun copyIncomingUri(uri: Uri, fallbackMime: String = ""): HashMap<String, Any>? {
        return try {
            val displayName = queryDisplayName(uri).ifBlank { "belge_${System.currentTimeMillis()}" }
            val safeName = sanitizeFileName(displayName)
            val mimeType = contentResolver.getType(uri).orEmpty().ifBlank { fallbackMime }.ifBlank { guessMimeType(safeName) }
            val folder = File(cacheDir, "shared_document_imports").apply { mkdirs() }
            val output = File(folder, "${System.nanoTime()}_$safeName")

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(output).use { stream -> input.copyTo(stream) }
            } ?: return null

            if (!output.exists() || output.length() == 0L) return null
            hashMapOf(
                "path" to output.absolutePath,
                "name" to safeName,
                "mimeType" to mimeType,
                "size" to output.length()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment.orEmpty()
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun sanitizeFileName(value: String): String {
        val cleaned = value.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim()
        return cleaned.ifBlank { "belge_${System.currentTimeMillis()}" }
    }

    private fun guessMimeType(name: String): String {
        return when (name.lowercase(Locale.ROOT).substringAfterLast('.', "")) {
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "doc" -> "application/msword"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    @Suppress("DEPRECATION")
    private fun getSingleStreamUri(intent: Intent): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
    }

    @Suppress("DEPRECATION")
    private fun getMultipleStreamUris(intent: Intent): List<Uri> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
        } else {
            intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
        }
    }

    private fun openDocumentPicker(result: MethodChannel.Result, allowMultiple: Boolean) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }
        pendingResult = result
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple)
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/msword",
                    "application/pdf",
                    "text/plain",
                    "application/octet-stream"
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(picker, "Word, PDF veya TXT dosyalarını seç"), requestCodeDocuments)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    private fun openLegacyDocxPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }
        pendingResult = result
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/msword",
                    "application/octet-stream"
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(picker, "Word dosyası seç"), requestCodeDocuments)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    private fun openBackupPicker(result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Dosya seçimi zaten açık.", null)
            return
        }
        pendingResult = result
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "application/zip", "text/plain", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(picker, "Yedek dosyası seç"), requestCodeBackup)
        } catch (e: Exception) {
            pendingResult = null
            result.error("open_failed", e.message, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == requestCodeSaveExport) {
            val result = pendingSaveResult
            val sourcePath = pendingSaveSourcePath
            pendingSaveResult = null
            pendingSaveSourcePath = null
            if (result == null) return
            if (resultCode != Activity.RESULT_OK || data?.data == null || sourcePath.isNullOrBlank()) {
                result.success(null)
                return
            }
            val destination = data.data!!
            try {
                val source = File(sourcePath)
                if (!source.exists() || source.length() == 0L) {
                    throw IllegalArgumentException("Kaydedilecek dosya bulunamadı.")
                }
                contentResolver.openOutputStream(destination, "w")?.use { output ->
                    source.inputStream().use { input -> input.copyTo(output) }
                    output.flush()
                } ?: throw IllegalStateException("Seçilen konuma yazılamadı.")
                result.success(hashMapOf<String, Any>(
                    "uri" to destination.toString(),
                    "name" to queryDisplayName(destination).ifBlank { source.name },
                    "size" to source.length()
                ))
            } catch (e: Exception) {
                result.error("save_export_failed", e.message ?: "Dosya kaydedilemedi.", null)
            }
            return
        }

        if (requestCode != requestCodeDocuments && requestCode != requestCodeBackup) return

        val result = pendingResult
        pendingResult = null
        if (result == null) return
        if (resultCode != Activity.RESULT_OK || data == null) {
            result.success(null)
            return
        }

        if (requestCode == requestCodeBackup) {
            val uri = data.data
            if (uri == null) {
                result.success(null)
                return
            }
            try {
                result.success(contentResolver.openInputStream(uri)?.use { it.readBytes() })
            } catch (e: Exception) {
                result.error("read_error", e.message, null)
            }
            return
        }

        val uris = linkedSetOf<Uri>()
        data.data?.let(uris::add)
        data.clipData?.let { clipData ->
            for (index in 0 until clipData.itemCount) {
                clipData.getItemAt(index).uri?.let(uris::add)
            }
        }
        val files = uris.mapNotNull { copyIncomingUri(it, data.type.orEmpty()) }
        result.success(files)
    }

    private fun zipDirectory(
        sourceDirectoryPath: String,
        outputPath: String,
        result: MethodChannel.Result
    ) {
        Thread {
            try {
                val sourceDirectory = File(sourceDirectoryPath)
                if (!sourceDirectory.exists() || !sourceDirectory.isDirectory) {
                    throw IllegalArgumentException("ZIP yapılacak klasör bulunamadı.")
                }
                val output = File(outputPath)
                output.parentFile?.mkdirs()
                if (output.exists() && !output.delete()) {
                    throw IllegalStateException("Eski ZIP dosyası silinemedi.")
                }

                val files = sourceDirectory.walkTopDown()
                    .filter { it.isFile }
                    .sortedBy { it.relativeTo(sourceDirectory).invariantSeparatorsPath.lowercase(Locale.ROOT) }
                    .toList()
                if (files.isEmpty()) {
                    throw IllegalArgumentException("ZIP paketine eklenecek dosya bulunamadı.")
                }

                val buffer = ByteArray(1024 * 1024)
                ZipOutputStream(BufferedOutputStream(FileOutputStream(output), 1024 * 1024)).use { zip ->
                    // PDF, DOCX, JPG ve PNG zaten sıkıştırılmıştır. BEST_SPEED hem daha az CPU/RAM
                    // kullanır hem de büyük kitap paketlerinde uygulamanın kapanma riskini azaltır.
                    zip.setLevel(Deflater.BEST_SPEED)
                    for (file in files) {
                        val entryName = file.relativeTo(sourceDirectory).invariantSeparatorsPath
                        val entry = ZipEntry(entryName).apply {
                            time = file.lastModified()
                        }
                        zip.putNextEntry(entry)
                        BufferedInputStream(FileInputStream(file), 1024 * 1024).use { input ->
                            while (true) {
                                val read = input.read(buffer)
                                if (read <= 0) break
                                zip.write(buffer, 0, read)
                            }
                        }
                        zip.closeEntry()
                    }
                    zip.finish()
                    zip.flush()
                }

                if (!output.exists() || output.length() < 100L) {
                    throw IllegalStateException("ZIP dosyası oluşturulamadı.")
                }
                runOnUiThread { result.success(output.absolutePath) }
            } catch (e: Exception) {
                runCatching { File(outputPath).delete() }
                runOnUiThread {
                    result.error("zip_failed", e.message ?: "ZIP dosyası oluşturulamadı.", null)
                }
            }
        }.start()
    }

    private fun saveExportToDownloads(
        sourcePath: String,
        mimeType: String,
        suggestedName: String?,
        result: MethodChannel.Result
    ) {
        Thread {
            var insertedUri: Uri? = null
            try {
                val source = File(sourcePath)
                if (!source.exists() || source.length() == 0L) {
                    throw IllegalArgumentException("Kaydedilecek dosya bulunamadı.")
                }
                val requestedName = sanitizeFileName(
                    suggestedName?.takeIf { it.isNotBlank() } ?: source.name
                )

                val savedName: String
                val savedLocation: String
                val savedUri: String

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, requestedName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType.ifBlank { "application/octet-stream" })
                        put(
                            MediaStore.MediaColumns.RELATIVE_PATH,
                            "${Environment.DIRECTORY_DOWNLOADS}/AltayParanormal"
                        )
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    val destination = contentResolver.insert(collection, values)
                        ?: throw IllegalStateException("Download klasöründe dosya oluşturulamadı.")
                    insertedUri = destination
                    contentResolver.openOutputStream(destination, "w")?.use { output ->
                        source.inputStream().buffered().use { input ->
                            input.copyTo(output, DEFAULT_BUFFER_SIZE * 8)
                        }
                        output.flush()
                    } ?: throw IllegalStateException("Download klasörüne yazılamadı.")

                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    contentResolver.update(destination, values, null, null)
                    savedName = queryDisplayName(destination).ifBlank { requestedName }
                    savedLocation = "Download/AltayParanormal/$savedName"
                    savedUri = destination.toString()
                } else {
                    @Suppress("DEPRECATION")
                    val folder = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        "AltayParanormal"
                    ).apply { mkdirs() }
                    var target = File(folder, requestedName)
                    if (target.exists()) {
                        val base = requestedName.substringBeforeLast('.', requestedName)
                        val extension = requestedName.substringAfterLast('.', "")
                        val suffix = System.currentTimeMillis()
                        target = File(
                            folder,
                            if (extension.isBlank()) "${base}_$suffix" else "${base}_$suffix.$extension"
                        )
                    }
                    source.inputStream().buffered().use { input ->
                        target.outputStream().buffered().use { output ->
                            input.copyTo(output, DEFAULT_BUFFER_SIZE * 8)
                            output.flush()
                        }
                    }
                    savedName = target.name
                    savedLocation = target.absolutePath
                    savedUri = Uri.fromFile(target).toString()
                }

                runOnUiThread {
                    result.success(
                        hashMapOf<String, Any>(
                            "uri" to savedUri,
                            "name" to savedName,
                            "location" to savedLocation,
                            "size" to source.length()
                        )
                    )
                }
            } catch (e: Exception) {
                insertedUri?.let { uri -> runCatching { contentResolver.delete(uri, null, null) } }
                runOnUiThread {
                    result.error(
                        "save_download_failed",
                        e.message ?: "Dosya Download klasörüne kaydedilemedi.",
                        null
                    )
                }
            }
        }.start()
    }

    private fun openExportSaveDialog(
        sourcePath: String,
        mimeType: String,
        suggestedName: String?,
        result: MethodChannel.Result
    ) {
        if (pendingSaveResult != null) {
            result.error("save_busy", "Başka bir kaydetme penceresi zaten açık.", null)
            return
        }
        val source = File(sourcePath)
        if (!source.exists() || source.length() == 0L) {
            result.error("missing_export_file", "Kaydedilecek dosya bulunamadı.", null)
            return
        }
        pendingSaveResult = result
        pendingSaveSourcePath = source.absolutePath
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_TITLE, suggestedName?.takeIf { it.isNotBlank() } ?: source.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, requestCodeSaveExport)
        } catch (e: Exception) {
            pendingSaveResult = null
            pendingSaveSourcePath = null
            result.error("save_dialog_failed", e.message ?: "Kaydetme penceresi açılamadı.", null)
        }
    }

    private fun mergePdfFiles(paths: List<String>, outputPath: String, result: MethodChannel.Result) {
        Thread {
            try {
                val validFiles = paths.map(::File).filter { it.exists() && it.length() > 5L }
                if (validFiles.isEmpty()) throw IllegalArgumentException("Birleştirilecek geçerli PDF bulunamadı.")

                val outputFile = File(outputPath)
                outputFile.parentFile?.mkdirs()
                if (outputFile.exists() && !outputFile.delete()) {
                    throw IllegalStateException("Eski PDF çıktısı silinemedi.")
                }

                // PDFRenderer ile sayfaları resme çevirip yeniden yazmak metni seçilemez
                // hâle getiriyor ve dosyayı gereksiz büyütüyordu. PDFBox sayfa nesnelerini
                // doğrudan birleştirir; metin, vektörler ve gömülü yazı tipleri korunur.
                val merger = PDFMergerUtility().apply {
                    destinationFileName = outputFile.absolutePath
                }
                validFiles.forEach { source -> merger.addSource(source) }
                merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())

                if (!outputFile.exists() || outputFile.length() < 5L) {
                    throw IllegalStateException("Birleştirilmiş PDF yazılamadı.")
                }
                runOnUiThread { result.success(outputFile.absolutePath) }
            } catch (e: Exception) {
                runOnUiThread {
                    result.error("pdf_merge_failed", e.message ?: "PDF birleştirme başarısız.", null)
                }
            }
        }.start()
    }

    private fun prepareExportImage(path: String, maxDimension: Int, result: MethodChannel.Result) {
        Thread {
            try {
                val source = File(path)
                if (!source.exists() || source.length() == 0L) throw IllegalArgumentException("Görsel dosyası bulunamadı.")
                val safeMax = maxDimension.coerceIn(800, 2200)
                val cacheFolder = File(cacheDir, "prepared_export_images").apply { mkdirs() }
                val cacheKey = "${source.absolutePath.hashCode()}_${source.lastModified()}_${source.length()}_$safeMax"
                val output = File(cacheFolder, "$cacheKey.jpg")

                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(source.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("Görsel biçimi okunamadı.")

                var sampleSize = 1
                while (bounds.outWidth / sampleSize > safeMax * 2 || bounds.outHeight / sampleSize > safeMax * 2) {
                    sampleSize *= 2
                }

                if (!output.exists() || output.length() == 0L) {
                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    val decoded = BitmapFactory.decodeFile(source.absolutePath, options)
                        ?: throw IllegalArgumentException("Görsel çözümlenemedi.")
                    val scale = minOf(1f, safeMax.toFloat() / maxOf(decoded.width, decoded.height).toFloat())
                    val targetWidth = maxOf(1, (decoded.width * scale).toInt())
                    val targetHeight = maxOf(1, (decoded.height * scale).toInt())
                    val resized = if (targetWidth != decoded.width || targetHeight != decoded.height) {
                        Bitmap.createScaledBitmap(decoded, targetWidth, targetHeight, true)
                    } else decoded
                    val flattened = Bitmap.createBitmap(resized.width, resized.height, Bitmap.Config.RGB_565)
                    Canvas(flattened).apply {
                        drawColor(Color.WHITE)
                        drawBitmap(resized, 0f, 0f, null)
                    }
                    FileOutputStream(output).use { stream ->
                        if (!flattened.compress(Bitmap.CompressFormat.JPEG, 84, stream)) {
                            throw IllegalStateException("Görsel dışa aktarma için hazırlanamadı.")
                        }
                    }
                    if (resized !== decoded) resized.recycle()
                    decoded.recycle()
                    flattened.recycle()
                }

                val finalBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(output.absolutePath, finalBounds)
                val payload = hashMapOf<String, Any>(
                    "path" to output.absolutePath,
                    "width" to finalBounds.outWidth.coerceAtLeast(1),
                    "height" to finalBounds.outHeight.coerceAtLeast(1),
                    "extension" to "jpg"
                )
                runOnUiThread { result.success(payload) }
            } catch (e: Exception) {
                runOnUiThread { result.error("image_prepare_failed", e.message ?: "Görsel hazırlanamadı.", null) }
            }
        }.start()
    }

    private fun renderPdfPages(path: String, result: MethodChannel.Result) {
        val source = File(path)
        if (!source.exists()) {
            result.error("pdf_missing", "PDF dosyası bulunamadı.", null)
            return
        }

        try {
            val outputDir = File(filesDir, "imported_pdf_pages/${source.nameWithoutExtension}_${source.lastModified()}").apply { mkdirs() }
            val descriptor = ParcelFileDescriptor.open(source, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(descriptor)
            val outputPaths = mutableListOf<String>()

            for (index in 0 until renderer.pageCount) {
                val page = renderer.openPage(index)
                val scale = minOf(2.0f, 2200f / page.width.toFloat())
                val width = maxOf(1, (page.width * scale).toInt())
                val height = maxOf(1, (page.height * scale).toInt())
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                Canvas(bitmap).drawColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                val output = File(outputDir, "sayfa_${(index + 1).toString().padStart(3, '0')}.png")
                FileOutputStream(output).use { bitmap.compress(Bitmap.CompressFormat.PNG, 95, it) }
                bitmap.recycle()
                page.close()
                outputPaths.add(output.absolutePath)
            }

            renderer.close()
            descriptor.close()
            result.success(outputPaths)
        } catch (e: Exception) {
            result.error("pdf_render_failed", e.message ?: "PDF sayfaları okunamadı.", null)
        }
    }
}
