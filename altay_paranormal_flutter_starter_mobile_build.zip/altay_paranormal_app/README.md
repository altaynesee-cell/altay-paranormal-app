SÜRÜM 5 - TAM SAYFA DETAY VE GALERİ DÜZELTMESİ

# Altay Paranormal App — 2. Sürüm

Bu paket, **Gizem, UFO ve Paranormal Araştırman Altay Aytın** için hazırlanmış yönetilebilir Flutter mobil uygulamasıdır.

## Bu sürümde neler var?

- Ana sayfa
- Yazılar
- Saha gezileri
- Galeri
- Kitap tanıtımı
- Hakkımda ve iletişim sayfaları
- Uygulama içinden içerik yönetimi
- Makale / yazı ekleme, düzenleme ve silme
- Saha notu ekleme, düzenleme ve silme
- Galeri kaydı ekleme, düzenleme ve silme
- Görsel URL ve kaynak/lisans bilgisi ekleme
- Yerel yedek kopyalama ve yedekten yükleme

## Önemli not

Bu sürümde eklediğin içerikler **telefonun içinde** saklanır. Uygulamayı silersen içerikler de silinebilir. Bu yüzden Yönetim Paneli içindeki **Yedek kopyala** özelliğini kullan.

## Görsel politikası

Galeriye AI görsel eklenmedi. Görseller için gerçek, telifsiz, kamu malı veya izinli kaynak bağlantısı kullanman önerilir.

## Mobilden APK alma

Önceki GitHub düzeninde `altay_paranormal_flutter_starter_mobile_build.zip` dosyasını yenisiyle değiştirmen yeterli. GitHub Actions tekrar APK üretir.


## 4. sürüm notu
- Yazı ve galeri detayları artık alttan yarım pencere olarak değil, tam sayfa açılır. Uzun metinler rahat okunur.


## Sürüm 7 Notları
- Kitap okuyucuda yazı kontrastı koyulaştırıldı.
- Kitap bölümü içine satır arası görsel ekleme eklendi.
- Metinde `[GÖRSEL1]`, `[GÖRSEL2]` gibi tek satır işaretleri kullanılır; seçilen görseller o satırda görünür.


## Sürüm 66 — Toplu Word paylaşımı

- Android `ACTION_SEND_MULTIPLE` desteği eklendi.
- Dosya yöneticisinden birden fazla DOCX seçildiğinde Altay Paranormal paylaşım listesinde görünür.
- Paylaşılan Word dosyaları sırayla okunur ve bulunan bölümler tek onay penceresiyle mevcut kitabın sonuna eklenir.
- Bir dosya bozuksa diğer dosyaların içe aktarımı devam eder.


## Sürüm 67 — Yayınevi paketi ve uyumlu toplu paylaşım

- Her bölüm ayrı DOCX ve ayrı PDF olarak oluşturulur.
- Bütün dosyalar `WORD` ve `PDF` klasörleri bulunan tek ZIP paketine alınır.
- Android paylaşım ekranına çok sayıda dosya yerine tek ZIP gönderilir; böylece çoklu dosya paylaşımını desteklemeyen hedef uygulamaların görünmeme sorunu azaltılır.
- İstenirse yalnız Word ZIP veya yalnız PDF ZIP hazırlanabilir.
- Dosya yöneticisinden birden fazla Word dosyasını Altay Paranormal'a gönderme desteği de eklenmiştir.
