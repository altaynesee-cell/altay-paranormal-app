# Altay Paranormal App — Flutter Başlangıç Projesi

Bu paket, **Gizem, UFO ve Paranormal Araştırman Altay Aytın** için hazırlanmış ilk mobil uygulama iskeletidir.

## İçindeki bölümler

- Ana sayfa
- Makaleler
- Saha gezileri
- Galeri
- Kitap tanıtımı
- Hakkımda
- İletişim

## Önemli not

Bu paket kaynak kodudur. Burada doğrudan APK derlenmedi. APK almak için bilgisayarda Flutter ve Android Studio gerekir.

## Kurulum

1. Bilgisayara Flutter kurun.
2. Android Studio kurun.
3. ZIP dosyasını açın.
4. Terminali proje klasöründe açın.
5. Şu komutları çalıştırın:

```bash
flutter pub get
flutter create .
flutter run
```

APK almak için:

```bash
flutter build apk --release
```

APK dosyası genelde şu klasörde oluşur:

```bash
build/app/outputs/flutter-apk/app-release.apk
```

## İçerik düzenleme

Makaleler ve saha notları şu dosyadadır:

```text
lib/main.dart
```

Şu listeleri düzenleyebilirsiniz:

```dart
sampleArticles
fieldNotes
```

## Görsel politikası

Galeri bölümü bilerek boş/yer tutucu bırakıldı. Kullanılacak görseller gerçek, telifsiz, kamu malı veya izinli kaynaklardan eklenmelidir. AI üretimli görsel kullanılmadı.

## Sonraki sürümde eklenebilecekler

- Gerçek görsel galerisi
- Makale detay sayfası
- YouTube / Instagram / web sitesi bağlantıları
- WhatsApp iletişim butonu
- Favorilere ekleme
- Bildirim sistemi
- Yönetici paneli / içerik güncelleme sistemi

## Mobilden APK alma

Bu pakette `.github/workflows/build-apk.yml` dosyası hazırdır. Bilgisayar yoksa projeyi telefondan GitHub'a yükleyip Actions sekmesinden APK üretebilirsin. Ayrıntılı adımlar için `MOBILDEN_APK_YAPMA_REHBERI.md` dosyasına bak.
