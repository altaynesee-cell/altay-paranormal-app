SÜRÜM 5 - TAM SAYFA DETAY VE GALERİ DÜZELTMESİ

# Altay Paranormal App — 2. Sürüm

Bu paket, **Gizem, UFO ve Paranormal Araştırman Altay Aytın** için hazırlanmış yönetilebilir Flutter mobil uygulamasıdır.

## Bu sürümde neler var?

- Ana sayfa
- Yazılar
- Saha gezileri
- Galeri
- Kitap tanıtımı
- Hakkımda ve iletişim sayfaları
- Uygulama içinden içerik yönetimi
- Makale / yazı ekleme, düzenleme ve silme
- Saha notu ekleme, düzenleme ve silme
- Galeri kaydı ekleme, düzenleme ve silme
- Görsel URL ve kaynak/lisans bilgisi ekleme
- Yerel yedek kopyalama ve yedekten yükleme

## Önemli not

Bu sürümde eklediğin içerikler **telefonun içinde** saklanır. Uygulamayı silersen içerikler de silinebilir. Bu yüzden Yönetim Paneli içindeki **Yedek kopyala** özelliğini kullan.

## Görsel politikası

Galeriye AI görsel eklenmedi. Görseller için gerçek, telifsiz, kamu malı veya izinli kaynak bağlantısı kullanman önerilir.

## Mobilden APK alma

Önceki GitHub düzeninde `altay_paranormal_flutter_starter_mobile_build.zip` dosyasını yenisiyle değiştirmen yeterli. GitHub Actions tekrar APK üretir.


## 4. sürüm notu
- Yazı ve galeri detayları artık alttan yarım pencere olarak değil, tam sayfa açılır. Uzun metinler rahat okunur.


## Sürüm 7 Notları
- Kitap okuyucuda yazı kontrastı koyulaştırıldı.
- Kitap bölümü içine satır arası görsel ekleme eklendi.
- Metinde `[GÖRSEL1]`, `[GÖRSEL2]` gibi tek satır işaretleri kullanılır; seçilen görseller o satırda görünür.


## Sürüm 66 — Toplu Word paylaşımı

- Android `ACTION_SEND_MULTIPLE` desteği eklendi.
- Dosya yöneticisinden birden fazla DOCX seçildiğinde Altay Paranormal paylaşım listesinde görünür.
- Paylaşılan Word dosyaları sırayla okunur ve bulunan bölümler tek onay penceresiyle mevcut kitabın sonuna eklenir.
- Bir dosya bozuksa diğer dosyaların içe aktarımı devam eder.


## Sürüm 67 — Yayınevi paketi ve uyumlu toplu paylaşım

- Her bölüm ayrı DOCX ve ayrı PDF olarak oluşturulur.
- Bütün dosyalar `WORD` ve `PDF` klasörleri bulunan tek ZIP paketine alınır.
- Android paylaşım ekranına çok sayıda dosya yerine tek ZIP gönderilir; böylece çoklu dosya paylaşımını desteklemeyen hedef uygulamaların görünmeme sorunu azaltılır.
- İstenirse yalnız Word ZIP veya yalnız PDF ZIP hazırlanabilir.
- Dosya yöneticisinden birden fazla Word dosyasını Altay Paranormal'a gönderme desteği de eklenmiştir.

## Sürüm 68 — Toplu dış dosya alma

- Dosyalar, Word, Drive veya başka bir uygulamada birden fazla DOCX/PDF/TXT seçilip **Paylaş** denildiğinde Altay Paranormal paylaşım listesinde görünür.
- Tekli ve çoklu paylaşım (`ACTION_SEND` ve `ACTION_SEND_MULTIPLE`) desteklenir.
- Word ve PDF karışık seçilebilir; her dosya türü ayrı tanınır. PDF artık Word gibi okunmaya çalışılmaz.
- DOCX dosyaları metinleri ve içindeki görsellerle içe aktarılır.
- PDF dosyaları, sayfa yerleşimi ve görselleri bozulmaması için her sayfa tam sayfa görsel olarak ayrı bölüme alınır.
- Uygulamanın içindeki **Word/PDF yükle** düğmesi de birden fazla dosya seçebilir.
- İçe aktarılan dosyalar mevcut bölümlerin sonuna eklenir; mevcut bölümler kendiliğinden silinmez.
- Eski `.doc` biçimi doğrudan çözümlenmez; Word'de DOCX olarak kaydedilmelidir.


## Sürüm 69 — Akıllı Bölüm Akışı

- Başlık, konu ve coğrafyaya göre akıllı bölüm sıralama önerisi.
- Dengeli, konu öncelikli ve coğrafya öncelikli sıralama seçenekleri.
- David Icke → Anunnakiler → Ubeyd figürleri gibi mantıksal başlangıç zincirleri.
- Öneriyi uygulamadan önce eski ve yeni sıra ön izlemesi ile her bölüm için gerekçe.
- Kilitli bölümleri yerinde tutma, tek dokunuşla geri alma ve sonradan elle değiştirme.
- Yavaş, normal, hızlı ve çok hızlı bölüm taşıma ayarı.
- Bölümü doğrudan yazılan sıra numarasına taşıma.

## Sürüm 70 — Kaynak Korumalı Yapay Zekâ Editörü

- Bölümü kısaltmadan yazım, tekrar, anlatım ve geçiş analizi.
- Medeniyet ve antik yer tanıtımlarını gereksiz yere tekrarlamayan bağımsız araştırmacı üslubu.
- Bölümdeki gerçek motiflerden hareket eden, kesin hüküm kurmayan sürüngen soy/Reptilyan bağlantısı.
- Sahte tarih, kaynak, kazı, eser, alıntı ve akademik görüş üretmeme kuralı.
- Kaynak doğrulaması gereken noktaları metne eklemek yerine raporda gösterme.
- Düzenleme öncesi/sonrası kelime ve paragraf kontrolü.
- Yüzde 98 uzunluk koruması; bölümü aşırı kısaltan cevapları engelleme.
- Uygulamadan önce değişiklik ön izlemesi ve onay.
- Bölüm kartındaki rapor düğmesinden eklenen/değiştirilen noktaları, eski metni ve güncel metni görme.


## Sürüm 71

- Bölümler ekranında **Bölüm seç** düğmesi ve uzun basma ile çoklu seçim açılır.
- İşaretlenen kilitsiz bölümler tek onayla topluca silinir; işlem **Geri al** ile geri getirilebilir.
- Toplu DOCX, PDF ve TXT içe aktarımında `1. Bölüm`, `Bölüm 2`, `03-Bölüm` ve dosya başındaki numaralar algılanır.
- Ön söz ve giriş başta, numaralı bölümler artan sırada, son söz ve kaynakça sonda tutulur.
- PDF dosya adındaki bölüm numarası da sıralamada kullanılır.


## Sürüm 72
- Kitap bölümü ilk kurulumda tamamen boş açılır.
- Önceki paketlerdeki üç hazır örnek kitap bölümü otomatik temizlenir.
- Kullanıcının yüklediği veya elle oluşturduğu bölümler korunur.
- Yeni boş bölüm formunda hazır '1. Bölüm' metni bulunmaz.

## Sürüm 73

- DOCX/TXT içe aktarımında tekrarlanan `Antik Medeniyetler` genel üst başlığı artık bölüm olarak oluşturulmaz.
- `Antik Medeniyetlerde Reptilyanların İzinde` kitap başlığı da bölüm listesinden hariç tutulur.
- Numaralı ve özgün bölüm başlıkları normal biçimde içe aktarılmaya devam eder.


## Sürüm 74
- Gerçek DOCX ve PDF dışa aktarma yeniden yazıldı.
- Yayınevi paketi tam kitap, ayrı bölümler ve gerçek görselleri içerir.
- Proje yedeği ZIP; JSON, görseller, Word ve PDF ön izlemesini birlikte saklar.


## Sürüm 83 dışa aktarma
- Tek bölüm Word ve PDF, bölüm kartından ayrı ayrı aktarılır.
- Yayınevi Paketi yalnızca görselleri gömülü düzenlenebilir tam DOCX ile baskıya hazır tam PDF içerir.
- Çalışmayan toplu bölüm ZIP ve ayrı yayınevi Word/PDF düğmeleri arayüzden kaldırıldı.
