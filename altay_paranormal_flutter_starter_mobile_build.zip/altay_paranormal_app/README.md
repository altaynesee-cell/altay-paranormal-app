# Altay Paranormal - Sürüm 85

Gizem, UFO, paranormal araştırmalar ve **Antik Medeniyetlerde Reptilyanların İzinde** kitap projesi için hazırlanmış Flutter Android uygulaması.

## Sürüm 85 - yayınevi dışa aktarma düzeni

- **Yayınevi Paketi** içinde iki ana dosya oluşturulur:
  - `Altay_Aytin_Tam_Kitap_Duzenlenebilir.docx`
  - `Altay_Aytin_Tam_Kitap_Baskiya_Hazir.pdf`
- Word ve PDF, aynı 13,5 × 21 cm kitap ölçüsünü ve aynı bölüm akışını kullanır.
- Word görselleri dosyanın içine gömer; ayrı görsel klasörüne bağlı değildir.
- Görseller sayfa genişliğini ve yüksekliğini aşmadan, en-boy oranı korunarak yerleştirilir.
- Word içinde gerçek **Başlık 1 / Başlık 2 / Başlık 3** stilleri kullanılır.
- Bölüm numarası, ana başlık, alt başlık ve gövde metni ayrı paragraf yapısındadır.
- `Ön Söz`, `Giriş`, `Biyografi`, `Son Söz`, `Kaynakça` gibi özel alanlar bölüm numarası almaz.
- Sayfa numaraları kitap boyunca kesintisiz ilerler.
- Bölüm sonuna zorla sayfa sonu eklenmez; gereksiz boş sayfalar azaltılır.
- Gövde metni sola hizalıdır; kelimeler arasında aşırı boşluk oluşmaz.
- `ALTAY AYTIN KİMDİR? Altay Aytın...` biçimindeki birleşik satırlar başlık ve paragraf olarak ayrılır.
- Son Söz önündeki yanlış `ÖNSÖZ` gibi yinelenen yapısal başlıklar temizlenir.
- PDF sayfaları resme çevrilmez; metin seçilebilir ve aranabilir kalır.

## Diğer kitap özellikleri

- DOCX, PDF ve TXT dosyalarını tekli veya toplu içe aktarma
- Dış uygulamalardaki Paylaş menüsünden tekli/çoklu belge alma
- Bölüm numarasına göre otomatik sıralama
- Akıllı konu/coğrafya akışı önerisi
- Bölüm taşıma hızı ve belirli sıraya taşıma
- Çoklu bölüm seçme ve silme
- Kaynak korumalı yapay zekâ editörü ve değişiklik raporu
- Tek bölüm Word ve tek bölüm PDF dışa aktarma

## GitHub üzerinden APK oluşturma

Depoda bulunan `altay_paranormal_flutter_starter_mobile_build.zip` dosyasını bu paketle değiştirin. GitHub Actions yeni APK'yı otomatik oluşturur.

Kaynak ZIP'in kök yapısı:

```text
altay_paranormal_app/
  lib/main.dart
  pubspec.yaml
  android/
  assets/
```

> Eski Word veya PDF çıktıları kendiliğinden değişmez. Sürüm 85 APK kurulduktan sonra Yayınevi Paketini yeniden oluşturun.
