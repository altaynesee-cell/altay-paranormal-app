# Altay Paranormal App — 2. Sürüm

Bu paket, **Gizem, UFO ve Paranormal Araştırman Altay Aytın** için hazırlanmış yönetilebilir Flutter mobil uygulamasıdır.

## Bu sürümde neler var?

- Ana sayfa
- Yazılar
- Saha gezileri
- Galeri
- Kitap tanıtımı
- Hakkımda ve iletişim sayfaları
- Uygulama içinden içerik yönetimi
- Makale / yazı ekleme, düzenleme ve silme
- Saha notu ekleme, düzenleme ve silme
- Galeri kaydı ekleme, düzenleme ve silme
- Görsel URL ve kaynak/lisans bilgisi ekleme
- Yerel yedek kopyalama ve yedekten yükleme

## Önemli not

Bu sürümde eklediğin içerikler **telefonun içinde** saklanır. Uygulamayı silersen içerikler de silinebilir. Bu yüzden Yönetim Paneli içindeki **Yedek kopyala** özelliğini kullan.

## Görsel politikası

Galeriye AI görsel eklenmedi. Görseller için gerçek, telifsiz, kamu malı veya izinli kaynak bağlantısı kullanman önerilir.

## Mobilden APK alma

Önceki GitHub düzeninde `altay_paranormal_flutter_starter_mobile_build.zip` dosyasını yenisiyle değiştirmen yeterli. GitHub Actions tekrar APK üretir.


## 4. sürüm notu
- Yazı ve galeri detayları artık alttan yarım pencere olarak değil, tam sayfa açılır. Uzun metinler rahat okunur.
